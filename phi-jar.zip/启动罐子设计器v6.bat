﻿@echo off
chcp 65001 >nul
cd /d "C:\Users\lenovo\Desktop\罐子设计器"
start "" "C:\Users\lenovo\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\pythonw.exe" "jar_studio_v6.py"
