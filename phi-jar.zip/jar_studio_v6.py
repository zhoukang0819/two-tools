#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JAR STUDIO — 参数化罐体设计器

纯 Python：tkinter + numpy 实时渲染，可调形体参数、可转视角、可直接在罐身上画图。

    python jar_studio.py          打开界面
    python jar_studio.py --check   自检（打印渲染耗时）
    python jar_studio.py --sample  输出示例图
"""

from __future__ import annotations

import json
import math
import os
import sys
import time

import numpy as np
import tkinter as tk
from tkinter import filedialog

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageTk

# --------------------------------------------------------------------------- theme
BG = "#E9E1D8"
PANEL = "#F6F0E9"
PANEL_2 = "#E4D8CD"
LINE = "#D6C8BC"
TEXT = "#4B433F"
MUTED = "#9B8E85"
ACCENT = "#B08968"
ACCENT_2 = "#8A9A8B"
FONT = "微软雅黑"

TEX_W, TEX_H = 1024, 512

SWATCHES = [
    ("#F1E9DF", "米白"), ("#DCC9B6", "燕麦"), ("#C9ADA7", "灰粉"),
    ("#A3B18A", "鼠尾草"), ("#8FA3AD", "雾蓝"), ("#B7A6B8", "灰紫"),
    ("#8D8177", "灰褐"), ("#D8B08C", "杏仁"),
]

BODY_SPECS = [
    ("body_h", "罐身高度", 60.0, 190.0, 118.0, 1.0, "mm"),
    ("body_w", "罐身宽度", 50.0, 132.0, 112.0, 1.0, "mm"),
    ("belly", "腹部鼓起", 0.0, 0.24, 0.10, 0.01, ""),
    ("shoulder_h", "肩部高度", 6.0, 70.0, 24.0, 1.0, "mm"),
    ("curve", "肩部曲率", 0.5, 2.2, 1.25, 0.05, ""),
    ("neck_w", "脖子宽度", 16.0, 84.0, 64.0, 1.0, "mm"),
    ("neck_h", "脖子高度", 6.0, 80.0, 18.0, 1.0, "mm"),
    ("mouth_w", "罐口宽度", 18.0, 96.0, 72.0, 1.0, "mm"),
    ("fillet", "底部圆角", 2.0, 18.0, 12.0, 1.0, "mm"),
    ("bead", "口沿厚度", 0.0, 3.0, 1.2, 0.1, "mm"),
]
VIEW_SPECS = [
    ("tilt", "俯视角度", 0.0, 40.0, 12.0, 1.0, "°"),
    ("spin", "旋转", 0.0, 360.0, 0.0, 1.0, "°"),
    ("light_az", "光照方向", 0.0, 360.0, 315.0, 1.0, "°"),
    ("light_power", "光照强度", 0.4, 2.0, 1.0, 0.05, ""),
    ("persp", "透视强度", 0.0, 1.0, 0.55, 0.05, ""),
    ("ambient", "环境光", 0.15, 1.2, 0.55, 0.05, ""),
]
SPECS = BODY_SPECS + VIEW_SPECS

PRESETS = {
    "梅森罐": dict(body_w=92, body_h=128, belly=0.0, shoulder_h=16, curve=1.45,
                  neck_w=64, neck_h=22, mouth_w=66, fillet=8, bead=1.6),
    "牛奶瓶": dict(body_w=76, body_h=118, belly=0.02, shoulder_h=54, curve=0.55,
                  neck_w=34, neck_h=54, mouth_w=44, fillet=22, bead=2.4),
    "姜罐": dict(body_w=108, body_h=86, belly=0.18, shoulder_h=26, curve=1.35,
                neck_w=58, neck_h=10, mouth_w=64, fillet=6, bead=0.5),
    "香水瓶": dict(body_w=66, body_h=88, belly=0.0, shoulder_h=16, curve=1.4,
                 neck_w=14, neck_h=40, mouth_w=18, fillet=3, bead=0.6),
    "药瓶": dict(body_w=64, body_h=118, belly=0.01, shoulder_h=22, curve=0.9,
               neck_w=28, neck_h=16, mouth_w=34, fillet=8, bead=1.8),
    "玻璃杯": dict(kind="glass", body_w=88, body_h=172, mouth_w=64, neck_w=40,
                neck_h=20, shoulder_h=20, belly=0.0, curve=1.0, fillet=6, bead=0.6),
    "酒瓶": dict(body_w=76, body_h=118, belly=0.0, shoulder_h=52, curve=0.62,
               neck_w=28, neck_h=60, mouth_w=30, fillet=12, bead=1.3),
}


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# --------------------------------------------------------------------------- geometry
def smooth_curve(arr, passes: int = 2):
    """轻度平滑，去掉参数拼接处的硬折角，让罐身曲线更连续"""
    a = np.asarray(arr, dtype=np.float32).copy()
    if a.size < 8:
        return a
    for _ in range(passes):
        pad = np.concatenate([a[:1], a, a[-1:]])
        a = 0.25 * pad[:-2] + 0.5 * pad[1:-1] + 0.25 * pad[2:]
    return a


def build_profile_raw(p, samples: int = 720):
    if p.get("kind") == "glass":
        return build_glass_profile(p, samples)
    body_r = p["body_w"] / 2.0
    neck_r = p["neck_w"] / 2.0
    mouth_r = p["mouth_w"] / 2.0
    body_h = p["body_h"]
    neck_h = p["neck_h"]
    shoulder = p["shoulder_h"]
    belly = p["belly"]
    curve = max(0.4, p["curve"])
    fillet = min(p["fillet"], body_h * 0.45, body_r * 0.45)

    bead = p.get("bead", 1.2)
    lip_h = max(3.0, neck_h * 0.14)
    roll = max(0.6, abs(mouth_r - neck_r) * 0.18)
    total = body_h + shoulder + neck_h + lip_h

    ys = np.linspace(0.0, total, samples, dtype=np.float32)
    rs = np.empty_like(ys)

    for i in range(samples):
        y = float(ys[i])
        if y < fillet:
            t = (fillet - y) / fillet
            r = body_r - fillet + math.sqrt(max(fillet * fillet - t * t * fillet * fillet, 0.0))
        elif y < body_h:
            r = body_r
        elif y < body_h + shoulder:
            t = (y - body_h) / max(shoulder, 1e-6)
            k = t * t * t * (t * (t * 6 - 15) + 10)
            r = body_r + (neck_r - body_r) * (k ** curve)
        elif y < body_h + shoulder + neck_h:
            r = neck_r
        else:
            t = (y - (body_h + shoulder + neck_h)) / lip_h
            if t < 0.58:
                k = t / 0.58
                k = k * k * k * (k * (k * 6 - 15) + 10)
                r = neck_r + (mouth_r - neck_r) * k
            else:
                k = (t - 0.58) / 0.42
                r = mouth_r - roll * (k * k)

        if y > total - lip_h * 1.6 and bead > 0:
            r += bead * math.exp(-(((y - (total - lip_h * 0.55)) / (lip_h * 0.5)) ** 2))
            # 唇缘不要超出罐口太多，避免两侧出现"尖角"
            r = min(r, mouth_r + bead * 0.85)
        if y <= body_h and belly > 0:
            r *= 1.0 + belly * math.sin(math.pi * min(y, body_h) / body_h) ** 2
        rs[i] = max(r, 1.0)

    for _ in range(3):
        rs = np.convolve(rs, np.array([1.0, 2.0, 1.0], dtype=np.float32) / 4.0, mode="same").astype(np.float32)
    rs = np.maximum(rs, 1.0)
    drs = np.gradient(rs, ys).astype(np.float32)
    kernel = np.array([1.0, 2.0, 1.0], dtype=np.float32) / 4.0
    for _ in range(5):
        drs = np.convolve(drs, kernel, mode="same").astype(np.float32)
    return ys, rs, drs, float(total), float(max(rs.max(), body_r))



def build_glass_profile(p, samples: int = 720):
    """Stemmed glass: foot disc, thin stem, goblet bowl."""
    total = float(p["body_h"])
    bowl_max = p["body_w"] / 2.0
    mouth_r = max(4.0, p["mouth_w"] / 2.0)
    foot_r = bowl_max * 0.52
    foot_h = max(4.0, total * 0.035)
    stem_r = max(2.2, bowl_max * 0.065)
    stem_top = foot_h + total * 0.32
    bowl_end = total

    ys = np.linspace(0.0, total, samples, dtype=np.float32)
    rs = np.empty_like(ys)
    for i in range(samples):
        y = float(ys[i])
        if y < foot_h:
            t = y / max(foot_h, 1e-6)
            k = t * t * (3 - 2 * t)
            r = foot_r * (0.72 + 0.28 * k) - stem_r * 0.0
        elif y < stem_top:
            t = (y - foot_h) / max(stem_top - foot_h, 1e-6)
            blend = min(1.0, t / 0.18)
            r = stem_r + (foot_r - stem_r) * (1 - blend) ** 3 * 0.35
        else:
            t = (y - stem_top) / max(bowl_end - stem_top, 1e-6)
            if t < 0.5:
                k = t / 0.5
                k = k * k * (3 - 2 * k)
                r = stem_r + (bowl_max - stem_r) * k
            else:
                k = (t - 0.5) / 0.5
                k = k * k * (3 - 2 * k)
                r = bowl_max + (mouth_r - bowl_max) * k
        rs[i] = max(r, 1.2)

    for _ in range(2):
        rs = np.convolve(rs, np.array([1.0, 2.0, 1.0], dtype=np.float32) / 4.0, mode="same").astype(np.float32)
    rs = np.maximum(rs, 1.2)
    drs = np.gradient(rs, ys).astype(np.float32)
    return ys, rs, drs, total, float(rs.max())



# --------------------------------------------------------------------------- background
_BG_CACHE = {}


def background(w: int, h: int) -> np.ndarray:
    cached = _BG_CACHE.get((w, h))
    if cached is not None:
        return cached

    top = np.array([255, 248, 240], dtype=np.float32)
    bottom = np.array([233, 216, 201], dtype=np.float32)
    t = np.linspace(0.0, 1.0, h, dtype=np.float32)[:, None, None]
    bg = top[None, None, :] * (1 - t) + bottom[None, None, :] * t
    bg = np.ascontiguousarray(np.broadcast_to(bg, (h, w, 3)))

    yy = np.arange(h, dtype=np.float32)[:, None]
    xx = np.arange(w, dtype=np.float32)[None, :]
    cx, cy = w / 2.0, h * 0.55
    d = np.sqrt(((xx - cx) / (w * 0.68)) ** 2 + ((yy - cy) / (h * 0.68)) ** 2)
    vig = np.clip(1.0 - 0.16 * np.clip(d - 0.3, 0, None) ** 1.6, 0.75, 1.0)
    bg = bg * vig[..., None]

    _BG_CACHE[(w, h)] = bg
    if len(_BG_CACHE) > 8:
        _BG_CACHE.pop(next(iter(_BG_CACHE)))
    return bg




# --------------------------------------------------------------------------- v4 exports
def silhouette_mask(params, size):
    """与 render 相同的几何，返回 0/1 轮廓遮罩（用于透明底导出）"""
    W, H = size
    w, h = int(W), int(H)
    tilt = math.radians(clamp(params["tilt"], 0.0, 42.0))
    ct = math.cos(tilt)
    ys_p, rs_p, drs_p, total, max_r = build_profile(params)
    height_px = max(total * ct, 1.0)
    scale = min((h * 0.78) / height_px, (w * 0.82) / (2 * max_r)) * params.get("_zoom", 1.0)
    base_px = h * 0.89
    cx = w * 0.5
    xs = (np.arange(w, dtype=np.float32) - cx) / scale
    wy = (base_px - np.arange(h, dtype=np.float32)) / scale / max(ct, 1e-3)
    r_row = np.interp(wy, ys_p, rs_p, left=0.0, right=0.0).astype(np.float32)
    mask = (np.abs(xs)[None, :] <= r_row[:, None]).astype(np.uint8) * 255
    return Image.fromarray(mask, "L").filter(ImageFilter.GaussianBlur(1.0))


def export_rgba(params, texture, path, size=(1600, 1400)):
    """透明底导出：用背景差分取 alpha，去掉地面阴影"""
    img = render(params, texture, size, quality=1.0)
    w, h = img.size
    bg = background(w, h)
    arr = np.asarray(img.convert("RGB"), dtype=np.float32)
    diff = np.abs(arr - bg).max(axis=2)
    alpha = np.clip((diff - 7.0) / 14.0, 0.0, 1.0)

    # 去掉底座以下的投影
    tilt = math.radians(clamp(params["tilt"], 0.0, 42.0))
    ys_p, rs_p, drs_p, total, max_r = build_profile(params)
    height_px = max(total * math.cos(tilt), 1.0)
    scale = min((h * 0.78) / height_px, (w * 0.82) / (2 * max_r)) * params.get("_zoom", 1.0)
    base_px = h * 0.89
    cutoff = int(min(h, base_px + max(3.0, 6.0 * scale * 0.02) + 2))
    alpha[cutoff:, :] = 0.0

    a_img = Image.fromarray((alpha * 255).astype(np.uint8), "L").filter(ImageFilter.GaussianBlur(1.2))
    out = img.convert("RGBA")
    out.putalpha(a_img)
    out.save(path)
    return path


def _font(size, bold=False):
    for name in (("msyhbd.ttc", "simhei.ttf") if bold else ("msyh.ttc", "simhei.ttf")):
        try:
            return ImageFont.truetype("C:/Windows/Fonts/" + name, size)
        except Exception:
            continue
    return ImageFont.load_default()


INK = (38, 34, 30)
BLUE_INK = (44, 62, 80)
PAPER_BP = (248, 246, 241)
GRID = (226, 221, 212)
DIM = (150, 92, 66)


def export_blueprint(params, path, size=(2000, 2600)):
    """正视图 + 尺寸标注 + 参数表 + 标题栏"""
    from PIL import ImageDraw
    W, H = size
    img = Image.new("RGB", size, PAPER_BP)
    d = ImageDraw.Draw(img)
    M = 100

    # 网格
    step = 40
    for x in range(M, W - M + 1, step):
        d.line([(x, M), (x, H - M)], fill=GRID, width=1)
    for y in range(M, H - M + 1, step):
        d.line([(M, y), (W - M, y)], fill=GRID, width=1)
    d.rectangle([M, M, W - M, H - M], outline=(210, 204, 194), width=3)

    ys_p, rs_p, drs_p, total, max_r = build_profile(params)
    area_top, area_bottom = 320, 1960
    area_left, area_right = 200, 1160
    scale = min((area_right - area_left) / (2 * max_r * 1.12), (area_bottom - area_top) / (total * 1.06))
    cx = (area_left + area_right) / 2.0
    base = area_bottom

    def px(r, y):
        return (cx + r * scale, base - y * scale)

    pts_l = [px(-r, y) for y, r in zip(ys_p, rs_p)]
    pts_r = [px(r, y) for y, r in zip(ys_p, rs_p)]
    poly = pts_l + pts_r[::-1]
    d.polygon(poly, fill=(238, 233, 225))
    d.line(pts_l, fill=INK, width=4)
    d.line(pts_r, fill=INK, width=4)
    for y, r in zip(ys_p[::max(1, len(ys_p) // 26)], rs_p[::max(1, len(rs_p) // 26)]):
        d.line([px(-r * 0.995, y), px(r * 0.995, y)], fill=(214, 206, 194), width=1)

    # 中心线
    y0, y1 = px(0, 0)[1], px(0, total)[1]
    for yy in range(int(y1), int(y0), 34):
        d.line([(cx, yy), (cx, yy + 18)], fill=(170, 160, 150), width=2)

    def arrow(x1, y1_, x2, y2_):
        d.line([(x1, y1_), (x2, y2_)], fill=DIM, width=2)
        for (ax, ay, bx, by) in ((x1, y1_, x2, y2_), (x2, y2_, x1, y1_)):
            ang = math.atan2(by - ay, bx - ax)
            for s2 in (-0.42, 0.42):
                d.line([(ax, ay), (ax + 16 * math.cos(ang + s2), ay + 16 * math.sin(ang + s2))],
                       fill=DIM, width=2)

    # 底 / 口沿封口线
    d.line([pts_l[0], pts_r[0]], fill=INK, width=4)
    d.line([pts_l[-1], pts_r[-1]], fill=INK, width=4)

    # 高度（标尺放内侧）
    hx = cx - max_r * scale - 52
    arrow(hx, px(0, 0)[1], hx, px(0, total)[1])
    d.text((hx + 30, (px(0, 0)[1] + px(0, total)[1]) / 2), "H = %.1f mm" % total,
           font=_font(32, True), fill=DIM, anchor="lm")
    # 直径
    dy = px(0, 0)[1] + 96
    arrow(cx - max_r * scale, dy, cx + max_r * scale, dy)
    d.text((cx, dy + 22), "D = %.1f mm" % (2 * max_r), font=_font(32, True), fill=DIM, anchor="ma")

    # 标题
    d.text((M + 30, M + 24), "JAR STUDIO  ·  FRONT ELEVATION", font=_font(40, True), fill=BLUE_INK)
    d.text((M + 30, M + 78), "参数化罐体设计器 · 正视图与尺寸", font=_font(26), fill=(120, 112, 104))

    # 右侧参数表
    tx = 1300
    ty = 330
    d.text((tx, ty), "PARAMETERS", font=_font(30, True), fill=BLUE_INK)
    d.line([(tx, ty + 46), (W - M - 30, ty + 46)], fill=(200, 194, 184), width=2)
    ty += 66
    for key, label, lo, hi, dv, res, unit in BODY_SPECS:
        v = params.get(key, dv)
        d.text((tx, ty), label, font=_font(26), fill=(96, 90, 84))
        txt = ("%.2f" % v) if res < 0.1 else ("%.1f" % v if res < 1 else "%.0f" % v)
        d.text((W - M - 60, ty), txt + (" " + unit if unit else ""), font=_font(26, True),
               fill=INK, anchor="ra")
        ty += 46

    d = ImageDraw.Draw(img)
    phi = 1.6180339887
    d.line([(tx, ty + 10), (W - M - 30, ty + 10)], fill=(200, 194, 184), width=2)
    ty += 34
    d.text((tx, ty), "RATIOS", font=_font(30, True), fill=BLUE_INK)
    ty += 52
    ratios = [("H / D", params["body_h"] / max(params["body_w"], 1e-6), phi),
              ("neck / D", params["neck_w"] / max(params["body_w"], 1e-6), 1 / phi),
              ("shoulder / H", params["shoulder_h"] / max(params["body_h"], 1e-6), 1 / phi ** 3)]
    for name, val, target in ratios:
        d.text((tx, ty), name, font=_font(26), fill=(96, 90, 84))
        d.text((W - M - 190, ty), "%.3f" % val, font=_font(26, True), fill=INK, anchor="ra")
        d.text((W - M - 60, ty + 2), "phi %.3f" % target, font=_font(22), fill=DIM, anchor="ra")
        ty += 44

    # 标题栏
    bar_y = H - 250
    d.rectangle([M, bar_y, W - M, H - M], outline=(200, 194, 184), width=2)
    d.text((M + 30, bar_y + 26), "PROJECT", font=_font(24), fill=(120, 112, 104))
    d.text((M + 30, bar_y + 62), "PHI JAR / PARAMETRIC VESSEL", font=_font(32, True), fill=INK)
    d.text((M + 760, bar_y + 26), "SCALE", font=_font(24), fill=(120, 112, 104))
    d.text((M + 760, bar_y + 62), "1 : 2", font=_font(32, True), fill=INK)
    d.text((M + 1000, bar_y + 26), "DRAWN", font=_font(24), fill=(120, 112, 104))
    d.text((M + 1000, bar_y + 62), "2025 · ZHANG YONGHANG", font=_font(30), fill=INK)

    img.save(path)
    return path


def export_matrix(params, texture, path, cols=4, rows=3):
    """参数矩阵：横轴颈高、纵轴腹部鼓起，一格一个变体"""
    cell_w, cell_h = 430, 560
    pad, top = 40, 190
    W = pad * 2 + cols * cell_w
    H = top + rows * cell_h + 80
    img = Image.new("RGB", (W, H), PAPER_BP)
    from PIL import ImageDraw
    d = ImageDraw.Draw(img)
    d.text((pad, 54), "PARAMETER MATRIX", font=_font(48, True), fill=BLUE_INK)
    d.text((pad, 118), "颈高 × 腹部鼓起 · 同一比例系统下的 12 个变体",
           font=_font(26), fill=(120, 112, 104))

    neck_vals = [params["neck_h"] * f for f in (0.6, 0.9, 1.2, 1.5)]
    belly_vals = [max(0.0, params["belly"] + dlt) for dlt in (-0.03, 0.03, 0.09)]
    for r, belly in enumerate(belly_vals):
        for c, neck in enumerate(neck_vals):
            vp = dict(params)
            vp["neck_h"] = neck
            vp["belly"] = clamp(belly, 0.0, 0.24)
            tile = render(vp, texture, (cell_w - 24, cell_h - 96), quality=1.0)
            x = pad + c * cell_w + 12
            y = top + r * cell_h + 8
            img.paste(tile, (x, y))
            d.rectangle([x, y, x + tile.width, y + tile.height], outline=(216, 210, 200), width=2)
            d.text((x + 4, y + tile.height + 10),
                   "neck %.0f  ·  belly %.2f" % (neck, vp["belly"]),
                   font=_font(20), fill=(110, 104, 96))
    img.save(path)
    return path


_PROFILE_CACHE = {}


def build_profile(p, samples: int = 720):
    key = tuple(sorted((k, round(float(v), 4)) for k, v in p.items()
                       if isinstance(v, (int, float)) and not k.startswith("_"))) + (samples,)
    hit = _PROFILE_CACHE.get(key)
    if hit is not None:
        return hit
    ys, rs, drs, total, max_r = build_profile_raw(p, samples)
    rs = smooth_curve(rs, 3)
    drs = np.gradient(rs)
    out = (ys, rs, drs, total, max_r)
    if len(_PROFILE_CACHE) > 64:
        _PROFILE_CACHE.clear()
    _PROFILE_CACHE[key] = out
    return out


# --------------------------------------------------------------------------- render
LIGHT = np.array([-0.45, 0.52, 0.72], dtype=np.float32)
LIGHT /= np.linalg.norm(LIGHT)
HALF = LIGHT + np.array([0.0, 0.0, 1.0], dtype=np.float32)
HALF /= np.linalg.norm(HALF)
RIM = np.array([1.0, 0.95, 0.86], dtype=np.float32)

MATERIALS = {
    "glaze": dict(amb=0.58, diff=0.46, spec_pow=26, spec_str=95.0, fres=26.0, trans=0.0, metal=0.0),
    "matte": dict(amb=0.70, diff=0.34, spec_pow=7, spec_str=14.0, fres=6.0, trans=0.0, metal=0.0),
    "frost": dict(amb=0.30, diff=0.28, spec_pow=12, spec_str=55.0, fres=90.0, trans=0.22, metal=0.0),
    "glass": dict(amb=0.08, diff=0.12, spec_pow=80, spec_str=260.0, fres=170.0, trans=0.66, metal=0.0),
    "metal": dict(amb=0.30, diff=0.22, spec_pow=70, spec_str=190.0, fres=24.0, trans=0.0, metal=1.0),
}

MAT_NAMES = [("glaze", "釉面"), ("matte", "哑光"), ("frost", "磨砂"), ("glass", "玻璃"), ("metal", "金属")]


def light_vector(az_deg, el_deg):
    az = math.radians(az_deg)
    el = math.radians(max(4.0, min(86.0, el_deg)))
    x = math.sin(az) * math.cos(el)
    y = math.sin(el)
    z = math.cos(az) * math.cos(el)
    v = np.array([x, y, z], dtype=np.float32)
    return v / np.linalg.norm(v)


def render(params, texture, size, quality=1.0, bg_color=None) -> Image.Image:
    W, H = size
    q = clamp(quality, 0.25, 1.0)
    w = max(80, int(round(W * q)))
    h = max(80, int(round(H * q)))

    tilt = math.radians(clamp(params["tilt"], 0.0, 42.0))
    spin = math.radians(params["spin"] % 360.0)
    ct, st = math.cos(tilt), math.sin(tilt)

    ys_p, rs_p, drs_p, total, max_r = build_profile(params)
    height_px = max(total * ct, 1.0)
    scale = min((h * 0.78) / height_px, (w * 0.82) / (2 * max_r)) * params.get("_zoom", 1.0)
    base_px = h * 0.89
    cx = w * 0.5

    xs = (np.arange(w, dtype=np.float32) - cx) / scale
    rows = np.arange(h, dtype=np.float32)
    wy = (base_px - rows) / scale / max(ct, 1e-3)

    r_row = np.interp(wy, ys_p, rs_p, left=0.0, right=0.0).astype(np.float32)
    dr_row = np.interp(wy, ys_p, drs_p, left=0.0, right=0.0).astype(np.float32)
    r_row *= ((wy >= 0.0) & (wy <= total)).astype(np.float32)

    # ---- 透视：越靠近镜头（高处）越大，越远越小
    persp = float(params.get("persp", 0.55))
    pf = 1.0 + (wy - total * 0.5) / max(total, 1e-3) * (persp * 0.55) * math.sin(tilt)
    pf = np.clip(pf, 0.62, 1.55).astype(np.float32)
    r_row = r_row * pf

    if bg_color is None:
        out = background(w, h).copy()
    else:
        out = np.empty((h, w, 3), dtype=np.float32)
        out[:] = bg_color

    valid = np.flatnonzero(r_row > 0.5)
    if valid.size:
        r0, r1 = int(valid[0]), int(valid[-1]) + 1
        c0 = max(0, int(np.searchsorted(xs, -max_r, side="left")) - 1)
        c1 = min(w, int(np.searchsorted(xs, max_r, side="right")) + 1)

        base_y = base_px
        band0 = max(0, int(base_y - max_r * scale * 0.55))
        band1 = min(h, int(base_y + max_r * scale * 0.32))
        if band1 > band0:
            sx = (xs[c0:c1] - cx) / (max_r * scale * 1.5)
            sy = (np.arange(band0, band1, dtype=np.float32) - base_y) / (max_r * scale * 0.15)
            sh = np.exp(-(sx[None, :] ** 2 + sy[:, None] ** 2) * 2.3) * 0.32
            out[band0:band1, c0:c1] *= (1.0 - sh[..., None])

        X = (xs[c0:c1][None, :] / pf[r0:r1][:, None])
        Y = wy[r0:r1][:, None]
        R = r_row[r0:r1][:, None]
        DR = dr_row[r0:r1][:, None]

        inside = np.abs(X) <= R
        Z = np.sqrt(np.maximum(R * R - X * X, 0.0)) + 1e-5

        nx = X * 1.0
        ny = -R * DR
        nz = Z * 1.0
        inv = 1.0 / np.sqrt(nx * nx + ny * ny + nz * nz)
        nx = nx * inv
        ny = ny * inv
        nz = nz * inv

        mat = MATERIALS.get(params.get("material", "glaze"), MATERIALS["glaze"])
        power = float(params.get("light_power", 1.0))
        L = light_vector(params.get("light_az", 315.0), params.get("light_el", 45.0))
        Hv = L + np.array([0.0, 0.0, 1.0], dtype=np.float32)
        Hv /= np.linalg.norm(Hv)

        amb = float(params.get("ambient", 0.55))
        diff = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0.0, 1.0) * power
        spec = np.clip(nx * Hv[0] + ny * Hv[1] + nz * Hv[2], 0.0, 1.0) ** mat["spec_pow"]
        spec = spec * mat["spec_str"] * power
        fres = np.clip(1.0 - nz, 0.0, 1.0) ** 3 * mat["fres"]

        u = np.arctan2(X, Z) * (0.5 / math.pi) + 0.5 - spin * (0.5 / math.pi)
        u = u % 1.0
        v = np.clip(Y / total, 0.0, 0.999)
        ti = np.clip((u * TEX_W).astype(np.int32), 0, TEX_W - 1)
        tj = np.clip(((1.0 - v) * TEX_H).astype(np.int32), 0, TEX_H - 1)
        base = texture[tj, ti]
        _bh = params.get("body_hex")
        if _bh:
            _c = _bh.lstrip("#")
            _tint = np.array([int(_c[0:2], 16), int(_c[2:4], 16), int(_c[4:6], 16)],
                             dtype=np.float32) / 255.0
            base = base * _tint

        if params.get("wire"):
            fu = (u * 24.0) % 1.0
            fv = (v * 20.0) % 1.0
            grid = ((np.abs(fu - 0.5) > 0.482) | (np.abs(fv - 0.5) > 0.486))
            wire_mix = np.where(grid, 0.45, 1.0)[..., None]
        else:
            wire_mix = 1.0

        bg_block = out[r0:r1, c0:c1].copy()
        if mat["metal"] > 0.5:
            col = base * 0.62 * (mat["amb"] + mat["diff"] * diff)[..., None]
            col += spec[..., None] * (0.45 + 0.45 * base / 255.0)
            col += fres[..., None] * base * 0.35
            col += bg_block * 0.20
        else:
            col = base * ((mat["amb"] * amb / 0.55) + mat["diff"] * diff)[..., None]
            col += spec[..., None]
            col += fres[..., None] * RIM * 0.6
        if mat["trans"] > 0:
            t = mat["trans"]
            col = col * (1.0 - t) + bg_block * t

        # 边缘压暗（伪 AO）+ 底部反弹光
        edge_ao = np.clip((R - np.abs(X)) * scale, 0.0, 1.0)
        ao = 1.0 - 0.28 * (1.0 - edge_ao) ** 2
        col = col * ao[..., None]
        bounce = np.clip(-ny, 0.0, 1.0) ** 2 * 26.0
        col = col + bounce[..., None] * base / 255.0

        if params.get("wire"):
            col = col * wire_mix
        edge = np.clip((R - np.abs(X)) * scale, 0.0, 1.0)
        alpha = np.where(inside, edge, 0.0)[..., None]
        if mat["trans"] > 0:
            alpha = alpha * (1.0 - mat["trans"] * 0.35)

        block = out[r0:r1, c0:c1]
        block *= (1.0 - alpha)
        block += col * alpha
        out[r0:r1, c0:c1] = block

    # ---- 罐口：内壁 + 唇环 + 高光 + 唇下阴影（局部小图，快）
    rx = (params["mouth_w"] / 2.0) * scale * 0.96 * float(pf[-1])
    ry = max(rx * st, rx * 0.09)
    if rx > 6.0 and ry > 1.2:
        y_top = base_px - total * ct * scale
        bx0 = max(0, int(cx - rx * 1.35))
        bx1 = min(w, int(cx + rx * 1.35) + 1)
        by0 = max(0, int(y_top - ry * 1.5))
        by1 = min(h, int(y_top + ry * 2.8) + 1)
        bw, bh = bx1 - bx0, by1 - by0
        if bw > 6 and bh > 6:
            over = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
            od = ImageDraw.Draw(over)
            ox, oy = cx - bx0, y_top - by0
            lip = max(2, int(round(rx * 0.05)))

            _mh = params.get("mouth_hex", "#F7F0E5").lstrip("#")
            _lip = np.array([int(_mh[0:2], 16), int(_mh[2:4], 16), int(_mh[4:6], 16)],
                            dtype=np.float32)
            _deep = np.clip(_lip * 0.18 + np.array([26, 18, 14]) * 0.5, 0, 255)
            _mid = np.clip(_lip * 0.30 + np.array([30, 20, 16]) * 0.5, 0, 255)
            _hi = np.clip(_lip * 0.44 + np.array([34, 22, 16]) * 0.5, 0, 255)
            _sp = np.clip(_lip * 0.72 + 60, 0, 255)

            od.ellipse([ox - rx, oy - ry, ox + rx, oy + ry],
                       fill=tuple(int(v) for v in _deep) + (255,))
            od.ellipse([ox - rx * 0.88, oy - ry * 0.86, ox + rx * 0.88, oy + ry * 0.86],
                       fill=tuple(int(v) for v in _mid) + (255,))
            od.ellipse([ox - rx * 0.72, oy - ry * 0.72, ox + rx * 0.72, oy + ry * 0.72],
                       fill=tuple(int(v) for v in _hi) + (255,))
            od.arc([ox - rx * 0.70, oy - ry * 0.70, ox + rx * 0.70, oy + ry * 0.70],
                   205, 335, fill=tuple(int(v) for v in _sp) + (200,), width=max(1, lip // 2))

            od.ellipse([ox - rx, oy - ry, ox + rx, oy + ry],
                       outline=tuple(int(v) for v in _lip) + (255,), width=lip)
            od.arc([ox - rx, oy - ry, ox + rx, oy + ry], 196, 344,
                   fill=tuple(int(min(255, v * 1.12)) for v in _lip) + (240,),
                   width=max(1, lip // 2))

            arr = np.asarray(over, dtype=np.float32)
            a = arr[..., 3:4] / 255.0
            sub = out[by0:by1, bx0:bx1]
            out[by0:by1, bx0:bx1] = sub * (1.0 - a) + arr[..., :3] * a

            # 唇下阴影：局部小图 + 模糊
            sh = Image.new("L", (bw, bh), 0)
            ImageDraw.Draw(sh).ellipse(
                [ox - rx * 1.0, oy + ry * 0.5, ox + rx * 1.0, oy + ry * 0.5 + max(4.0, ry * 1.4)],
                fill=95)
            sh = sh.filter(ImageFilter.GaussianBlur(max(1.0, ry * 0.45)))
            shade = np.asarray(sh, dtype=np.float32)[..., None] / 255.0 * 0.42
            sub = out[by0:by1, bx0:bx1]
            out[by0:by1, bx0:bx1] = sub * (1.0 - shade)

    img = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8), "RGB")
    if (w, h) != (W, H):
        img = img.resize((W, H), Image.BICUBIC)
    return img


# --------------------------------------------------------------------------- slider
class Slider(tk.Canvas):
    def __init__(self, master, lo, hi, value, res=1.0, command=None, height=14):
        super().__init__(master, height=height, bg=PANEL, highlightthickness=0, bd=0,
                         cursor="hand2")
        self.lo, self.hi, self.res = float(lo), float(hi), float(res)
        self.value = float(value)
        self.command = command
        self.bind("<Configure>", lambda _e: self._draw())
        self.bind("<Button-1>", self._on_event)
        self.bind("<B1-Motion>", self._on_event)

    def set(self, v, notify=False):
        self.value = clamp(round(float(v) / self.res) * self.res, self.lo, self.hi)
        self._draw()
        if notify and self.command:
            self.command(self.value)

    def get(self):
        return self.value

    def _on_event(self, event):
        pad = 9
        w = max(1, self.winfo_width() - 2 * pad)
        t = clamp((event.x - pad) / w, 0.0, 1.0)
        v = clamp(round((self.lo + t * (self.hi - self.lo)) / self.res) * self.res, self.lo, self.hi)
        if abs(v - self.value) < 1e-9:
            return
        self.value = v
        self._draw()
        if self.command:
            self.command(v)

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 24:
            return
        pad, cy = 9, h // 2
        t = (self.value - self.lo) / max(self.hi - self.lo, 1e-9)
        x = pad + t * (w - 2 * pad)
        self.create_line(pad, cy, w - pad, cy, width=4, fill="#E2D0BF", capstyle="round")
        if x > pad + 2:
            self.create_line(pad, cy, x, cy, width=4, fill=ACCENT, capstyle="round")
        r = 6
        self.create_oval(x - r, cy - r, x + r, cy + r, fill="#FFFDFA", outline=ACCENT, width=2)



class ScrollPane(tk.Frame):
    """Vertical scrolling container with a slim scrollbar."""

    def __init__(self, master, width, bg=PANEL):
        super().__init__(master, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, width=width - 16)
        self.vsb = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview,
                                width=10, bd=0, relief="flat", bg="#DCC6B4",
                                troughcolor="#F6EBE1", activebackground=ACCENT)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vsb.pack(side="right", fill="y")
        self.inner = tk.Frame(self.canvas, bg=bg)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw",
                                              width=width - 24)
        self.inner.bind("<Configure>", self._on_inner)
        self.canvas.bind_all("<MouseWheel>", self._on_wheel, add="+")

    def _on_inner(self, _event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_wheel(self, event):
        widget = self.winfo_containing(event.x_root, event.y_root)
        if widget is None:
            return
        parent = widget
        while parent is not None:
            if parent is self:
                self.canvas.yview_scroll(-1 * int(event.delta / 120), "units")
                return
            parent = getattr(parent, "master", None)



# --------------------------------------------------------------------------- app
class JarStudio:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.params = {k: d for k, _, _, _, d, _, _ in SPECS}
        self.params["kind"] = "jar"
        self.params["wire"] = False
        self.params["material"] = "glaze"
        self.params["light_az"] = 315.0
        self.params["light_el"] = 45.0
        self.params["light_power"] = 1.0
        self.paint = np.zeros((TEX_H, TEX_W, 4), dtype=np.uint8)
        self.base_color = np.array([247, 241, 232], dtype=np.float32)
        self.texture = np.zeros((TEX_H, TEX_W, 3), dtype=np.float32)
        self._compose_texture()

        self.brush_color = "#C9ADA7"
        self.color_target = "brush"
        self.brush_size = 24
        self.tool = "soft"
        self.undo_stack = []
        self._render_job = None
        self._hi_job = None
        self._resize_job = None
        self.last_image = None
        self.bg_style = 0
        self._bg_for_render = None
        self._photo = None
        self._profile = build_profile(self.params)
        self._orbit = None

        root.title("JAR STUDIO · 参数化罐体设计")
        root.configure(bg=BG)
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        win_w, win_h = min(1200, sw - 120), min(770, sh - 120)
        root.geometry("%dx%d+%d+%d" % (win_w, win_h,
                                      max(20, (sw - win_w) // 2), max(16, (sh - win_h) // 3)))
        root.minsize(1040, 700)
        self._dark_title_bar()

        self._build_ui()
        self._refresh_materials()
        root.after(50, lambda: self.render_now(1.0))
        root.after(120, self._bind_canvas_events)

    def _dark_title_bar(self):
        if os.name != "nt":
            return
        try:
            import ctypes

            self.root.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            value = ctypes.c_int(1)
            for attr in (20, 19):
                ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(value), 4)
        except Exception:
            pass

    # ---------------- ui
    def _build_ui(self):
        outer = tk.Frame(self.root, bg=BG)
        outer.pack(fill="both", expand=True, padx=14, pady=12)

        left = tk.Frame(outer, bg=PANEL, width=318)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        head = tk.Frame(left, bg=PANEL)
        head.pack(fill="x", padx=16, pady=(10, 2))
        tk.Label(head, text="JAR STUDIO", bg=PANEL, fg=TEXT,
                 font=(FONT, 14, "bold")).pack(anchor="w")
        tk.Label(head, text="参数化罐体设计器", bg=PANEL, fg=MUTED,
                 font=(FONT, 8)).pack(anchor="w")

        save_row = tk.Frame(left, bg=PANEL)
        self.save_row = save_row
        save_row.pack(side="bottom", fill="x", padx=16, pady=(6, 10))
        tk.Button(save_row, text="渲染预览", bg=ACCENT, fg="#FFF9F2", bd=0, relief="flat",
                  activebackground="#9C7657", activeforeground="#FFF9F2",
                  font=(FONT, 9, "bold"), pady=5, cursor="hand2",
                  command=self.show_render).pack(side="left", fill="x", expand=True, padx=(0, 3))
        tk.Button(save_row, text="保存图", bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                  activebackground=LINE, activeforeground=TEXT, font=(FONT, 8), pady=5,
                  cursor="hand2", command=self.save_preview).pack(side="left", fill="x", expand=True, padx=(0, 3))
        tk.Button(save_row, text="导出", bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                  activebackground=LINE, activeforeground=TEXT, font=(FONT, 8), pady=5,
                  cursor="hand2", command=self.export_assets).pack(side="left", fill="x", expand=True)


        tbar2 = tk.Frame(left, bg=PANEL)
        tbar2.pack(side="bottom", fill="x", padx=16, pady=(0, 4))
        for text, cmd in (("蓝图", self.export_blueprint_ui), ("矩阵", self.export_matrix_ui),
                          ("透明底", self.export_rgba_ui), ("φ 锁定", self.phi_snap),
                          ("存参", self.save_params), ("读参", self.load_params)):
            tk.Button(tbar2, text=text, bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                      activebackground=LINE, activeforeground=TEXT, font=(FONT, 8), pady=4,
                      cursor="hand2", command=cmd).pack(side="left", fill="x", expand=True, padx=1)

        tbar3 = tk.Frame(left, bg=PANEL)
        tbar3.pack(side="bottom", fill="x", padx=16, pady=(0, 3))
        for text, cmd in (("重置视角", self.reset_view), ("换背景", self.cycle_bg),
                          ("存场景", self.save_scene)):
            tk.Button(tbar3, text=text, bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                      activebackground=LINE, activeforeground=TEXT, font=(FONT, 8), pady=4,
                      cursor="hand2", command=cmd).pack(side="left", fill="x", expand=True, padx=1)

        pane = ScrollPane(left, 318, PANEL)
        pane.pack(fill="both", expand=True, padx=(12, 2), pady=(4, 0))
        body = tk.Frame(pane.inner, bg=PANEL)
        body.pack(fill="both", expand=True, padx=8, pady=(2, 6))

        self.scale_widgets = {}
        preset_row = tk.Frame(body, bg=PANEL)
        preset_row.pack(fill="x")
        tk.Label(preset_row, text="样式", bg=PANEL, fg=ACCENT,
                 font=(FONT, 8, "bold")).pack(side="left", padx=(0, 6))
        grid = tk.Frame(preset_row, bg=PANEL)
        grid.pack(side="left", fill="x", expand=True)
        names = list(PRESETS)
        for idx, name in enumerate(names):
            tk.Button(grid, text=name, bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                      activebackground=LINE, activeforeground=TEXT, font=(FONT, 8),
                      padx=6, pady=2, cursor="hand2",
                      command=lambda n=name: self.apply_preset(n)).grid(
                row=idx // 3, column=idx % 3, sticky="ew", padx=1, pady=1)
        for c in range(3):
            grid.columnconfigure(c, weight=1)

        tk.Frame(body, bg=LINE, height=1).pack(fill="x", pady=(6, 4))
        for spec in BODY_SPECS:
            self._add_slider(body, *spec)

        tk.Frame(body, bg=LINE, height=1).pack(fill="x", pady=(5, 3))
        for spec in VIEW_SPECS:
            self._add_slider(body, *spec)

        mat_row = tk.Frame(body, bg=PANEL)
        mat_row.pack(fill="x", pady=(4, 0))
        tk.Label(mat_row, text="材质", bg=PANEL, fg=ACCENT,
                 font=(FONT, 8, "bold")).pack(side="left", padx=(0, 6))
        self.mat_buttons = {}
        for key, label in MAT_NAMES:
            b = tk.Button(mat_row, text=label, bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                          activebackground=LINE, activeforeground=TEXT, font=(FONT, 8),
                          padx=5, pady=2, cursor="hand2",
                          command=lambda k=key: self.set_material(k))
            b.pack(side="left", padx=(0, 3))
            self.mat_buttons[key] = b

        self.wire_var = tk.BooleanVar(value=False)
        tk.Checkbutton(body, text="显示建模布线", variable=self.wire_var,
                       command=self.toggle_wire, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                       activebackground=PANEL, activeforeground=TEXT, bd=0,
                       highlightthickness=0, font=(FONT, 8)).pack(anchor="w", pady=(2, 0))

        tk.Frame(body, bg=LINE, height=1).pack(fill="x", pady=(6, 4))
        tk.Frame(body, bg=LINE, height=1).pack(fill="x", pady=(7, 4))
        tgt = tk.Frame(body, bg=PANEL)
        tgt.pack(fill="x", pady=(2, 0))
        tk.Label(tgt, text="配色对象", bg=PANEL, fg=MUTED,
                 font=(FONT, 8)).pack(side="left", padx=(0, 6))
        self.target_buttons = {}
        for key, label in (("body", "罐身"), ("mouth", "罐口"), ("brush", "画笔")):
            b = tk.Button(tgt, text=label, bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                          activebackground=LINE, activeforeground=TEXT, font=(FONT, 8),
                          padx=6, pady=1, cursor="hand2",
                          command=lambda k=key: self.set_target(k))
            b.pack(side="left", padx=(0, 4))
            self.target_buttons[key] = b

        sw = tk.Frame(body, bg=PANEL)
        sw.pack(fill="x", pady=(3, 0))
        self.swatch_label = tk.Label(sw, text="配色 · 画笔", bg=PANEL, fg=ACCENT,
                                     font=(FONT, 8, "bold"))
        self.swatch_label.pack(side="left", padx=(0, 6))
        for hexc, _name in SWATCHES:
            tk.Button(sw, bg=hexc, width=2, height=1, bd=0, relief="flat", cursor="hand2",
                      command=lambda c=hexc: self.set_color(c)).pack(side="left", padx=(0, 3))

        tools = tk.Frame(body, bg=PANEL)
        tools.pack(fill="x", pady=(4, 0))
        self.tool_buttons = {}
        for key, label in (("soft", "圆笔"), ("hard", "硬笔"), ("spray", "喷笔"), ("eraser", "橡皮")):
            b = tk.Button(tools, text=label, bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                          activebackground=LINE, activeforeground=TEXT, font=(FONT, 8),
                          padx=5, pady=2, cursor="hand2",
                          command=lambda k=key: self.set_tool(k))
            b.pack(side="left", padx=(0, 4))
            self.tool_buttons[key] = b
        self._refresh_tools()
        self.set_target("body")
        self.brush_scale = Slider(tools, 4, 64, self.brush_size, 1.0,
                                  command=self.on_brush, height=16)
        self.brush_scale.pack(side="left", fill="x", expand=True, padx=(4, 0))

        actions = tk.Frame(body, bg=PANEL)
        actions.pack(fill="x", pady=(4, 0))
        for label, cmd in (("撤销", self.undo), ("清空", self.clear_paint), ("重置视角", self.reset_view)):
            tk.Button(actions, text=label, bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                      activebackground=LINE, activeforeground=TEXT, font=(FONT, 8),
                      padx=7, pady=2, cursor="hand2", command=cmd).pack(side="left", padx=(0, 4))

        right = tk.Frame(outer, bg=BG)
        right.pack(side="left", fill="both", expand=True, padx=(14, 0))

        self.canvas = tk.Canvas(right, bg=BG, highlightthickness=0, cursor="crosshair")
        self.canvas.pack(fill="both", expand=True)

        status = tk.Frame(right, bg=BG)
        status.pack(fill="x", pady=(7, 0))
        self.status_var = tk.StringVar(value="就绪")
        tk.Label(status, textvariable=self.status_var, bg=BG, fg=MUTED,
                 font=(FONT, 9)).pack(side="left")
        self.size_var = tk.StringVar(value="")
        tk.Label(status, textvariable=self.size_var, bg=BG, fg=MUTED,
                 font=(FONT, 9)).pack(side="right")

    def _add_slider(self, parent, key, label, lo, hi, default, res, unit):
        wrap = tk.Frame(parent, bg=PANEL)
        wrap.pack(fill="x", pady=(0, 0))
        top = tk.Frame(wrap, bg=PANEL)
        top.pack(fill="x")
        tk.Label(top, text=label, bg=PANEL, fg=TEXT, font=(FONT, 9)).pack(side="left")
        val = tk.StringVar()
        tk.Label(top, textvariable=val, bg=PANEL, fg=ACCENT_2,
                 font=("Consolas", 9)).pack(side="right")

        sld = Slider(wrap, lo, hi, self.params[key], res,
                     command=lambda v, k=key: self.on_param(k, v))
        sld.pack(fill="x", pady=(1, 0))
        sld.bind("<ButtonRelease-1>", lambda _e: self.render_now(1.0))
        self.scale_widgets[key] = (sld, val, unit, res)
        val.set(self._fmt(self.params[key], res, unit))

    @staticmethod
    def _fmt(value, res, unit):
        text = ("%.2f" % value) if res < 0.1 else ("%.1f" % value if res < 1 else "%d" % value)
        return (text + " " + unit).strip()

    # ---------------- state
    def _compose_texture(self):
        alpha = self.paint[..., 3:4].astype(np.float32) / 255.0
        rgb = self.paint[..., :3].astype(np.float32)
        base = self.base_color[None, None, :]
        self.texture = np.clip(rgb * alpha + base * (1.0 - alpha), 0, 255)

    def on_param(self, key, value):
        self.params[key] = float(value)
        sld, val, unit, res = self.scale_widgets[key]
        val.set(self._fmt(float(value), res, unit))
        self._profile = build_profile(self.params)
        self.schedule_render()

    def on_brush(self, value):
        self.brush_size = int(float(value))

    def set_target(self, key):
        self.color_target = key
        for k, b in getattr(self, "target_buttons", {}).items():
            b.configure(bg=ACCENT if k == key else PANEL_2,
                        fg="#FFF9F2" if k == key else TEXT)
        label = {"brush": "画笔", "body": "罐身", "mouth": "罐口"}[key]
        if hasattr(self, "swatch_label"):
            self.swatch_label.configure(text="配色 · " + label)

    def set_color(self, hexc):
        if self.color_target == "body":
            self.params["body_hex"] = hexc
            self.render_now(1.0)
            self.status_var.set("罐身配色：" + hexc)
            return
        if self.color_target == "mouth":
            self.params["mouth_hex"] = hexc
            self.render_now(1.0)
            self.status_var.set("罐口配色：" + hexc)
            return
        self.brush_color = hexc
        if self.tool == "eraser":
            self.tool = "soft"
        self._refresh_tools()

    def set_tool(self, tool):
        self.tool = tool
        self._refresh_tools()

    def _refresh_tools(self):
        for key, btn in self.tool_buttons.items():
            active = key == self.tool
            btn.configure(bg=ACCENT if active else PANEL_2,
                          fg="#FFF9F2" if active else TEXT)

    def apply_preset(self, name):
        preset = PRESETS[name]
        self.params["kind"] = preset.get("kind", "jar")
        for k, v in preset.items():
            if k == "kind":
                continue
            self.params[k] = float(v)
            sld, val, unit, res = self.scale_widgets[k]
            sld.set(v)
            val.set(self._fmt(float(v), res, unit))
        self._profile = build_profile(self.params)
        self.render_now(1.0)

    def reset_view(self):
        self.apply_preset_values({"tilt": 12.0, "spin": 0.0})

    def apply_preset_values(self, values):
        for k, v in values.items():
            self.params[k] = float(v)
            sld, val, unit, res = self.scale_widgets[k]
            sld.set(v)
            val.set(self._fmt(float(v), res, unit))
        self.render_now(1.0)

    def set_material(self, key):
        self.params["material"] = key
        self._refresh_materials()
        self.render_now(0.75)
        self.root.after(160, lambda: self.render_now(1.0))

    def _refresh_materials(self):
        current = self.params.get("material", "glaze")
        for key, btn in getattr(self, "mat_buttons", {}).items():
            active = key == current
            btn.configure(bg=ACCENT if active else PANEL_2,
                          fg="#FFF9F2" if active else TEXT)

    def toggle_wire(self):
        self.params["wire"] = bool(self.wire_var.get())
        self.render_now(1.0)

    def show_render(self):
        img = render(self.params, self.texture, (1500, 1280), quality=1.0)
        win = tk.Toplevel(self.root)
        win.title("渲染预览")
        win.configure(bg=BG)
        photo = ImageTk.PhotoImage(img.resize((900, 768), Image.LANCZOS))
        label = tk.Label(win, image=photo, bg=BG)
        label.image = photo
        label.pack(padx=14, pady=14)

        bar = tk.Frame(win, bg=BG)
        bar.pack(pady=(0, 14))

        def save():
            path = filedialog.asksaveasfilename(
                title="保存渲染图", defaultextension=".png", initialfile="jar_render.png",
                filetypes=[("PNG 图片", "*.png"), ("JPEG 图片", "*.jpg")])
            if not path:
                return
            if path.lower().endswith((".jpg", ".jpeg")):
                img.save(path, quality=95)
            else:
                img.save(path)

        tk.Button(bar, text="保存这张图", bg=ACCENT, fg="#FFF9F2", bd=0, relief="flat",
                  font=(FONT, 9, "bold"), padx=16, pady=5, cursor="hand2",
                  command=save).pack(side="left", padx=6)
        tk.Button(bar, text="关闭", bg=PANEL_2, fg=TEXT, bd=0, relief="flat",
                  font=(FONT, 9), padx=16, pady=5, cursor="hand2",
                  command=win.destroy).pack(side="left", padx=6)

    def undo(self):
        if not self.undo_stack:
            return
        self.paint = self.undo_stack.pop()
        self._compose_texture()
        self.render_now(1.0)

    def clear_paint(self):
        self._push_undo()
        self.paint[:] = 0
        self._compose_texture()
        self.render_now(1.0)

    def _push_undo(self):
        self.undo_stack.append(self.paint.copy())
        if len(self.undo_stack) > 16:
            self.undo_stack.pop(0)

    # ---------------- rendering
    def schedule_render(self):
        if self._render_job is not None:
            self.root.after_cancel(self._render_job)
        if self._hi_job is not None:
            self.root.after_cancel(self._hi_job)
        self._render_job = self.root.after(8, lambda: self.render_now(0.42))
        self._hi_job = self.root.after(200, lambda: self.render_now(1.0))

    def render_now(self, quality=1.0):
        self._render_job = None
        self._hi_job = None
        w = max(320, self.canvas.winfo_width())
        h = max(320, self.canvas.winfo_height())
        # 内部渲染像素上限，超过就降分辨率再放大，拖动时更跟手
        cap = 780
        iw, ih = w, h
        if w > cap:
            r = cap / float(w)
            iw, ih = int(w * r), int(h * r)
        t0 = time.perf_counter()
        bg = self._bg_for_render
        img = render(self.params, self.texture, (iw, ih), quality=quality,
                     bg_color=bg)
        if (iw, ih) != (w, h):
            img = img.resize((w, h), Image.BILINEAR)
        dt = (time.perf_counter() - t0) * 1000.0
        self.last_image = img
        self._photo = ImageTk.PhotoImage(img)
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=self._photo)
        total, max_r = self._profile[3], self._profile[4]
        self.size_var.set("高 %.0f mm · 直径 %.0f mm" % (total, max_r * 2))
        self.status_var.set("渲染 %.1f ms · 左键画 · 右键转视角 · 滚轮缩放" % dt)

    def _bind_canvas_events(self):
        self.canvas.bind("<Configure>", self._on_resize)
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<ButtonPress-3>", self._on_orbit_start)
        self.canvas.bind("<B3-Motion>", self._on_orbit)
        self.canvas.bind("<ButtonRelease-3>", lambda _e: setattr(self, "_orbit", None))
        self.canvas.bind("<MouseWheel>", self._on_wheel)

    def _on_resize(self, _event):
        if self._resize_job is not None:
            self.root.after_cancel(self._resize_job)
        self._resize_job = self.root.after(140, lambda: self.render_now(1.0))

    def _on_wheel(self, event):
        delta = 1 if event.delta > 0 else -1
        zoom = clamp(self.params.get("_zoom", 1.0) * (1.08 ** delta), 0.6, 2.4)
        self.params["_zoom"] = zoom
        self.render_now(0.75)
        self.root.after(180, lambda: self.render_now(1.0))

    def _on_orbit_start(self, event):
        self._orbit = (event.x, event.y, self.params["tilt"], self.params["spin"])

    def _on_orbit(self, event):
        if not self._orbit:
            return
        x0, y0, tilt0, spin0 = self._orbit
        tilt = clamp(tilt0 + (event.y - y0) * 0.25, 0, 40)
        spin = (spin0 + (event.x - x0) * 0.6) % 360
        self.params["tilt"] = tilt
        self.params["spin"] = spin
        for key, value in (("tilt", tilt), ("spin", spin)):
            sld, val, unit, res = self.scale_widgets[key]
            sld.set(value)
            val.set(self._fmt(value, res, unit))
        self.schedule_render()

    # ---------------- painting
    def _view_geometry(self):
        w = max(320, self.canvas.winfo_width())
        h = max(320, self.canvas.winfo_height())
        _ys, _rs, _drs, total, max_r = self._profile
        tilt = math.radians(clamp(self.params["tilt"], 0, 42))
        ct = max(math.cos(tilt), 1e-3)
        scale = min((h * 0.78) / max(total * ct, 1.0), (w * 0.82) / (2 * max_r)) * self.params.get("_zoom", 1.0)
        return w, h, scale, w * 0.5, h * 0.89, total, ct

    def _on_press(self, event):
        self._last_paint = None
        self._push_undo()
        self._paint_at(event.x, event.y)

    def _on_drag(self, event):
        self._paint_at(event.x, event.y)

    def _on_release(self, _event):
        self._last_paint = None
        self.render_now(1.0)

    def _paint_stroke(self, px, py):
        """在两点之间插值，避免快速拖动出现断点"""
        last = getattr(self, "_last_paint", None)
        self._last_paint = (px, py)
        if last is None:
            self._paint_at(px, py)
            return
        dx, dy = px - last[0], py - last[1]
        dist = math.hypot(dx, dy)
        step = max(2.0, self.brush_size * 0.22)
        n = int(min(160, max(1, dist / step)))
        for i in range(1, n + 1):
            t = i / n
            self._paint_at(last[0] + dx * t, last[1] + dy * t)

    def _paint_at(self, px, py):
        w, h, scale, cx, base_px, total, ct = self._view_geometry()
        spin = math.radians(self.params["spin"] % 360)
        radius = self.brush_size / 2.0
        x0, x1 = max(0, int(px - radius)), min(w, int(px + radius) + 1)
        y0, y1 = max(0, int(py - radius)), min(h, int(py + radius) + 1)
        if x1 <= x0 or y1 <= y0:
            return

        gx = np.arange(x0, x1, dtype=np.float32) + 0.5
        gy = np.arange(y0, y1, dtype=np.float32) + 0.5
        X = (gx[None, :] - cx) / scale
        Y = ((base_px - gy[:, None]) / scale) / ct

        ys_p, rs_p, _drs, _total, _max_r = self._profile
        R = np.interp(Y, ys_p, rs_p, left=0.0, right=0.0)
        valid = np.abs(X) <= R * 0.94
        if not valid.any():
            return

        Z = np.sqrt(np.maximum(R * R - X * X, 0.0)) + 1e-5
        u = (np.arctan2(X, Z) * (0.5 / math.pi) + 0.5 - spin * (0.5 / math.pi)) % 1.0
        v = np.clip(Y / total, 0.0, 0.999)

        dx = gx[None, :] - px
        dy = gy[:, None] - py
        dist = np.sqrt(dx * dx + dy * dy) / max(radius, 1e-6)
        edge = np.clip((0.97 - np.abs(X) / np.maximum(R, 1e-6)) / 0.12, 0.0, 1.0)
        if self.tool == "hard":
            weight = np.clip((1.0 - dist) * 7.0, 0.0, 1.0)
        elif self.tool == "spray":
            weight = (np.clip(1.0 - dist, 0.0, 1.0) ** 0.8) * (np.random.rand(*dist.shape) < 0.32)
        else:
            weight = np.clip(1.0 - dist, 0.0, 1.0) ** 0.6
        weight = weight * valid * edge

        ti = np.clip((u * TEX_W).astype(np.int32), 0, TEX_W - 1)
        tj = np.clip(((1.0 - v) * TEX_H).astype(np.int32), 0, TEX_H - 1)

        if self.tool == "eraser":
            self.paint[tj, ti, 3] = np.maximum(
                self.paint[tj, ti, 3] - (weight * 255).astype(np.uint8), 0)
        else:
            rgb = np.array([int(self.brush_color[1:3], 16),
                            int(self.brush_color[3:5], 16),
                            int(self.brush_color[5:7], 16)], dtype=np.float32)
            old_a = self.paint[tj, ti, 3].astype(np.float32) / 255.0
            wgt = weight.astype(np.float32)
            new_a = np.clip(old_a + wgt * (1.0 - old_a), 0.0, 1.0)
            mix = wgt * (1.0 - old_a) / np.maximum(new_a, 1e-5)
            for c in range(3):
                cur = self.paint[tj, ti, c].astype(np.float32)
                self.paint[tj, ti, c] = np.clip(cur * (1.0 - mix) + rgb[c] * mix, 0, 255).astype(np.uint8)
            self.paint[tj, ti, 3] = (new_a * 255).astype(np.uint8)

        self._compose_texture()
        self.schedule_render()

    # ---------------- export

    # ---------------- v4 功能
    def phi_snap(self):
        """一键把整体比例锁到黄金分割"""
        phi = 1.6180339887
        p = self.params
        d = float(p["body_w"])
        p["body_h"] = round(d * phi, 1)
        p["neck_w"] = round(d / phi, 1)
        p["shoulder_h"] = round(p["body_h"] / phi ** 3, 1)
        p["neck_h"] = round(max(6.0, p["body_h"] * 0.17), 1)
        p["mouth_w"] = round(min(96.0, max(18.0, p["neck_w"] * 1.12)), 1)
        for key in ("body_h", "neck_w", "shoulder_h", "neck_h", "mouth_w"):
            sld, val, unit, res = self.scale_widgets[key]
            sld.set(p[key])
            val.set(self._fmt(p[key], res, unit))
        self._profile = build_profile(p)
        self.render_now(1.0)
        self.status_var.set("已按 φ 重新锁定比例")

    def export_blueprint_ui(self):
        path = filedialog.asksaveasfilename(title="导出蓝图", defaultextension=".png",
                                            initialfile="jar_blueprint.png",
                                            filetypes=[("PNG 图片", "*.png")])
        if not path:
            return
        export_blueprint(self.params, path)
        self.status_var.set("蓝图已导出：%s" % os.path.basename(path))

    def export_matrix_ui(self):
        path = filedialog.asksaveasfilename(title="导出参数矩阵", defaultextension=".png",
                                            initialfile="jar_matrix.png",
                                            filetypes=[("PNG 图片", "*.png")])
        if not path:
            return
        export_matrix(self.params, self.texture, path)
        self.status_var.set("矩阵已导出：%s" % os.path.basename(path))

    def export_rgba_ui(self):
        path = filedialog.asksaveasfilename(title="导出透明底 PNG", defaultextension=".png",
                                            initialfile="jar_cutout.png",
                                            filetypes=[("PNG 图片", "*.png")])
        if not path:
            return
        export_rgba(self.params, self.texture, path)
        self.status_var.set("透明底已导出：%s" % os.path.basename(path))

    def save_params(self):
        path = filedialog.asksaveasfilename(title="保存参数", defaultextension=".json",
                                            initialfile="jar_params.json",
                                            filetypes=[("JSON", "*.json")])
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            json.dump({k: v for k, v in self.params.items() if not k.startswith("_")},
                      f, ensure_ascii=False, indent=2)
        self.status_var.set("参数已保存")

    def load_params(self):
        path = filedialog.askopenfilename(title="读取参数", filetypes=[("JSON", "*.json")])
        if not path:
            return
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        for key, value in data.items():
            if key in self.scale_widgets:
                self.params[key] = float(value)
                sld, val, unit, res = self.scale_widgets[key]
                sld.set(float(value))
                val.set(self._fmt(float(value), res, unit))
        if data.get("_material"):
            self.params["material"] = data["_material"]
            try:
                self._refresh_materials()
            except Exception:
                pass
        if "_bg" in data:
            self.bg_style = int(data["_bg"])
            self._bg_for_render = [None, (255, 255, 255), (238, 234, 226),
                                   (58, 56, 52), (214, 206, 196)][self.bg_style % 5]
        self._profile = build_profile(self.params)
        self.render_now(1.0)
        self.status_var.set("参数已读取")

    def cycle_bg(self):
        styles = [None, (255, 255, 255), (238, 234, 226), (58, 56, 52), (214, 206, 196)]
        self.bg_style = (self.bg_style + 1) % len(styles)
        self._bg_for_render = styles[self.bg_style]
        name = ["纸感渐变", "纯白", "米灰", "深灰", "暖砂"][self.bg_style]
        self.render_now(1.0)
        self.status_var.set("背景：" + name)

    def save_scene(self):
        path = filedialog.asksaveasfilename(title="保存场景", defaultextension=".json",
                                            initialfile="jar_scene.json",
                                            filetypes=[("JSON", "*.json")])
        if not path:
            return
        data = {k: v for k, v in self.params.items() if not k.startswith("_")}
        data["_material"] = self.params.get("material", "glaze")
        data["_bg"] = self.bg_style
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        self.status_var.set("场景已保存（含灯光与背景）")

    def save_preview(self):
        if self.last_image is None:
            return
        path = filedialog.asksaveasfilename(
            title="保存预览图", defaultextension=".png", initialfile="jar_preview.png",
            filetypes=[("PNG 图片", "*.png"), ("JPEG 图片", "*.jpg")])
        if not path:
            return
        big = render(self.params, self.texture, (1600, 1400), quality=1.0)
        if path.lower().endswith((".jpg", ".jpeg")):
            big.save(path, quality=95)
        else:
            big.save(path)
        self.status_var.set("已保存预览：%s" % os.path.basename(path))

    def export_assets(self):
        folder = filedialog.askdirectory(title="选择导出文件夹")
        if not folder:
            return
        tex = Image.fromarray(np.clip(self.texture, 0, 255).astype(np.uint8), "RGB")
        tex.save(os.path.join(folder, "jar_texture_uv.png"))
        with open(os.path.join(folder, "jar_params.json"), "w", encoding="utf-8") as f:
            json.dump({k: v for k, v in self.params.items() if not k.startswith("_")},
                      f, ensure_ascii=False, indent=2)
        self.status_var.set("已导出贴图与参数到：%s" % folder)



def export_mode(argv) -> int:
    params = {k: d for k, _, _, _, d, _, _ in SPECS}
    params["kind"] = "jar"
    params["wire"] = False
    params["material"] = "glaze"
    tex = np.full((TEX_H, TEX_W, 3), 240.0, dtype=np.float32)
    what = argv[0]
    out = argv[1] if len(argv) > 1 else what.strip("-") + ".png"
    if what == "--blueprint":
        export_blueprint(params, out)
    elif what == "--matrix":
        export_matrix(params, tex, out)
    elif what == "--rgba":
        export_rgba(params, tex, out)
    print("saved", out)
    return 0


# --------------------------------------------------------------------------- entry
def check_mode() -> int:
    params = {k: d for k, _, _, _, d, _, _ in SPECS}
    tex = np.full((TEX_H, TEX_W, 3), 240.0, dtype=np.float32)
    size = (880, 740)
    render(params, tex, size)
    hi, lo = [], []
    for _ in range(8):
        t = time.perf_counter()
        render(params, tex, size, quality=1.0)
        hi.append((time.perf_counter() - t) * 1000)
        t = time.perf_counter()
        render(params, tex, size, quality=0.58)
        lo.append((time.perf_counter() - t) * 1000)
    print("full %.1f ms (max %.1f) | drag %.1f ms" % (sum(hi) / len(hi), max(hi), sum(lo) / len(lo)))
    return 0


def sample_mode() -> int:
    params = {k: d for k, _, _, _, d, _, _ in SPECS}
    tex = np.full((TEX_H, TEX_W, 3), 240.0, dtype=np.float32)
    img = render(params, tex, (900, 1100), quality=1.0)
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample.png")
    img.save(out)
    print("saved", out)
    return 0


def ui_test():
    root = tk.Tk()
    root.geometry("+3000+3000")
    app = JarStudio(root)
    root.update()
    app.render_now(0.5)
    root.update()
    print("window %dx%d | canvas %dx%d | save row bottom %d / panel %d"
          % (root.winfo_width(), root.winfo_height(),
             app.canvas.winfo_width(), app.canvas.winfo_height(),
             app.save_row.winfo_y() + app.save_row.winfo_height(),
             app.save_row.master.winfo_height()))
    root.destroy()
    return 0


def enable_dpi_awareness():
    if os.name != "nt":
        return
    try:
        import ctypes

        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def main():
    if "--uitest" in sys.argv:
        raise SystemExit(ui_test())
    if any(f in sys.argv for f in ("--blueprint", "--matrix", "--rgba", "--persp")):
        i = [k for k, a in enumerate(sys.argv)
             if a in ("--blueprint", "--matrix", "--rgba", "--persp")][0]
        return export_mode(sys.argv[i:])
    if "--check" in sys.argv:
        raise SystemExit(check_mode())
    if "--sample" in sys.argv:
        raise SystemExit(sample_mode())
    enable_dpi_awareness()
    root = tk.Tk()
    JarStudio(root)
    root.mainloop()


if __name__ == "__main__":
    main()
