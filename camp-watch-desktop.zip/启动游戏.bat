@echo off
setlocal
set "HERE=%~dp0"
set "PY=C:\Users\lenovo\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\pythonw.exe"

if exist "%PY%" (
    start "" "%PY%" "%HERE%camp_game.py"
    exit /b 0
)

where pythonw >nul 2>&1
if %errorlevel%==0 (
    start "" pythonw "%HERE%camp_game.py"
    exit /b 0
)

echo pythonw not found. Edit the PY path in this .bat file.
pause
