#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""营地守望 / Camp Watch — 俯视角卡通营地生存小游戏

玩法：白天招人干活、晚上守墙。给营地居民买工具，他们会变成工人、猎人、
骑士、伐木工；每天夜里贪婪怪来袭，一波比一波强。撑过 8 天即胜利。

    python camp_game.py          开始游戏
    python camp_game.py --check  无窗口自检（模拟 60 秒）
"""

from __future__ import annotations

import math
import os
import random
import sys
import time

import tkinter as tk
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageTk

# --------------------------------------------------------------------------- config
VIEW_W, VIEW_H = 1200, 760
WORLD_W, WORLD_H = 8400, 6000
DAY_LEN, NIGHT_LEN = 84.0, 56.0
WIN_DAY = 8

KEEP_R = 62
WALL_BASE = 250
WALL_STEP = 140
MAX_EXPAND = 3
START_COINS = 30

TOOL_COST = {"worker": 3, "hunter": 4, "knight": 6, "lumber": 3, "farmer": 4}
TOOL_NAME = {"worker": "锤子", "hunter": "弓", "knight": "剑", "lumber": "斧子",
             "farmer": "锄头"}
ROLE_NAME = {"idle": "居民", "worker": "工人", "hunter": "猎人", "knight": "骑士",
             "lumber": "伐木工", "farmer": "农民"}
ROLE_COLOR = {"idle": (226, 205, 176), "worker": (196, 148, 96), "hunter": (124, 154, 110),
              "knight": (150, 160, 178), "lumber": (176, 128, 92),
              "farmer": (216, 186, 108)}

GRASS = (126, 196, 116)
GRASS_DARK = (108, 176, 102)
GRASS_LIGHT = (146, 210, 132)
INK = (52, 44, 40)
NIGHT_TINT = (26, 34, 74)

FONT_PATH = "C:/Windows/Fonts/msyh.ttc"
_font_cache = {}


def load_font(size):
    if size not in _font_cache:
        try:
            _font_cache[size] = ImageFont.truetype(FONT_PATH, size)
        except Exception:
            _font_cache[size] = ImageFont.load_default()
    return _font_cache[size]


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


# --------------------------------------------------------------------------- drawing
def blob(d, x, y, rx, ry, fill, outline=INK, width=3):
    d.ellipse([x - rx, y - ry, x + rx, y + ry], fill=fill, outline=outline, width=width)


def shadow(d, x, y, rx, ry):
    d.ellipse([x - rx, y - ry, x + rx, y + ry], fill=(70, 96, 66, 70))


# --------------------------------------------------------------------------- terrain
TILE = 256
_TILE_CACHE = None
_DECOR = None


def build_tiles():
    global _TILE_CACHE
    if _TILE_CACHE is not None:
        return _TILE_CACHE
    tiles = []
    for variant in range(3):
        img = Image.new("RGB", (TILE, TILE), GRASS)
        d = ImageDraw.Draw(img)
        rnd = random.Random(100 + variant)
        for _ in range(46):
            x, y = rnd.uniform(0, TILE), rnd.uniform(0, TILE)
            r = rnd.uniform(14, 46)
            col = GRASS_DARK if rnd.random() < 0.5 else GRASS_LIGHT
            for ox in (-TILE, 0, TILE):
                for oy in (-TILE, 0, TILE):
                    d.ellipse([x + ox - r, y + oy - r * 0.65, x + ox + r, y + oy + r * 0.65], fill=col)
        for _ in range(120):
            x, y = rnd.uniform(0, TILE), rnd.uniform(0, TILE)
            h = rnd.uniform(3, 7)
            col = (104, 170, 98) if rnd.random() < 0.6 else (146, 206, 132)
            for ox in (-TILE, 0, TILE):
                for oy in (-TILE, 0, TILE):
                    d.line([(x + ox, y + oy), (x + ox - 2, y + oy - h)], fill=col, width=2)
        tiles.append(img)
    _TILE_CACHE = tiles
    return tiles


def build_decor():
    global _DECOR
    if _DECOR is not None:
        return _DECOR
    rnd = random.Random(31)
    items = []
    for _ in range(2600):
        x, y = rnd.uniform(0, WORLD_W), rnd.uniform(0, WORLD_H)
        roll = rnd.random()
        if roll < 0.62:
            items.append(("tuft", x, y, rnd.uniform(3, 7), rnd.random() * 6))
        elif roll < 0.82:
            items.append(("flower", x, y, rnd.uniform(2, 3.4), rnd.random() * 6))
        elif roll < 0.94:
            items.append(("stone", x, y, rnd.uniform(4, 9), rnd.random() * 6))
        else:
            items.append(("bush", x, y, rnd.uniform(10, 16), rnd.random() * 6))
    _DECOR = items
    return items


def build_ground():
    return None

_SUN = {}


def sunlight(w, h):
    key = (w, h)
    if key in _SUN:
        return _SUN[key]
    import numpy as np
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    t = np.clip((xx / w) * 0.5 + (yy / h) * 0.7, 0, 1)
    a = ((1 - t) ** 1.6 * 34).astype(np.uint8)
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    arr[..., 0] = 255
    arr[..., 1] = 238
    arr[..., 2] = 196
    arr[..., 3] = a
    from PIL import Image as _Im
    _SUN[key] = _Im.fromarray(arr, "RGBA")
    return _SUN[key]


_SFX = {}
_SFX_OK = True


def _wav_tone(path, freqs, dur=0.18, vol=0.35, wave_type="sine"):
    import wave as _wave
    import numpy as _np
    sr = 22050
    n = int(sr * dur)
    t = _np.arange(n) / sr
    data = _np.zeros(n, dtype=_np.float32)
    for f in freqs:
        if wave_type == "square":
            data += _np.sign(_np.sin(2 * _np.pi * f * t))
        else:
            data += _np.sin(2 * _np.pi * f * t)
    data /= max(1, len(freqs))
    env = _np.exp(-t * 6.0)
    data = (data * env * vol * 32767).astype(_np.int16)
    with _wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(data.tobytes())


def _wav_noise(path, dur=0.12, vol=0.3):
    import wave as _wave
    import numpy as _np
    sr = 22050
    n = int(sr * dur)
    t = _np.arange(n) / sr
    data = _np.random.uniform(-1, 1, n) * _np.exp(-t * 26.0) * vol * 32767
    with _wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(data.astype(_np.int16).tobytes())


def init_sfx():
    global _SFX_OK
    try:
        import os as _os
        d = _os.path.join(_os.environ.get("TEMP", "."), "camp_sfx")
        _os.makedirs(d, exist_ok=True)
        _wav_tone(_os.path.join(d, "horn.wav"), [146.8, 220.0], 0.5, 0.32, "square")
        _wav_tone(_os.path.join(d, "coin.wav"), [880.0, 1320.0], 0.12, 0.22)
        _wav_noise(_os.path.join(d, "hit.wav"), 0.09, 0.25)
        for k in ("horn", "coin", "hit"):
            with open(_os.path.join(d, k + ".wav"), "rb") as f:
                _SFX[k] = f.read()
    except Exception:
        _SFX_OK = False


_SFX_LAST = {}


def play_sfx(name, min_gap=0.09):
    """内存播放 + 节流：避免每帧反复读盘、抢音频设备导致卡顿。"""
    if not _SFX_OK or name not in _SFX:
        return
    import time as _time
    now = _time.perf_counter()
    if now - _SFX_LAST.get(name, 0.0) < min_gap:
        return
    _SFX_LAST[name] = now
    try:
        import winsound
        winsound.PlaySound(_SFX[name], winsound.SND_MEMORY | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
    except Exception:
        pass


_TREE_CACHE = {}
TREE_TILE = 210
TREE_ANCHOR = (105, 178)


def tree_sprite(variant, scale):
    key = (variant, round(scale * 10))
    if key in _TREE_CACHE:
        return _TREE_CACHE[key]
    from PIL import Image as _Im, ImageDraw as _ID
    img = _Im.new("RGBA", (TREE_TILE, TREE_TILE), (0, 0, 0, 0))
    d = _ID.Draw(img, "RGBA")
    x, y = TREE_ANCHOR
    sc = scale
    d.ellipse([x + 5 - 26 * sc, y + 16 * sc - 9 * sc, x + 5 + 26 * sc, y + 16 * sc + 9 * sc],
              fill=(70, 96, 66, 70))
    d.rectangle([x - 5 * sc, y - 6 * sc, x + 5 * sc, y + 18 * sc],
                fill=(118, 84, 56), outline=INK, width=2)
    if variant == 1:
        for i in range(3):
            w_ = (30 - i * 7) * sc
            h_ = (22 - i * 4) * sc
            yy = y - (14 + i * 15) * sc
            d.polygon([(x - w_, yy), (x + w_, yy), (x, yy - h_)],
                      fill=(64, 122, 78), outline=INK)
    else:
        d.ellipse([x - 26 * sc, y - 24 * sc - 24 * sc, x + 26 * sc, y - 24 * sc + 24 * sc],
                  fill=(70, 134, 82), outline=INK, width=3)
        d.ellipse([x - 13 * sc - 16 * sc, y - 13 * sc - 14 * sc, x - 13 * sc + 16 * sc, y - 13 * sc + 14 * sc],
                  fill=(88, 158, 96), outline=INK, width=3)
        d.ellipse([x + 13 * sc - 15 * sc, y - 15 * sc - 13 * sc, x + 13 * sc + 15 * sc, y - 15 * sc + 13 * sc],
                  fill=(88, 158, 96), outline=INK, width=3)
        d.ellipse([x - 4 - 9 * sc, y - 30 * sc - 6 * sc, x - 4 + 9 * sc, y - 30 * sc + 6 * sc],
                  fill=(132, 194, 128), outline=(72, 138, 84), width=2)
    _TREE_CACHE[key] = img
    return img


_FOG = {}


def fog_layer(w, h):
    key = (w, h)
    if key in _FOG:
        return _FOG[key]
    import numpy as _np
    yy, xx = _np.mgrid[0:h, 0:w].astype(_np.float32)
    d = _np.hypot((xx - w / 2) / (w * 0.55), (yy - h / 2) / (h * 0.55))
    a = (_np.clip(d - 0.45, 0, 1) ** 1.2 * 120).astype(_np.uint8)
    arr = _np.zeros((h, w, 4), dtype=_np.uint8)
    arr[..., 0] = 210
    arr[..., 1] = 214
    arr[..., 2] = 220
    arr[..., 3] = a
    _FOG[key] = Image.fromarray(arr, "RGBA")
    return _FOG[key]


_GLOW = {}


def glow_sprite(rad):
    key = max(24, int(rad))
    if key in _GLOW:
        return _GLOW[key]
    size = key * 2
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    d = np.hypot(xx - size / 2.0, (yy - size / 2.0) / 0.82) / (size / 2.0)
    a = np.clip(1.0 - d, 0, 1) ** 1.5
    arr = np.zeros((size, size, 4), dtype=np.uint8)
    arr[..., 0] = 255
    arr[..., 1] = 198
    arr[..., 2] = 118
    arr[..., 3] = (a * 92).astype(np.uint8)
    _GLOW[key] = Image.fromarray(arr, "RGBA")
    return _GLOW[key]


_CORNER = {}
_LIGHTSPR = {}


def corner_vignette(size=360, alpha=104, fx=False, fy=False):
    """角部暗角贴片：角上最暗，到贴片边缘淡出为 0，避免出现方块边界。"""
    key = (size, alpha, fx, fy)
    if key in _CORNER:
        return _CORNER[key]
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    d = np.hypot(xx, yy) / size
    a = np.clip(1.0 - d, 0, 1) ** 2.2 * alpha
    arr = np.zeros((size, size, 4), dtype=np.uint8)
    arr[..., 0] = 16
    arr[..., 1] = 12
    arr[..., 2] = 10
    arr[..., 3] = a.astype(np.uint8)
    img = Image.fromarray(arr, "RGBA")
    if fx:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    if fy:
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
    _CORNER[key] = img
    return img


def light_spot(size=420, alpha=34):
    key = (size, alpha)
    if key in _LIGHTSPR:
        return _LIGHTSPR[key]
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    d = np.hypot(xx, yy) / size
    a = np.clip(1.0 - d * 1.5, 0, 1) ** 1.6 * alpha
    arr = np.zeros((size, size, 4), dtype=np.uint8)
    arr[..., 0] = 255
    arr[..., 1] = 238
    arr[..., 2] = 196
    arr[..., 3] = a.astype(np.uint8)
    _LIGHTSPR[key] = Image.fromarray(arr, "RGBA")
    return _LIGHTSPR[key]


_VIGNETTE = {}
_SCREEN_OVERLAY = {}


def screen_overlay(w, h):
    key = (w, h)
    if key in _SCREEN_OVERLAY:
        return _SCREEN_OVERLAY[key]
    ov = Image.alpha_composite(sunlight(w, h), vignette(w, h))
    _SCREEN_OVERLAY[key] = ov
    return ov


def apply_overlay(frame, layer):
    try:
        frame.alpha_composite(layer)
        return frame
    except Exception:
        return Image.alpha_composite(frame, layer)


def vignette(w, h):
    key = (w, h)
    if key in _VIGNETTE:
        return _VIGNETTE[key]
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = img.load()
    cx, cy = w / 2.0, h / 2.0
    maxd = math.hypot(cx, cy)
    step = 2
    for y in range(0, h, step):
        for x in range(0, w, step):
            d = math.hypot(x - cx, y - cy) / maxd
            a = int(clamp((d - 0.55) / 0.45, 0, 1) ** 2 * 78)
            if a > 0:
                for yy in range(y, min(h, y + step)):
                    for xx in range(x, min(w, x + step)):
                        px[xx, yy] = (18, 14, 10, a)
    _VIGNETTE[key] = img
    return img


# --------------------------------------------------------------------------- entities
class Thing:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.dead = False

    def pos(self):
        return (self.x, self.y)


class Tree(Thing):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.hp = 8.0
        self.max_hp = 8.0
        self.r = 26
        self.seed = random.random() * 6
        self.scale = random.uniform(0.78, 1.22)
        self.variant = 1 if random.random() < 0.28 else 0

    def chop(self, dmg):
        self.hp -= dmg
        if self.hp <= 0:
            self.dead = True


class WallSide:
    def __init__(self, name, ax, ay, bx, by):
        self.name = name
        self.ax, self.ay, self.bx, self.by = ax, ay, bx, by
        self.level = 1
        self.max_hp = 300.0
        self.hp = 300.0

    @property
    def ratio(self):
        return clamp(self.hp / self.max_hp, 0.0, 1.0)

    def mid(self):
        return ((self.ax + self.bx) / 2, (self.ay + self.by) / 2)

    def near(self, x, y, pad=26):
        # distance from point to segment
        vx, vy = self.bx - self.ax, self.by - self.ay
        wx, wy = x - self.ax, y - self.ay
        L2 = vx * vx + vy * vy
        t = 0.0 if L2 == 0 else clamp((wx * vx + wy * vy) / L2, 0, 1)
        px, py = self.ax + t * vx, self.ay + t * vy
        return math.hypot(x - px, y - py) <= pad

    def point(self, t):
        return (self.ax + (self.bx - self.ax) * t, self.ay + (self.by - self.ay) * t)


class Monster(Thing):
    def __init__(self, x, y, hp, dmg, speed, kind="imp"):
        super().__init__(x, y)
        self.kind = kind
        self.max_hp = hp
        self.hp = hp
        self.dmg = dmg
        self.speed = speed
        self.r = {"imp": 20, "brute": 29, "thrower": 22, "bomber": 17, "shield": 24,
                  "flyer": 16}[kind]
        self.throw_cd = random.uniform(1.0, 2.4)
        self.hp_flash = 0.0
        self.atk_t = 0.0
        self.cd = 0.0
        self.bob = random.random() * 6
        self.hit_flash = 0.0

    def hurt(self, amount, src="arrow"):
        mult = 1.0
        if self.kind == "shield":
            mult = 1.35 if src == "melee" else 0.45     # 盾怪怕近战，怕箭
        elif self.kind == "flyer":
            mult = 1.25 if src == "arrow" else 0.85     # 飞行怪怕弓手
        elif self.kind == "thrower":
            mult = 1.4 if src == "melee" else 0.9       # 投石怪怕近战
        elif self.kind == "bomber":
            mult = 1.2 if src == "arrow" else 0.8
        self.hp -= amount * mult
        self.hit_flash = 0.12
        self.hp_flash = 2.0
        if self.hp <= 0 and not self.dead:
            self.dead = True


ROLE_HP = {"idle": 8.0, "worker": 8.0, "hunter": 6.0, "knight": 34.0,
           "lumber": 8.0, "farmer": 7.0}


class Unit(Thing):
    def __init__(self, x, y, role="idle", team="mine"):
        super().__init__(x, y)
        self.role = role
        self.team = team
        self.faction = "player" if team == "mine" else None
        self.max_hp = ROLE_HP.get(role, 8.0)
        self.hp = self.max_hp
        self.hit_flash = 0.0
        self.jit = random.uniform(0, math.tau)
        self.swing = 0.0
        self.garrison = None
        self.on_wall = False
        self.kills = 0
        self.veteran = False
        self.face = 1
        self.walk = 0.0
        self.atk = "idle"
        self.atk_t = 0.0
        self.pending = None
        self.scale = 1.0
        self.r = 13
        self.speed = 78 if role != "knight" else 70
        self.target = None
        self.purse = 0
        self.bob = random.random() * 6
        self.work = 0.0
        self.cd = 0.0
        self.collect_cd = 0.0

    def set_role(self, role):
        self.role = role
        self.speed = {"worker": 82, "hunter": 96, "knight": 72, "lumber": 86}.get(role, 78)
        self.target = None
        self.max_hp = ROLE_HP.get(role, 8.0)
        self.hp = self.max_hp

    def hurt(self, amount):
        self.hp -= amount
        self.hit_flash = 0.15
        self.atk = "stagger"
        self.atk_t = 0.16
        if self.hp <= 0:
            self.dead = True


class Refugee(Thing):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.r = 13
        self.speed = 46
        self.target = None
        self.bob = random.random() * 6
        self.seed = random.random() * 6

    def update(self, dt):
        self.bob += dt * 5
        if self.target is None or dist(self.pos(), self.target) < 16 or random.random() < dt * 0.35:
            self.target = (clamp(self.x + random.uniform(-120, 120), 60, WORLD_W - 60),
                           clamp(self.y + random.uniform(-120, 120), 60, WORLD_H - 60))
        dx, dy = self.target[0] - self.x, self.target[1] - self.y
        d = math.hypot(dx, dy)
        if d > 4:
            self.x += dx / d * self.speed * dt
            self.y += dy / d * self.speed * dt


class Coin(Thing):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.life = 26.0
        self.bob = random.random() * 6


class Animal(Thing):
    def __init__(self, x, y, kind="rabbit"):
        super().__init__(x, y)
        self.kind = kind
        self.hp = 1.0
        self.speed = 62 if kind == "rabbit" else 48
        self.r = 9 if kind == "rabbit" else 13
        self.target = None
        self.bob = random.random() * 6
        self.flee = 0.0

    def hurt(self, amount, src="arrow"):
        self.hp -= amount
        if self.hp <= 0:
            self.dead = True


class Popup:
    def __init__(self, x, y, text, color=(255, 240, 200)):
        self.x, self.y = x, y
        self.text = text
        self.color = color
        self.life = 1.1
        self.dead = False

    def update(self, dt):
        self.y -= 26 * dt
        self.life -= dt
        if self.life <= 0:
            self.dead = True


# --------------------------------------------------------------------------- game
class Game:
    def __init__(self, seed=1):
        random.seed(seed)
        self.reset()
        corner_vignette()
        light_spot()

    # ---------------- setup
    def reset(self):
        self.t = 0.0
        self.clock = 0.0
        self.day = 1
        self.phase = "day"
        self.phase_t = DAY_LEN
        self.coins = START_COINS
        self.wave_left = 0
        self.wave_timer = 0.0
        self.second_wave_done = False
        self.territory = 300.0
        self.wall_expand = 0
        self.wall_half = float(WALL_BASE)
        self.island = 1
        self.crowns = 3
        self.nights_done = 0
        self.dock = None
        self.nest = None
        self.flash = 0.0
        self.fps = 0.0
        self.low_detail = False
        self.buildings = []
        self.projects = []
        self.blood = False
        self.blood_count = 0
        self.stats_kills = 0
        self.stats_lost = 0
        self.stats_income = 0
        self.dawn = None
        self.promo = None
        self.safe_day = False
        self.army_order = 0.0
        self.state = "menu"
        self.difficulty = 1
        self.diff_scale = {"hp": 0.7, "income": 1.2}
        self.weather = "clear"
        self.weather_t = 0.0
        self.chronicle = ""
        self.peak_coins = START_COINS
        self.hitstop = 0.0
        self.ui_simple = False
        self.end_stats = None
        self.message = ""
        self.message_t = 0.0
        self.keep_hp = 440.0
        self.keep_max = 440.0

        self.keep = (WORLD_W / 2, WORLD_H / 2)
        kx, ky = self.keep
        self.workshop = (kx + 120, ky + 26)
        self.camps = []
        self.enemy_units = []
        kx0, ky0 = self.keep
        self.enemy_units = []
        self.camp_styles = [(0, (168, 84, 72), (216, 210, 198)),
                            (1, (86, 116, 158), (206, 214, 226)),
                            (2, (96, 138, 96), (214, 222, 206))]
        specs = ((0.9, 1500, 0), (3.9, 1850, 1))
        for idx, (ang, rad, style) in enumerate(specs):
            x = clamp(kx0 + math.cos(ang) * rad, 200, WORLD_W - 200)
            y = clamp(ky0 + math.sin(ang) * rad, 200, WORLD_H - 200)
            power = random.uniform(0.8, 1.3)
            camp = {"id": idx, "x": x, "y": y, "hp": 380.0 * power, "max": 380.0 * power,
                    "level": 1, "power": power, "owner": "enemy", "timer": 110.0,
                    "purse": 0.0, "t": 0.0, "wall_half": 118.0, "style": style,
                    "units": [], "raid_target": None, "raid_timer": 0.0}
            camp["walls"] = self._make_camp_walls(x, y, camp["wall_half"], 90.0 * power)
            self.camps.append(camp)
            for i in range(2 + int(power * 2)):
                ang2 = random.uniform(0, math.tau)
                u = Unit(x + math.cos(ang2) * random.uniform(70, 140),
                         y + math.sin(ang2) * random.uniform(70, 140), "guard", team="enemy")
                u.mode = "guard"
                u.target_struct = None
                u.home = (x, y)
                u.camp = camp
                u.faction = idx
                u.life = 1e9
                u.target = None
                u.max_hp = 10.0 * power
                u.hp = u.max_hp
                u.dmg = 1.0 + power * 0.8
                self.enemy_units.append(u)
                camp["units"].append(u)

        h = self.wall_half
        self.walls = [
            WallSide("top", kx - h, ky - h, kx + h, ky - h),
            WallSide("bottom", kx - h, ky + h, kx + h, ky + h),
            WallSide("left", kx - h, ky - h, kx - h, ky + h),
            WallSide("right", kx + h, ky - h, kx + h, ky + h),
        ]

        self.player = Unit(kx, ky + 120, role="player")
        self.player.speed = 178
        self.player.r = 15
        self.player.facing = -1

        self.units = [Unit(kx + random.uniform(-70, 70), ky + random.uniform(40, 100)) for _ in range(5)]
        self.monsters = []
        self.animals = []
        self.refugees = []
        self.refugee_timer = 10.0
        self.arrows = []
        self.slashes = []
        self.stars = []
        self.toasts = []
        self.coin_pulse = 0.0
        self.deny_flash = 0.0
        self.shake = 0.0
        self.animal_timer = 1.0
        self.coins_world = []
        self.popups = []
        self.hits = []

        self.trees = self._gen_trees(11)
        self.tiles = build_tiles()
        self.decor = build_decor()
        if not hasattr(self, "_decor_grid"):
            grid = {}
            for idx, item in enumerate(self.decor):
                cell = (int(item[1]) // 320, int(item[2]) // 320)
                grid.setdefault(cell, []).append(idx)
            self._decor_grid = grid

    def _gen_trees(self, seed):
        kx, ky = self.keep
        rnd = random.Random(seed)
        trees = []
        attempts = 0
        while len(trees) < 950 and attempts < 90000:
            attempts += 1
            ang = rnd.uniform(0, math.tau)
            rad = rnd.uniform(self.wall_half + 90, self.wall_half + 2800)
            x = kx + math.cos(ang) * rad
            y = ky + math.sin(ang) * rad * 0.9
            if 30 < x < WORLD_W - 30 and 30 < y < WORLD_H - 30:
                if all(dist((x, y), t.pos()) > 84 for t in trees):
                    trees.append(Tree(x, y))
        return trees

    def say(self, text, dur=2.4):
        self.message = text
        self.message_t = dur
        if text:
            self.toasts.append([text, min(3.2, max(1.6, dur))])
            if len(self.toasts) > 2:
                self.toasts.pop(0)

    def deny(self, text):
        self.deny_flash = 0.5
        self.say(text, 1.8)

    # ---------------- helpers
    def idle_units(self):
        return [u for u in self.units if u.role == "idle"]

    CELL = 220

    def _grid_add(self, grid, obj):
        key = (int(obj.x // self.CELL), int(obj.y // self.CELL))
        lst = grid.get(key)
        if lst is None:
            grid[key] = [obj]
        else:
            lst.append(obj)

    def rebuild_grids(self):
        hg = {}
        for m in self.monsters:
            if not m.dead:
                self._grid_add(hg, m)
        for e in self.enemy_units:
            if not e.dead:
                self._grid_add(hg, e)
        self._grid_hostile = hg
        ug = {}
        for u in self.units:
            if not u.dead:
                self._grid_add(ug, u)
        self._grid_units = ug
        ag = {}
        for a in self.animals:
            if not a.dead:
                self._grid_add(ag, a)
        self._grid_animals = ag

    def query_grid(self, grid, x, y, radius):
        out = []
        r = int(radius // self.CELL) + 1
        cx, cy = int(x // self.CELL), int(y // self.CELL)
        r2 = radius * radius
        for gx in range(cx - r, cx + r + 1):
            for gy in range(cy - r, cy + r + 1):
                for o in grid.get((gx, gy), ()):
                    dx = o.x - x
                    dy = o.y - y
                    d2 = dx * dx + dy * dy
                    if d2 <= r2:
                        out.append((d2, o))
        return out

    def pick_hostile(self, x, y, k=2, radius=900):
        cand = self.query_grid(getattr(self, "_grid_hostile", {}), x, y, radius)
        if not cand:
            return None
        if len(cand) > k:
            cand.sort(key=lambda t: t[0])
        cand = cand[:max(1, k)]
        return random.choice(cand)[1]

    def pick_animal(self, x, y, k=2, radius=900):
        cand = self.query_grid(getattr(self, "_grid_animals", {}), x, y, radius)
        if not cand:
            return None
        if len(cand) > k:
            cand.sort(key=lambda t: t[0])
        cand = cand[:max(1, k)]
        return random.choice(cand)[1]

    def pick_near(self, items, x, y, k=3, radius=900):
        """在最近的 k 个目标里随机挑一个，避免所有单位都扑同一个。"""
        cand = []
        for it in items:
            if getattr(it, "dead", False):
                continue
            d = dist((x, y), it.pos())
            if d < radius:
                cand.append((d, it))
        if not cand:
            return None
        cand.sort(key=lambda c: c[0])
        return random.choice(cand[:max(1, k)])[1]

    def hostile_units(self):
        return self.monsters + self.enemy_units

    def nearest_monster(self, x, y, radius):
        best = None
        bd = radius
        for m in self.monsters:
            dd = dist((x, y), m.pos())
            if dd < bd:
                best, bd = m, dd
        return best

    def wall_blocking(self, x, y, pad=16):
        for w in self.walls:
            if w.hp > 0 and w.near(x, y, pad):
                return w
        return None

    def inside_walls(self, x, y):
        kx, ky = self.keep
        return abs(x - kx) < self.wall_half - 6 and abs(y - ky) < self.wall_half - 6

    # ---------------- player actions
    def buy_tool(self, role):
        if self.state != "playing":
            return
        cost = TOOL_COST[role]
        if dist(self.player.pos(), self.workshop) > 120:
            self.say("走到装备台旁边才能买工具")
            return
        idles = self.idle_units()
        if not idles:
            self.say("没有空闲的居民了")
            return
        if self.coins < cost:
            self.deny("金币不够（需要 %d）" % cost)
            return
        self.coins -= cost
        self.coin_pulse = 0.35
        u = min(idles, key=lambda v: dist(v.pos(), self.workshop))
        u.set_role(role)
        u.x, u.y = self.workshop[0] + random.uniform(-24, 24), self.workshop[1] + random.uniform(18, 40)
        self.popups.append(Popup(u.x, u.y - 26, "-%d" % cost, (255, 210, 150)))
        self.say("买了一把%s，居民变成了%s" % (TOOL_NAME[role], ROLE_NAME[role]))

    def upgrade_walls(self):
        if self.state != "playing":
            return
        if dist(self.player.pos(), self.keep) > 150:
            self.say("回到大本营附近才能安排施工")
            return
        if any(p["kind"] == "wall" for p in self.projects):
            self.say("城墙正在施工中")
            return
        level = max(w.level for w in self.walls)
        if level >= 5:
            self.say("城墙已经满级")
            return
        cost = 10 * level
        if self.coins < cost:
            self.deny("升级需要 %d 金币" % cost)
            return
        self.start_project("wall", self.keep[0], self.keep[1] + 60, cost,
                           50 if self.safe_day else 70)
        self.say("工人开始加固城墙（约 1 分钟）")

    def start_project(self, kind, x, y, cost, dur, data=None):
        self.coins -= cost
        self.projects.append({"kind": kind, "x": x, "y": y, "dur": float(dur),
                              "prog": 0.0, "data": data or {}})
        self.popups.append(Popup(x, y - 26, "-%d" % cost, (255, 210, 150)))

    def complete_project(self, pj):
        kind = pj["kind"]
        self.star_fx(pj["x"], pj["y"] - 10, (255, 226, 140))
        self.popups.append(Popup(pj["x"], pj["y"] - 46, "完工", (255, 236, 170)))
        if kind == "wall":
            level = max(w.level for w in self.walls)
            for w in self.walls:
                w.level = level + 1
                w.max_hp = 300.0 * w.level
                w.hp = w.max_hp
            self.popups.append(Popup(pj["x"], pj["y"] - 30, "城墙 Lv.%d" % (level + 1), (210, 230, 255)))
            self.say("城墙修好了，升到 %d 级" % (level + 1))
        elif kind == "expand":
            self.wall_expand += 1
            self.wall_half += WALL_STEP
            h = self.wall_half
            kx, ky = self.keep
            level = self.walls[0].level if self.walls else 1
            coords = [("top", kx - h, ky - h, kx + h, ky - h),
                      ("bottom", kx - h, ky + h, kx + h, ky + h),
                      ("left", kx - h, ky - h, kx - h, ky + h),
                      ("right", kx + h, ky - h, kx + h, ky + h)]
            self.walls = []
            for name, ax, ay, bx, by in coords:
                w = WallSide(name, ax, ay, bx, by)
                w.level = level
                w.max_hp = 300.0 * level
                w.hp = w.max_hp
                self.walls.append(w)
            self.say("疆域扩张完成")
        elif kind == "camp_barracks":
            self.buildings.append({"type": "barracks", "x": pj["x"], "y": pj["y"], "cd": 14.0})
            self.say("兵营建好了，会定期训练骑士", 2.6)
        elif kind == "camp_hospital":
            self.buildings.append({"type": "hospital", "x": pj["x"], "y": pj["y"]})
            self.say("医院建好了，附近单位会慢慢回血", 2.6)
        elif kind == "camp_trap":
            self.buildings.append({"type": "trap", "x": pj["x"], "y": pj["y"], "cd": 0.0})
            self.say("陷阱布好了", 2.0)
        elif kind in ("farm", "tower"):
            self.buildings.append({"type": kind, "x": pj["x"], "y": pj["y"], "purse": 0,
                                   "t": 0.0, "cd": 0.0})
            self.say({"farm": "农场建好了", "tower": "箭塔建好了"}[kind])
        elif kind.startswith("statue"):
            role = kind.split("_")[1]
            self.buildings.append({"type": "statue", "role": role, "x": pj["x"], "y": pj["y"]})
            self.say({"hunter": "猎人", "knight": "骑士", "farmer": "农民"}[role] + "雕像落成")

    def update_projects(self, dt):
        for pj in list(self.projects):
            if pj["prog"] >= pj["dur"]:
                self.projects.remove(pj)
                self.complete_project(pj)

    def add_kill(self, u):
        u.kills = getattr(u, "kills", 0) + 1
        if not getattr(u, "veteran", False) and u.kills >= 5:
            u.veteran = True
            u.scale = 1.15
            u.max_hp = u.max_hp * 1.5
            u.hp = u.max_hp
            self.flash = 0.35
            self.promo = ["%s晋升老兵！" % ROLE_NAME.get(u.role, "单位"), 3.0]
            play_sfx("coin", 0.05)
            self.popups.append(Popup(u.x, u.y - 34, "老兵!", (255, 236, 150)))
            self.say("你的%s成了老兵" % ROLE_NAME.get(u.role, "单位"), 2.2)

    def unit_power(self, u):
        return 1.3 if getattr(u, "veteran", False) else 1.0

    def keep_buff(self, x, y, radius=300):
        """在大本营附近作战的己方单位获得守家加成。"""
        kx, ky = self.keep
        return 1.25 if math.hypot(x - kx, y - ky) < radius else 1.0

    def statue_buff(self, role, x, y, radius=250):
        for b in self.buildings:
            if b["type"] == "statue" and b["role"] == role:
                if dist((x, y), (b["x"], b["y"])) < radius:
                    return 1.5
        return 1.0

    def expand_walls(self):
        if self.state != "playing":
            return
        if dist(self.player.pos(), self.keep) > 150:
            self.say("回到大本营附近才能安排施工")
            return
        if self.wall_expand >= MAX_EXPAND:
            self.say("已经是最大疆域了")
            return
        if any(p["kind"] == "expand" for p in self.projects):
            self.say("扩建正在施工中")
            return
        cost = 30 + 25 * self.wall_expand
        if self.coins < cost:
            self.deny("扩建需要 %d 金币" % cost)
            return
        self.start_project("expand", self.keep[0] + 70, self.keep[1] + 70, cost, 85)
        self.say("工人开始扩建疆域（约 1 分半）")

    def upgrade_branch(self, kind, branch):
        p = self.player.pos()
        need = {"tower": 30, "farm": 25}.get(kind)
        if need is None:
            return
        for b in self.buildings:
            if b["type"] != kind or b.get("branch"):
                continue
            if dist(p, (b["x"], b["y"])) > 110:
                continue
            if self.coins < need:
                self.deny("升级需要 %d 金币" % need)
                return
            self.coins -= need
            self.coin_pulse = 0.3
            b["branch"] = branch
            self.star_fx(b["x"], b["y"] - 10, (255, 226, 140))
            name = {"rapid": "连射塔", "heavy": "重箭塔",
                    "high": "高产农场", "bomb": "自爆农场"}[branch]
            self.say("升级为%s" % name, 2.4)
            return
        self.say("走到箭塔/农场旁边才能升级")

    def build(self, kind):
        if self.state != "playing":
            return
        spec = {"camp_barracks": (40, 70, "兵营"), "camp_hospital": (34, 60, "医院"),
                "camp_trap": (14, 22, "陷阱"),
                "farm": (20, 55, "农场"), "tower": (34, 60, "箭塔"),
                "statue_hunter": (30, 50, "猎人雕像"),
                "statue_knight": (34, 50, "骑士雕像"),
                "statue_farmer": (28, 50, "农民雕像")}
        if kind not in spec:
            return
        cost, dur, name = spec[kind]
        if dist(self.player.pos(), self.keep) > 200:
            self.say("回到大本营附近才能建造")
            return
        limit = {"farm": 2, "tower": 2, "camp_barracks": 2, "camp_hospital": 1,
                 "camp_trap": 6, "statue_hunter": 2, "statue_knight": 2,
                 "statue_farmer": 2}[kind]
        btype = kind.replace("camp_", "")
        if sum(1 for b in self.buildings if b["type"] == btype) >= limit or \
                any(p["kind"] == kind for p in self.projects):
            self.say("%s最多造 2 个" % name)
            return
        if self.coins < cost:
            self.deny("建造%s需要 %d 金币" % (name, cost))
            return
        kx, ky = self.keep
        for _ in range(40):
            ang = random.uniform(0, math.tau)
            if kind == "camp_trap":
                rad = random.uniform(self.wall_half + 30, self.wall_half + 120)
            elif kind in ("camp_barracks", "camp_hospital"):
                rad = random.uniform(self.wall_half * 0.40, self.wall_half * 0.72)
            else:
                rad = random.uniform(self.wall_half * 0.35, self.wall_half * 0.75)
            x, y = kx + math.cos(ang) * rad, ky + math.sin(ang) * rad
            if dist((x, y), self.keep) < 130:
                continue
            if any(dist((x, y), (b["x"], b["y"])) < 90 for b in self.buildings):
                continue
            if any(dist((x, y), (p["x"], p["y"])) < 80 for p in self.projects):
                continue
            if dist((x, y), self.workshop) < 90:
                continue
            self.start_project(kind, x, y, cost, dur, {"role": kind.split("_")[1]} if "statue" in kind else None)
            self.say("工人开始建造%s" % name)
            return
        self.say("附近没有空地了")

    def _make_camp_walls(self, cx, cy, half, base_hp):
        walls = [WallSide("c_top", cx - half, cy - half, cx + half, cy - half),
                 WallSide("c_bottom", cx - half, cy + half, cx + half, cy + half),
                 WallSide("c_left", cx - half, cy - half, cx - half, cy + half),
                 WallSide("c_right", cx + half, cy - half, cx + half, cy + half)]
        for w in walls:
            w.level = 1
            w.max_hp = base_hp
            w.hp = base_hp
        return walls

    def camp_inside(self, camp, x, y, pad=12):
        return abs(x - camp["x"]) < camp["wall_half"] - pad and \
               abs(y - camp["y"]) < camp["wall_half"] - pad

    def camp_nearest_wall(self, camp, x, y):
        best, bd = None, 1e9
        for w in camp["walls"]:
            if w.hp <= 0:
                continue
            mx, my = w.mid()
            d = math.hypot(mx - x, my - y)
            if d < bd:
                best, bd = w, d
        return best

    def camp_wall_block(self, camp, x, y, pad=18):
        for w in camp["walls"]:
            if w.hp > 0 and w.near(x, y, pad):
                return w
        return None

    def spawn_refugee(self):
        kx, ky = self.keep
        for _ in range(40):
            ang = random.uniform(0, math.tau)
            rad = random.uniform(self.wall_half + 220, self.wall_half + 760)
            x = clamp(kx + math.cos(ang) * rad, 40, WORLD_W - 40)
            y = clamp(ky + math.sin(ang) * rad, 40, WORLD_H - 40)
            if abs(x - kx) > self.wall_half + 60 or abs(y - ky) > self.wall_half + 60:
                self.refugees.append(Refugee(x, y))
                self.say("外面来了一个难民，走过去按 G 收编", 3.0)
                return

    def recruit(self):
        if self.state != "playing":
            return
        p = self.player.pos()
        near = [r for r in self.refugees if dist(p, r.pos()) < 90]
        if not near:
            self.say("附近没有难民")
            return
        if self.coins < 5:
            self.deny("收编需要 5 金币")
            return
        self.coins -= 5
        r = min(near, key=lambda v: dist(p, v.pos()))
        u = Unit(r.x, r.y, "idle")
        u.home = (self.keep[0] + random.uniform(-70, 70), self.keep[1] + random.uniform(30, 90))
        self.units.append(u)
        self.refugees.remove(r)
        self.popups.append(Popup(r.x, r.y - 26, "-5", (255, 210, 150)))
        self.say("收编了一个难民，他会走回营地", 2.6)

    def spawn_animal(self):
        kx, ky = self.keep
        for _ in range(30):
            ang = random.uniform(0, math.tau)
            rad = random.uniform(self.wall_half + 120, self.wall_half + 1500)
            x = clamp(kx + math.cos(ang) * rad, 40, WORLD_W - 40)
            y = clamp(ky + math.sin(ang) * rad, 40, WORLD_H - 40)
            if abs(x - kx) > self.wall_half + 40 or abs(y - ky) > self.wall_half + 40:
                kind = "rabbit" if random.random() < 0.65 else "deer"
                self.animals.append(Animal(x, y, kind))
                return

    def update_animal(self, a, dt):
        a.bob += dt * 8
        a.flee = max(0.0, a.flee - dt)
        threat = None
        for u in self.units:
            if u.role == "hunter" and dist(u.pos(), a.pos()) < 190:
                threat = u
                break
        if threat is not None:
            dx, dy = a.x - threat.x, a.y - threat.y
            d = math.hypot(dx, dy) or 1.0
            a.x += dx / d * a.speed * 1.7 * dt
            a.y += dy / d * a.speed * 1.7 * dt
        else:
            if a.target is None or dist(a.pos(), a.target) < 12 or random.random() < dt * 0.4:
                a.target = (clamp(a.x + random.uniform(-180, 180), 40, WORLD_W - 40),
                            clamp(a.y + random.uniform(-180, 180), 40, WORLD_H - 40))
            if a.target:
                dx, dy = a.target[0] - a.x, a.target[1] - a.y
                d = math.hypot(dx, dy)
                if d > 4:
                    a.x += dx / d * a.speed * 0.5 * dt
                    a.y += dy / d * a.speed * 0.5 * dt
        a.x = clamp(a.x, 40, WORLD_W - 40)
        a.y = clamp(a.y, 40, WORLD_H - 40)

    def slash_fx(self, x, y, ang, color=(255, 240, 200)):
        self.slashes.append([x, y, ang, 0.22, color])

    def star_fx(self, x, y, color=(255, 230, 160)):
        self.stars.append([x, y, 0.26, color])

    def fire_arrow(self, x0, y0, x1, y1, color=(240, 224, 160), dur=0.26):
        self.arrows.append([x0, y0, x1, y1, 0.0, dur, color])

    def shoot(self, u, target, dmg, color=(240, 224, 160)):
        target.hurt(dmg, "arrow")
        self.fire_arrow(u.x, u.y - 16, target.x, target.y - 8, color)
        self.hits.append([target.x, target.y, 0.1])

    def update_buildings(self, dt):
        for b in list(self.buildings):
            if b["type"] == "barracks":
                b["cd"] -= dt
                if b["cd"] <= 0:
                    knights = sum(1 for u in self.units if u.role == "knight")
                    if knights < 2 * sum(1 for x in self.buildings if x["type"] == "barracks"):
                        b["cd"] = 20.0
                        ang = random.uniform(0, math.tau)
                        u = Unit(b["x"] + math.cos(ang) * 36, b["y"] + math.sin(ang) * 36, "knight")
                        u.home = (b["x"], b["y"])
                        self.units.append(u)
                        self.popups.append(Popup(b["x"], b["y"] - 34, "新骑士", (210, 230, 255)))
                    else:
                        b["cd"] = 6.0
                continue
            if b["type"] == "hospital":
                for u in self.units:
                    if u.hp < u.max_hp and dist(u.pos(), (b["x"], b["y"])) < 210:
                        u.hp = min(u.max_hp, u.hp + 3.0 * dt)
                continue
            if b["type"] == "trap":
                b["cd"] -= dt
                if b["cd"] <= 0:
                    for m in self.monsters + self.enemy_units:
                        if dist(m.pos(), (b["x"], b["y"])) < 30:
                            m.hurt(7.0, "melee")
                            m.speed *= 0.55
                            b["cd"] = 1.2
                            self.star_fx(b["x"], b["y"] - 6, (220, 210, 180))
                            break
                continue
            if b["type"] == "farm":
                w = b.get("worker")
                if w is not None and not getattr(w, "dead", False) and \
                        dist((w.x, w.y), (b["x"], b["y"])) < 90:
                    b["t"] += dt
                    if b["t"] >= (2.2 if self.safe_day else 3.2):
                        b["t"] = 0.0
                        b["purse"] = min(12, b["purse"] + 1)
            elif b["type"] == "tower":
                branch = b.get("branch")
                rate = 1.9
                dmg = 1.6
                rng = 360 * (0.75 if self.weather == "rain" else (0.62 if self.weather == "fog" else 1.0))
                if branch == "rapid":
                    rate, dmg = 0.95, 1.0
                elif branch == "heavy":
                    rate, dmg, rng = 2.6, 4.6, 440
                b["cd"] -= dt
                if b["cd"] <= 0:
                    m = self.nearest_monster(b["x"], b["y"], rng)
                    if m is not None:
                        b["cd"] = rate
                        m.hurt(dmg, "arrow")
                        self.fire_arrow(b["x"], b["y"] - 40, m.x, m.y - 8, (250, 240, 200), 0.3)
                        self.hits.append([m.x, m.y, 0.1])
                        if m.dead:
                            self.coins_world.append(Coin(m.x, m.y))

    def lose_crown(self):
        self.crowns -= 1
        self.flash = 1.0
        kx, ky = self.keep
        if self.crowns <= 0:
            self.state = "lose"
            self.say("王冠被抢光了…营地陷落", 9.0)
            return
        self.keep_hp = self.keep_max * 0.55
        for w in self.walls:
            w.hp = max(w.max_hp * 0.3, 1.0)
        self.coins = self.coins // 2
        self.monsters = []
        self.popups.append(Popup(kx, ky - 70, "王冠被抢走了！", (255, 170, 150)))
        self.say("贪婪抢走了王冠！新君主继位，还剩 %d 顶王冠" % self.crowns, 4.5)
        self.player.x, self.player.y = kx, ky + 90

    def open_dock(self):
        ang = random.uniform(0, math.tau)
        rad = self.wall_half + 90
        self.dock = (clamp(self.keep[0] + math.cos(ang) * rad, 80, WORLD_W - 80),
                     clamp(self.keep[1] + math.sin(ang) * rad, 80, WORLD_H - 80))
        self.say("码头修好了！走到码头按 V 起航去下一座岛", 4.0)

    def sail(self):
        if self.state != "playing" or self.dock is None:
            return
        if dist(self.player.pos(), self.dock) > 120:
            self.say("走到码头旁边才能起航")
            return
        if self.island >= 3:
            self.say("这是最后一座岛，先摧毁贪婪之巢", 3.0)
            return
        self.island += 1
        self.nights_done = 0
        self.dock = None
        self.wall_expand = 0
        self.wall_half = float(WALL_BASE)
        kx, ky = self.keep
        coords = [("top", kx - self.wall_half, ky - self.wall_half, kx + self.wall_half, ky - self.wall_half),
                  ("bottom", kx - self.wall_half, ky + self.wall_half, kx + self.wall_half, ky + self.wall_half),
                  ("left", kx - self.wall_half, ky - self.wall_half, kx - self.wall_half, ky + self.wall_half),
                  ("right", kx + self.wall_half, ky - self.wall_half, kx + self.wall_half, ky + self.wall_half)]
        self.walls = []
        for name, ax, ay, bx, by in coords:
            self.walls.append(WallSide(name, ax, ay, bx, by))
        self.buildings = []
        self.monsters = []
        self.animals = []
        self.refugees = []
        self.coins_world = []
        self.trees = self._gen_trees(random.randint(100, 99999))
        self.keep_hp = self.keep_max
        self.day = 1
        self.phase = "day"
        self.phase_t = DAY_LEN
        self.coins = int(self.coins * 0.8)
        self.player.x, self.player.y = kx, ky + 90
        if self.island >= 3:
            self.create_nest()
            self.say("第三座岛 —— 找找贪婪之巢，把它毁掉才算结束", 5.0)
        else:
            self.say("第 %d 座岛 —— 从零开始，怪物更强了" % self.island, 4.5)

    def create_nest(self):
        kx, ky = self.keep
        ang = random.uniform(0, math.tau)
        rad = random.uniform(1250, 1600)
        x = clamp(kx + math.cos(ang) * rad, 120, WORLD_W - 120)
        y = clamp(ky + math.sin(ang) * rad * 0.9, 120, WORLD_H - 120)
        self.nest = {"x": x, "y": y, "hp": 900.0, "max": 900.0, "cd": 0.0, "bob": 0.0}

    def nearest_enemy_camp(self, x, y, radius=4000):
        best, bd = None, radius
        for c in self.camps:
            if c["owner"] == "enemy":
                d = dist((x, y), (c["x"], c["y"]))
                if d < bd:
                    best, bd = c, d
        return best

    def struct_pos(self, kind, camp):
        return self.keep if kind == "keep" else (camp["x"], camp["y"])

    def struct_walls(self, kind, camp):
        return self.walls if kind == "keep" else camp["walls"]

    def structure_targets(self, exclude_camp=None):
        out = [("keep", None)]
        for c in self.camps:
            if c is exclude_camp or c["owner"] == "ruin":
                continue
            out.append(("camp", c))
        return out

    def pick_structure(self, x, y, exclude_camp=None, k=2):
        cand = []
        for kind, c in self.structure_targets(exclude_camp):
            if kind == "keep":
                px, py = self.keep
            else:
                px, py = c["x"], c["y"]
            cand.append((math.hypot(px - x, py - y), (kind, c)))
        if not cand:
            return None
        cand.sort(key=lambda t: t[0])
        return random.choice(cand[:max(1, k)])[1]

    def damage_structure(self, kind, camp, amount, x, y):
        if kind == "keep":
            wall = self.wall_blocking(x, y, 26)
            if wall is not None:
                wall.hp = max(0.0, wall.hp - amount)
                return "wall"
            self.keep_hp = max(0.0, self.keep_hp - amount * 0.7)
            if self.keep_hp <= 0:
                self.lose_crown()
            return "keep"
        if camp["owner"] != "enemy":
            return None
        wall = self.camp_wall_block(camp, x, y, 30)
        if wall is not None:
            wall.hp = max(0.0, wall.hp - amount)
            return "wall"
        camp["hp"] = max(0.0, camp["hp"] - amount * 0.8)
        if camp["hp"] <= 0:
            camp["owner"] = "ruin"
            for u in list(camp["units"]):
                u.dead = True
            camp["units"] = []
            self.say("一座营地被人打成了废墟", 2.6)
        return "camp"

    def enemy_step(self, e, tx, ty, dt, speed_scale=1.0):
        """敌方单位移动；试图跨过我方/他方围墙时改为拆墙。"""
        dx, dy = tx - e.x, ty - e.y
        d = math.hypot(dx, dy)
        if d < 2:
            return
        nx = e.x + dx / d * e.speed * speed_scale * dt
        ny = e.y + dy / d * e.speed * speed_scale * dt
        # 我方围墙
        if not self.inside_walls(e.x, e.y) and self.inside_walls(nx, ny):
            best, bd = None, 1e9
            for w in self.walls:
                if w.hp <= 0:
                    continue
                mx, my = w.mid()
                dd = math.hypot(mx - e.x, my - e.y)
                if dd < bd:
                    best, bd = w, dd
            if best is not None:
                best.hp = max(0.0, best.hp - e.dmg * 1.2 * dt)
                if random.random() < dt * 5:
                    self.star_fx(best.mid()[0], best.mid()[1], (220, 190, 160))
                    self.slash_fx(e.x, e.y - 8, math.atan2(dy, dx), (255, 150, 140))
                return
        # 目标营地围墙
        for c in self.camps:
            if c is getattr(e, "camp", None) or c["owner"] == "ruin":
                continue
            if not self.camp_inside(c, e.x, e.y) and self.camp_inside(c, nx, ny):
                wall = self.camp_nearest_wall(c, e.x, e.y)
                if wall is not None:
                    wall.hp = max(0.0, wall.hp - e.dmg * 1.2 * dt)
                    if random.random() < dt * 5:
                        self.star_fx(wall.mid()[0], wall.mid()[1], (220, 190, 160))
                    return
        e.x, e.y = nx, ny

    def update_enemy_units(self, dt):
        for e in list(self.enemy_units):
            if e.dead:
                continue
            e.bob += dt * 6
            own = e.camp
            if own is None or own.get("owner") == "ruin":
                e.dead = True
                continue

            # 敌对单位：不是自己阵营的任何人
            prey = None
            pd = 320.0 if e.mode == "raid" else 190.0
            cand = self.query_grid(getattr(self, "_grid_units", {}), e.x, e.y, pd) + \
                self.query_grid(getattr(self, "_grid_hostile", {}), e.x, e.y, pd)
            for d2, o in cand:
                if o is e or getattr(o, "dead", False):
                    continue
                if getattr(o, "camp", None) is own:
                    continue
                d = math.sqrt(d2)
                if d < pd:
                    prey, pd = o, d

            if e.mode == "raid" and e.life <= 0:
                e.dead = True
                continue

            if prey is not None:
                if pd > 32:
                    self.enemy_step(e, prey.x, prey.y, dt, 1.0)
                else:
                    e.cd -= dt
                    if e.cd <= 0:
                        e.cd = 0.8
                        prey.hurt(e.dmg)
                        e.swing = 0.22
                        self.slash_fx(e.x, e.y - 8, math.atan2(prey.y - e.y, prey.x - e.x),
                                      (255, 150, 140))
                        self.star_fx(prey.x, prey.y - 8, (255, 170, 150))
                continue

            # 夜里袭击队收工
            if self.phase == "night" and e.mode == "raid":
                hx, hy = own["x"], own["y"]
                self.enemy_step(e, hx, hy, dt, 1.0)
                continue

            # 夜里守家
            if self.phase == "night" and e.mode != "raid":
                hx, hy = own["x"], own["y"]
                if dist((e.x, e.y), (hx, hy)) > 180:
                    self.move_towards(e, (hx, hy), dt, 0.9)
                elif random.random() < dt * 0.5:
                    e.target = (hx + random.uniform(-100, 100), hy + random.uniform(-100, 100))
                if e.target:
                    self.move_towards(e, e.target, dt, 0.45)
                continue

            # 守卫：白天也不出门，只在自己营地附近转
            if e.mode != "raid":
                hx, hy = own["x"], own["y"]
                if dist((e.x, e.y), (hx, hy)) > 220:
                    self.move_towards(e, (hx, hy), dt, 0.8)
                elif random.random() < dt * 0.4:
                    e.target = (hx + random.uniform(-110, 110), hy + random.uniform(-110, 110))
                if e.target:
                    self.move_towards(e, e.target, dt, 0.4)
                continue

            # 白天：出去打别人的营地（玩家或另一座营）
            if e.target_struct is None or random.random() < dt * 0.15:
                e.target_struct = self.pick_structure(e.x, e.y, exclude_camp=own, k=2)
            if e.target_struct is None:
                continue
            kind, target_camp = e.target_struct
            if kind == "camp" and target_camp["owner"] == "ruin":
                e.target_struct = None
                continue
            tx, ty = (self.keep if kind == "keep" else (target_camp["x"], target_camp["y"]))
            td = math.hypot(tx - e.x, ty - e.y)
            if td > 120:
                self.enemy_step(e, tx, ty, dt, 0.8)
            else:
                res = self.damage_structure(kind, target_camp, e.dmg * 0.9 * dt, e.x, e.y)
                if res and random.random() < dt * 4:
                    self.slash_fx(e.x, e.y - 8, math.atan2(ty - e.y, tx - e.x), (255, 150, 140))

    def update_camps(self, dt):
        self.army_order = max(0.0, self.army_order - dt)
        if self.state == "playing" and self.camps and \
                all(c["owner"] == "mine" for c in self.camps):
            self.state = "win"
            self.flash = 1.0
            self.shake = 0.8
            self.say("所有敌方营地都插上了我们的旗！", 9.0)
            return
        for c in self.camps:
            if c["owner"] == "enemy":
                c["timer"] -= dt
                if c["timer"] <= 0:
                    c["timer"] = max(70.0, 135.0 - self.day * 8)
                    num = 1 + int(c["power"] * 1.1)
                    for _ in range(num):
                        ang = random.uniform(0, math.tau)
                        u = Unit(clamp(c["x"] + math.cos(ang) * 60, 40, WORLD_W - 40),
                                 clamp(c["y"] + math.sin(ang) * 60, 40, WORLD_H - 40),
                                 "guard", team="enemy")
                        u.mode = "raid"
                        u.life = 90.0
                        u.target_struct = None
                        u.camp = c
                        u.faction = c["id"]
                        u.home = (c["x"], c["y"])
                        u.max_hp = 8.0 * c["power"] + self.day * 0.5
                        u.hp = u.max_hp
                        u.dmg = 1.1 + c["power"] * 0.8
                        self.enemy_units.append(u)
                    self.say("敌方营地派人来袭！", 2.2)
                if c["hp"] > 0:
                    c["hp"] = min(c["max"], c["hp"] + 1.2 * dt)
            elif c["owner"] == "mine":
                c["t"] += dt
                if c["t"] >= 9.0:
                    c["t"] = 0.0
                    c["purse"] = min(8, c["purse"] + 1)
                if c["hp"] <= 0:
                    c["owner"] = "ruin"
                    self.say("分营地被摧毁了", 2.5)

        # 玩家攻击营地
        p = self.player.pos()
        for c in self.camps:
            if c["owner"] == "mine" and dist(p, (c["x"], c["y"])) < 64 and c["purse"] > 0:
                self.coins += c["purse"]
                self.popups.append(Popup(c["x"], c["y"] - 30, "+%d" % c["purse"]))
                c["purse"] = 0

    def roll_weather(self):
        old_w = getattr(self, "weather", "clear")
        if self.day % 8 == 0:
            self.weather = "rain"          # 血月必下雨
            return
        self.weather = random.choice(["clear", "clear", "clear", "rain", "fog", "snow"])
        if getattr(self, "weather", "clear") != old_w:
            eff = {"clear": "农产 +10%", "rain": "弓手/箭塔射程 -25%",
                   "fog": "远程射程 -38%，怪更快", "snow": "双方移速 -15%"}[self.weather]
            self.say("天气转为%s：%s" % ({"clear": "晴", "rain": "雨", "fog": "雾", "snow": "雪"}[self.weather], eff), 3.2)

    def roll_event(self):
        if random.random() > 0.45:
            return
        ev = random.choice(["merchant", "wanderer", "plague", "harvest"])
        if ev == "merchant":
            self.coins += 15
            self.say("商人路过，留下 15 金币", 3.0)
        elif ev == "wanderer":
            u = Unit(self.keep[0] + random.uniform(-60, 60), self.keep[1] + random.uniform(70, 110))
            self.units.append(u)
            self.say("一名流浪骑士加入了营地", 3.0)
        elif ev == "plague" and len(self.units) > 2:
            victim = random.choice([u for u in self.units if u.role == "idle"] or self.units)
            victim.dead = True
            self.say("营地爆发疫病，走了一位居民", 3.0)
        elif ev == "harvest":
            self.coins += 10
            self.say("今年丰收，额外获得 10 金币", 3.0)

    def pick_chronicle(self):
        lines = [
            "第 %d 天，瞭望塔报告：东边有火光。",
            "第 %d 天，木匠说城墙的木头该换了。",
            "第 %d 天，孩子们在墙根下捡到一枚旧币。",
            "第 %d 天，风从北边来，带着一股铁锈味。",
            "第 %d 天，猎人在林子里发现了很多脚印。",
            "第 %d 天，哨兵换了三轮，没人敢合眼。",
            "第 %d 天，有人在墙上刻了一道新痕。",
        ]
        return random.choice(lines) % self.day

    def start_game(self, lvl):
        self.difficulty = lvl
        if lvl == 1:
            self.diff_scale = {"hp": 0.7, "income": 1.2}
        elif lvl == 3:
            self.diff_scale = {"hp": 1.35, "income": 1.15}
        else:
            self.diff_scale = {"hp": 1.0, "income": 1.0}
        self.state = "playing"
        self.say({1: "和平模式：怪物更弱，收入更高", 2: "普通模式", 3: "残酷模式：怪物更强"}[lvl], 3.0)

    def quick_repair(self):
        if self.coins < 10:
            self.deny("修墙需要 10 金币")
            return
        self.coins -= 10
        self.coin_pulse = 0.3
        for w in self.walls:
            w.hp = w.max_hp
        self.say("城墙全部修好", 2.0)

    def quick_recruit(self):
        if self.coins < 6:
            self.deny("补员需要 6 金币")
            return
        self.coins -= 6
        self.coin_pulse = 0.3
        u = Unit(self.keep[0] + random.uniform(-50, 50), self.keep[1] + random.uniform(70, 110))
        self.units.append(u)
        self.say("来了一名新居民", 2.0)

    def station_troops(self):
        p = self.player.pos()
        for c in self.camps:
            if c["owner"] == "mine" and dist(p, (c["x"], c["y"])) < 180:
                stationed = [u for u in self.units if getattr(u, "garrison", None) is c]
                if stationed:
                    for u in stationed:
                        u.garrison = None
                    self.say("已撤回 %d 名驻军" % len(stationed), 2.6)
                else:
                    free = [u for u in self.units if getattr(u, "garrison", None) is None]
                    free.sort(key=lambda u: dist(u.pos(), (c["x"], c["y"])))
                    take = free[:3]
                    for u in take:
                        u.garrison = c
                    self.say("驻军 %d 人就位，他们会在分营地周围防守" % len(take), 3.0)
                return
        self.say("走到自己的分营地旁按 H 驻扎", 2.6)

    def plant_flag(self):
        p = self.player.pos()
        for c in self.camps:
            if c["owner"] == "ruin" and dist(p, (c["x"], c["y"])) < 110:
                if self.coins < 30:
                    self.deny("插旗需要 30 金币")
                    return
                self.coins -= 30
                c["owner"] = "mine"
                c["hp"] = c["max"]
                for w in c["walls"]:
                    w.level = 2
                    w.max_hp = 150.0
                    w.hp = w.max_hp
                c["max"] = max(c["max"], 520.0)
                c["level"] = max(c["level"], 2)
                for e in self.enemy_units:
                    if dist((e.x, e.y), (c["x"], c["y"])) < 420:
                        e.dead = True
                self.shake = 0.5
                self.popups.append(Popup(c["x"], c["y"] - 30, "插旗！", (210, 240, 255)))
                self.say("这里成为我们的分营地，会自己产钱，也会被怪攻击", 4.0)
                return
        self.say("附近没有可插旗的废墟")

    def order_attack(self):
        if self.state != "playing":
            return
        if self.nearest_enemy_camp(self.player.x, self.player.y) is None:
            self.say("附近没有敌方营地了")
            return
        self.army_order = 26.0
        self.say("全军出击！骑士正在杀向敌方营地", 3.0)

    def update_nest(self, dt):
        n = self.nest
        if n is None:
            return
        n["bob"] += dt * 2.2
        n["cd"] -= dt
        if self.phase == "night" and n["cd"] <= 0:
            n["cd"] = 9.0
            hp = 5.0 + self.day * 1.4
            dmg = 2.2 + self.day * 0.7
            for _ in range(2):
                ang = random.uniform(0, math.tau)
                self.monsters.append(Monster(clamp(n["x"] + math.cos(ang) * 60, 40, WORLD_W - 40),
                                             clamp(n["y"] + math.sin(ang) * 60, 40, WORLD_H - 40),
                                             hp, dmg, 38 + self.day))
        if n["hp"] <= 0:
            pass

    def damage_nest(self, amount):
        n = self.nest
        if n is None or n["hp"] <= 0:
            return
        n["hp"] = max(0.0, n["hp"] - amount)

    # ---------------- waves
    def spawn_wave(self):
        self.blood = (self.day % 8 == 0) or (self.day % 8 == 1 and self.day > 1 and self.day == 9)
        self.blood = (self.day % 8 == 0)
        if self.blood:
            self.blood_count += 1
        count = min(24, 2 + int((self.day - 1) * 2.2))
        hp = 5.0 + self.day * 1.4
        dmg = 1.8 + self.day * 0.65
        scale = 1.0 + (self.island - 1) * 0.35
        hp *= scale
        dmg *= scale
        count = int(count * (1.0 + (self.island - 1) * 0.25))
        if self.blood:
            count = int(count * 1.75)
            hp *= 1.4
            dmg *= 1.25
        hp *= self.diff_scale["hp"]
        dmg *= self.diff_scale["hp"] * 0.9
        speed = 34 + self.day * 1.6
        speed *= 0.85 if self.weather == "snow" else (1.05 if self.weather == "fog" else 1.0)
        kx, ky = self.keep
        for i in range(count):
            ang = random.uniform(0, math.tau)
            rad = random.uniform(self.wall_half + 380, self.wall_half + 640)
            x = clamp(kx + math.cos(ang) * rad, 20, WORLD_W - 20)
            y = clamp(ky + math.sin(ang) * rad, 20, WORLD_H - 20)
            roll = random.random()
            if self.day >= 3 and i % 5 == 0:
                mon = Monster(x, y, hp * 2.2, dmg * 1.5, speed * 0.8, "brute")
            elif self.blood and self.blood_count >= 3 and roll < 0.22:
                mon = Monster(x, y, hp * 0.6, dmg * 0.8, speed * 1.5, "flyer")
            elif self.day >= 2 and roll < 0.34:
                mon = Monster(x, y, hp * 0.8, dmg * 0.9, speed * 0.75, "thrower")
            elif self.day >= 4 and roll < 0.46:
                mon = Monster(x, y, hp * 0.7, dmg * 0.6, speed * 1.25, "bomber")
            elif self.day >= 5 and roll < 0.58:
                mon = Monster(x, y, hp * 1.8, dmg * 0.8, speed * 0.7, "shield")
            else:
                mon = Monster(x, y, hp, dmg, speed)
            mon.target_struct = self.pick_structure(x, y, k=1 if random.random() < 0.75 else 3)
            self.monsters.append(mon)
        if self.blood:
            self.say("血月！第 %d 夜：%d 只怪冲过来了！" % (self.day, count), 3.6)
        else:
            self.say("第 %d 夜：%d 只怪冲过来了！" % (self.day, count), 3.0)

    # ---------------- update
    def update(self, dt, keys=()):
        if self.state == "menu":
            return
        if self.state != "playing":
            return
        if self.hitstop > 0:
            self.hitstop -= dt
            dt *= 0.25
        self.t += dt
        self.clock += dt
        self.message_t = max(0.0, self.message_t - dt)
        self.flash = max(0.0, self.flash - dt * 1.4)
        if self.promo is not None:
            self.promo[1] -= dt
            if self.promo[1] <= 0:
                self.promo = None
        if self.dawn is not None:
            self.dawn["t"] -= dt
            if self.dawn["t"] <= 0:
                self.dawn = None
        self.promo = None
        if self.coins > self.peak_coins:
            self.peak_coins = self.coins
        self.coin_pulse = max(0.0, self.coin_pulse - dt)
        self.deny_flash = max(0.0, self.deny_flash - dt)
        self.shake = max(0.0, self.shake - dt * 2.2)
        for t in self.toasts:
            t[1] -= dt
        self.toasts = [t for t in self.toasts if t[1] > 0]

        if self.day > 30 and self.state == "playing":
            self.survive_win = True
            self.state = "win"
            return

        # second wave at mid-night
        if self.phase == "night" and not self.second_wave_done and self.phase_t < NIGHT_LEN * 0.45:
            self.second_wave_done = True
            extra = 1 + int(self.day * 0.7)
            hp = 3.0 + self.day * 1.1
            dmg = 2.0 + self.day * 0.7
            kx, ky = self.keep
            for _ in range(extra):
                ang = random.uniform(0, math.tau)
                rad = random.uniform(self.wall_half + 380, self.wall_half + 620)
                self.monsters.append(Monster(clamp(kx + math.cos(ang) * rad, 20, WORLD_W - 20),
                                             clamp(ky + math.sin(ang) * rad, 20, WORLD_H - 20),
                                             hp, dmg, 36 + self.day * 1.4))
            self.say("夜里又冲来一波！", 2.4)

        # phase
        self.phase_t -= dt
        if self.phase_t <= 0:
            if self.phase == "day":
                self.phase = "night"
                self.phase_t = NIGHT_LEN
                play_sfx("horn")
                self._k0, self._l0 = self.stats_kills, self.stats_lost
                self.second_wave_done = False
                self.spawn_wave()
            else:
                self.phase = "day"
                self.nights_done += 1
                if False:
                    self.open_dock()
                if self.nights_done >= 3 and self.island >= 3:
                    self.state = "win"
                    self.say("第三座岛也守住了！", 9.0)
                    return
                self.day += 1
                self.phase_t = DAY_LEN
                self.roll_weather()
                self.roll_event()
                self.chronicle = self.pick_chronicle()
                kills = self.stats_kills - getattr(self, "_k0", 0)
                lost = self.stats_lost - getattr(self, "_l0", 0)
                wall_pct = int(sum(w.ratio for w in self.walls) / max(len(self.walls), 1) * 100)
                self.dawn = {"kills": kills, "lost": lost, "income": 0, "wall": wall_pct, "t": 10.0}
                self.safe_day = self.blood
                bonus = 6 + self.day * 2
                if self.safe_day:
                    bonus = int(bonus * 1.5)
                self.coins += bonus
                self.coin_pulse = 0.35
                self.popups.append(Popup(self.keep[0], self.keep[1] - 90, "+%d" % bonus, (255, 236, 150)))
                if self.dawn is not None:
                    self.dawn["income"] = bonus
                # 黎明：城墙自动修补一部分（参考 Thronefall 的"战后自动修复"）
                for w in self.walls:
                    w.hp = min(w.max_hp, w.hp + w.max_hp * 0.18)
                # 黎明：补一个免费居民
                if len(self.units) < 4:
                    u = Unit(self.keep[0] + random.uniform(-50, 50), self.keep[1] + random.uniform(70, 110))
                    self.units.append(u)
                    self.say("第 %d 天：守住了一夜，奖励 %d 金币，来了 1 个新居民" % (self.day, bonus), 3.4)
                else:
                    self.say("第 %d 天：守住了一夜，奖励 %d 金币，城墙被自动修补" % (self.day, bonus), 3.4)

        self.update_player(dt, keys)
        self.rebuild_grids()
        for u in self.units:
            self.update_unit(u, dt)
        self._sep_t = getattr(self, "_sep_t", 0.0) + dt
        if self._sep_t >= 0.05:
            self._sep_t = 0.0
            self.separate_units(dt * 20)
        for m in self.monsters:
            self.update_monster(m, dt)
        self.update_nest(dt)
        # 大本营：附近无敌人时缓慢自愈
        if self.keep_hp < self.keep_max:
            kx, ky = self.keep
            threat_near = any(dist(m.pos(), (kx, ky)) < 620 for m in self.monsters) or \
                          any(dist(e.pos(), (kx, ky)) < 620 for e in self.enemy_units)
            if not threat_near:
                self.keep_hp = min(self.keep_max, self.keep_hp + 2.5 * dt)
        self.update_projects(dt)
        self.update_camps(dt)
        self.update_enemy_units(dt)
        self.update_buildings(dt)
        for r in self.refugees:
            r.update(dt)
        if self.phase == "day":
            self.refugee_timer -= dt
            if self.refugee_timer <= 0:
                self.refugee_timer = 22.0
                if len(self.refugees) < 3 and random.random() < 0.8:
                    self.spawn_refugee()
        for a in self.animals:
            self.update_animal(a, dt)
        self.animal_timer -= dt
        if self.phase == "day" and self.animal_timer <= 0:
            self.animal_timer = 7.0
            if len(self.animals) < min(12, 3 + self.day):
                self.spawn_animal()
        for sl in self.slashes:
            sl[3] -= dt
        self.slashes = [x for x in self.slashes if x[3] > 0]
        for st in self.stars:
            st[2] -= dt
        self.stars = [x for x in self.stars if x[2] > 0]
        for ar in self.arrows:
            ar[4] += dt
        self.arrows = [a for a in self.arrows if a[4] < a[5]]
        for c in self.coins_world:
            c.life -= dt
            if c.life <= 0:
                c.dead = True
        for p in self.popups:
            p.update(dt)
        for h in self.hits:
            h[2] -= dt
        self.hits = [h for h in self.hits if h[2] > 0]

        for u in self.units:
            if u.dead:
                self.stats_lost += 1
                self.popups.append(Popup(u.x, u.y - 20, "阵亡", (255, 180, 170)))
        self.units = [u for u in self.units if not u.dead]
        self.stats_kills += sum(1 for m in self.monsters if m.dead)
        self.monsters = [m for m in self.monsters if not m.dead]
        self.animals = [a for a in self.animals if not a.dead]
        self.enemy_units = [e for e in self.enemy_units if not e.dead]
        self.coins_world = [c for c in self.coins_world if not c.dead]
        self.popups = [p for p in self.popups if not p.dead]

        kx, ky = self.keep

    def update_player(self, dt, keys):
        p = self.player
        vx = vy = 0.0
        if "w" in keys or "up" in keys:
            vy -= 1
        if "s" in keys or "down" in keys:
            vy += 1
        if "a" in keys or "left" in keys:
            vx -= 1
        if "d" in keys or "right" in keys:
            vx += 1
        if vx or vy:
            L = math.hypot(vx, vy)
            p.x += vx / L * p.speed * dt
            p.y += vy / L * p.speed * dt
            if abs(vx) > 0.1:
                p.facing = 1 if vx > 0 else -1
        p.x = clamp(p.x, 24, WORLD_W - 24)
        p.y = clamp(p.y, 24, WORLD_H - 24)

        # 攻击贪婪之巢
        if self.nest is not None and self.nest["hp"] > 0 and dist(p.pos(), (self.nest["x"], self.nest["y"])) < 78:
            self.damage_nest(7.0 * dt)
            if random.random() < dt * 5:
                self.hits.append([self.nest["x"] + random.uniform(-20, 20), self.nest["y"] + random.uniform(-20, 10), 0.12])

        # collect purses and coins
        for u in self.units:
            if u.purse > 0 and dist(p.pos(), u.pos()) < 30:
                self.coins += u.purse
                play_sfx("coin", 0.18)
                self.popups.append(Popup(u.x, u.y - 24, "+%d" % u.purse))
                u.purse = 0
        for b in self.buildings:
            if b["type"] == "farm" and b["purse"] > 0 and dist(p.pos(), (b["x"], b["y"])) < 52:
                self.coins += b["purse"]
                self.popups.append(Popup(b["x"], b["y"] - 26, "+%d" % b["purse"]))
                b["purse"] = 0
        for c in self.coins_world:
            if not c.dead and dist(p.pos(), c.pos()) < 28:
                c.dead = True
                self.coins += 1
                self.popups.append(Popup(c.x, c.y - 18, "+1"))

    def update_unit(self, u, dt):
        kx, ky = self.keep
        u.moving = False
        if u.atk_t > 0:
            u.atk_t -= dt
            if u.atk == "draw" and u.atk_t <= 0:
                if u.pending is not None:
                    tgt, dmg, col = u.pending
                    u.pending = None
                    if tgt is not None and not getattr(tgt, "dead", True):
                        self.shoot(u, tgt, dmg, col)
                        u.atk = "release"
                        u.atk_t = 0.14
                        continue_after_shot = True
                    else:
                        u.atk = "idle"
                else:
                    u.atk = "idle"
            elif u.atk in ("release", "swing", "stagger") and u.atk_t <= 0:
                u.atk = "idle"
        # 兜底：任何异常状态 1 秒后强制回到 idle，避免卡死不动
        if u.atk not in ("idle", "draw", "release", "swing", "stagger"):
            u.atk = "idle"
        if u.role in ("idle", "worker", "lumber", "farmer") and u.garrison is None:
            threat = None
            td = 150.0
            for e in self.enemy_units:
                if e.dead:
                    continue
                d = dist(e.pos(), u.pos())
                if d < td:
                    threat, td = e, d
            for m in self.monsters:
                if m.dead:
                    continue
                d = dist(m.pos(), u.pos())
                if d < td:
                    threat, td = m, d
            if threat is not None:
                self.move_towards(u, (kx + random.uniform(-60, 60), ky + random.uniform(0, 80)), dt, 1.35)
                return
        gar = getattr(u, "garrison", None)
        if gar is not None:
            if gar.get("owner") != "mine":
                u.garrison = None
            else:
                if dist(u.pos(), (gar["x"], gar["y"])) > 175:
                    self.move_towards(u, (gar["x"], gar["y"]), dt, 1.1)
                    return
                tgt = self.pick_near(self.hostile_units(), u.x, u.y, 2, 250)
                if tgt is not None:
                    dd = dist(u.pos(), tgt.pos())
                    if dd > 34:
                        self.move_towards(u, tgt.pos(), dt, 1.0)
                    elif u.cd <= 0:
                        u.cd = 0.8
                        tgt.hurt(2.4, "melee")
                        u.swing = 0.22
                        self.slash_fx(u.x, u.y - 10, math.atan2(tgt.y - u.y, tgt.x - u.x))
                        self.star_fx(tgt.x, tgt.y - 8)
                else:
                    ang = math.atan2(u.y - gar["y"], u.x - gar["x"]) + dt * 0.5
                    u.x = gar["x"] + math.cos(ang) * 90
                    u.y = gar["y"] + math.sin(ang) * 90
                return
        u.bob += dt * 7
        if getattr(u, "swing", 0) > 0:
            u.swing = max(0.0, u.swing - dt)
        if u.role == "idle":
            if not hasattr(u, "home"):
                u.home = (u.x, u.y)
            if random.random() < dt * 0.6:
                u.target = (u.home[0] + random.uniform(-40, 40), u.home[1] + random.uniform(-30, 30))
            self.move_towards(u, u.target, dt, 0.5)
            return

        if u.role == "worker":
            if self.projects:
                pj = min(self.projects, key=lambda q: dist(u.pos(), (q["x"], q["y"])))
                spot = (pj["x"] + random.uniform(-16, 16), pj["y"] + random.uniform(10, 26))
                if dist(u.pos(), spot) > 30:
                    self.move_towards(u, spot, dt, 1.0)
                else:
                    pj["prog"] += dt * 0.95
                    if random.random() < dt * 4:
                        self.hits.append([pj["x"], pj["y"], 0.1])
                return
            broken = min(self.walls, key=lambda w: w.ratio)
            if broken.ratio < 1.0:
                spot = broken.mid()
                spot = (spot[0] + random.uniform(-30, 30), spot[1] + random.uniform(-30, 30))
                if dist(u.pos(), spot) > 34:
                    self.move_towards(u, spot, dt, 1.0)
                else:
                    broken.hp = min(broken.max_hp, broken.hp + 22 * dt)
                    if random.random() < dt * 3:
                        self.hits.append([broken.mid()[0], broken.mid()[1], 0.1])
            else:
                self.move_towards(u, (kx + random.uniform(-70, 70), ky + random.uniform(-40, 70)), dt, 0.35)
            return

        if u.role == "hunter":
            going_home = self.phase == "night" or (self.phase == "day" and self.phase_t < 14)
            if going_home:
                u._tg = getattr(u, "_tg", 0.0) - dt
                threat = getattr(u, "_target", None)
                if threat is not None and (getattr(threat, "dead", True) or
                                           dist(threat.pos(), u.pos()) > 520):
                    threat = None
                if threat is None or u._tg <= 0:
                    threat = self.pick_hostile(u.x, u.y, 2, 460)
                    u._target = threat
                    u._tg = 0.5
                # 墙垛位置：锁 1.5 秒不换，避免左右横跳
                u.wall_t = getattr(u, "wall_t", 0.0) - dt
                if getattr(u, "wall_post", None) is None or u.wall_t <= 0:
                    if threat is not None:
                        ang = math.atan2(threat.y - ky, threat.x - kx)
                    else:
                        ang = u.jit
                    u.wall_post = (kx + math.cos(ang) * (self.wall_half - 36),
                                   ky + math.sin(ang) * (self.wall_half - 36))
                    u.wall_t = 1.5
                post = u.wall_post
                if dist(u.pos(), post) > 34:
                    u.on_wall = False
                    self.move_towards(u, post, dt, 1.15)
                    return
                u.on_wall = True
                if threat is not None:
                    rng = 360 if self.weather == "rain" else 420
                    if u.cd <= 0 and (u.atk != "draw") and dist(u.pos(), threat.pos()) < rng:
                        u.cd = 1.7 / self.keep_buff(u.x, u.y)
                        rngm = {"rain": 0.75, "fog": 0.55}.get(self.weather, 1.0)
                        dmg = 0.9 * 1.2 * self.statue_buff("hunter", u.x, u.y) * rngm
                        u.face = 1 if threat.x > u.x else -1
                        u.atk = "draw"
                        u.atk_t = 0.22
                        u.pending = (threat, dmg, (240, 224, 160))
                        if getattr(u, "veteran", False):
                            self.fire_arrow(u.x, u.y - 16, threat.x + random.uniform(-14, 14),
                                            threat.y - 8, (255, 240, 190), 0.3)
                    u.cd -= dt
            else:
                u.on_wall = False
                prey = self.pick_animal(u.x, u.y, 2, 900)
                bd = dist(u.pos(), prey.pos()) if prey is not None else 1e9
                if prey is not None:
                    if bd > 300:
                        self.move_towards(u, prey.pos(), dt, 1.0)
                    elif u.cd <= 0 and u.atk != "draw":
                        u.cd = 2.1
                        u.atk = "draw"
                        u.atk_t = 0.2
                        u.face = 1 if prey.x > u.x else -1
                        u.pending = (prey, 1.0, (250, 236, 190))
                        if prey.dead:
                            u.purse += 1
                            self.popups.append(Popup(prey.x, prey.y - 18, "+1 猎物", (214, 246, 210)))
                    u.cd -= dt
                else:
                    if u.target is None or random.random() < dt * 0.4:
                        u.target = (clamp(kx + random.uniform(-720, 720), 40, WORLD_W - 40),
                                    clamp(ky + random.uniform(-620, 620), 40, WORLD_H - 40))
                    self.move_towards(u, u.target, dt, 0.6)
            return

        if u.role == "knight":
            # 先打人：附近有敌对单位时优先，没有才去拆营地
            nearby_unit = self.pick_hostile(u.x, u.y, 1, 520)
            camp = None
            if nearby_unit is None:
                if self.army_order > 0:
                    camp = self.nearest_enemy_camp(u.x, u.y, 2600)
                else:
                    camp = self.nearest_enemy_camp(u.x, u.y, 380)
            if camp is not None:
                if not self.camp_inside(camp, u.x, u.y):
                    wall = self.camp_nearest_wall(camp, u.x, u.y)
                    if wall is not None:
                        mx, my = wall.mid()
                        d = dist(u.pos(), (mx, my))
                        if d > 58:
                            self.move_towards(u, (mx, my), dt, 1.0)
                        else:
                            if u.cd <= 0:
                                u.cd = 0.6
                                wall.hp = max(0.0, wall.hp - 6.0)
                                u.swing = 0.24
                                self.slash_fx(u.x, u.y - 10, math.atan2(my - u.y, mx - u.x))
                                self.star_fx(mx, my, (220, 200, 160))
                                self.hits.append([mx, my, 0.1])
                            u.cd -= dt
                        return
                d = dist(u.pos(), (camp["x"], camp["y"]))
                if d > 80:
                    self.move_towards(u, (camp["x"], camp["y"]), dt, 1.0)
                elif u.cd <= 0:
                    u.cd = 0.6
                    camp["hp"] -= 5.0
                    u.swing = 0.24
                    self.slash_fx(u.x, u.y - 10, math.atan2(camp["y"] - u.y, camp["x"] - u.x))
                    self.star_fx(camp["x"], camp["y"] - 10, (255, 220, 170))
                    self.hits.append([camp["x"], camp["y"], 0.1])
                    if camp["hp"] <= 0:
                        camp["owner"] = "ruin"
                        self.say("敌方大本营被拆了！过去按 F 插旗", 4.0)
                u.cd -= dt
                return
            target = self.pick_hostile(u.x, u.y, 3, 900)
            if target is not None:
                d = dist(u.pos(), target.pos())
                if d > 46:
                    spot = (target.x + math.cos(u.jit) * 22, target.y + math.sin(u.jit) * 22)
                    self.move_towards(u, spot, dt, 1.0)
                elif u.cd <= 0:
                    u.cd = 0.55
                    dxk, dyk = target.x - u.x, target.y - u.y
                    Lk = math.hypot(dxk, dyk) or 1
                    target.x += dxk / Lk * 7
                    target.y += dyk / Lk * 7
                    lx, ly = target.x - u.x, target.y - u.y
                    Ld = math.hypot(lx, ly) or 1
                    u.x += lx / Ld * 5
                    u.y += ly / Ld * 5
                    u.face = 1 if lx > 0 else -1
                    u.atk = "swing"
                    u.atk_t = 0.22
                    dmg_val = 2.4 * self.statue_buff("knight", u.x, u.y)
                    target.hurt(dmg_val)
                    if random.random() < 0.5:
                        self.popups.append(Popup(target.x + random.uniform(-8, 8), target.y - 26,
                                                 "-%d" % max(1, int(dmg_val)), (255, 220, 200)))
                    u.swing = 0.24
                    self.slash_fx(u.x, u.y - 10, math.atan2(target.y - u.y, target.x - u.x))
                    self.star_fx(target.x, target.y - 8,
                                 (255, 255, 220) if getattr(target, "atk", "") == "swing"
                                 else (255, 230, 160))
                    self.hits.append([target.x, target.y, 0.12])
                    if target.dead:
                        self.coins_world.append(Coin(target.x, target.y))
                        self.add_kill(u)
                u.cd -= dt
            else:
                self.move_towards(u, (kx + random.uniform(-110, 110), ky + random.uniform(-90, 90)), dt, 0.5)
            return

        if u.role == "farmer":
            farm = getattr(u, "farm", None)
            if farm is not None and farm.get("worker") is not u:
                farm = None
            if farm is None:
                free = [b for b in self.buildings if b["type"] == "farm"
                        and (b.get("worker") is None or getattr(b.get("worker"), "dead", True))]
                if free:
                    farm = min(free, key=lambda b: dist(u.pos(), (b["x"], b["y"])))
                    farm["worker"] = u
                    u.farm = farm
                else:
                    u.farm = None
            if farm is None:
                self.move_towards(u, (kx + random.uniform(-90, 90), ky + random.uniform(40, 110)), dt, 0.4)
                return
            if dist(u.pos(), (farm["x"], farm["y"])) > 46:
                self.move_towards(u, (farm["x"], farm["y"] + 24), dt, 0.9)
            return

        if u.role == "lumber":
            going_home = self.phase == "night" or (self.phase == "day" and self.phase_t < 14)
            if going_home:
                if not self.inside_walls(u.x, u.y):
                    self.move_towards(u, (kx + random.uniform(-70, 70), ky + random.uniform(-70, 70)), dt, 1.2)
                return
            tree = None
            bd = 1e9
            for t in self.trees:
                if t.dead:
                    continue
                d = dist(u.pos(), t.pos())
                if d < bd:
                    tree, bd = t, d
            if tree is None:
                self.move_towards(u, (kx, ky + 40), dt, 0.4)
                return
            if bd > 34:
                self.move_towards(u, tree.pos(), dt, 1.0)
            else:
                tree.hp -= 1.4 * dt
                if random.random() < dt * 4:
                    self.hits.append([tree.x, tree.y, 0.1])
                if tree.hp <= 0:
                    tree.dead = True
                    u.purse += 1
                    self.territory = min(760, self.territory + 11)
                    self.popups.append(Popup(tree.x, tree.y - 20, "+1", (200, 255, 200)))
            return

    def separate_units(self, dt):
        pool = [u for u in self.units if not u.dead]
        n = len(pool)
        for i in range(n):
            a = pool[i]
            for j in range(i + 1, n):
                b = pool[j]
                dx = b.x - a.x
                dy = b.y - a.y
                d2 = dx * dx + dy * dy
                if 0.01 < d2 < 26 * 26:
                    d = math.sqrt(d2)
                    push = (26 - d) * 1.6 * dt
                    ux, uy = dx / d * push, dy / d * push
                    a.x -= ux
                    a.y -= uy
                    b.x += ux
                    b.y += uy

    def move_towards(self, u, target, dt, speed_scale=1.0):
        if not target:
            return
        dx, dy = target[0] - u.x, target[1] - u.y
        d = math.hypot(dx, dy)
        if d < 4:
            return
        sp = u.speed * speed_scale * (0.85 if self.weather == "snow" else 1.0)
        u.x += dx / d * sp * dt
        u.y += dy / d * sp * dt
        u.walk += dt * 9.0
        u.moving = True
        if abs(dx) > 1:
            u.face = 1 if dx > 0 else -1

    def update_monster(self, m, dt):
        m.bob += dt * 6
        m.hit_flash = max(0.0, m.hit_flash - dt)

        if m.kind == "flyer":
            prey = None
            pd = 400.0
            for u in self.units + self.enemy_units:
                if u.dead:
                    continue
                d = dist(u.pos(), m.pos())
                if d < pd:
                    prey, pd = u, d
            if prey is not None:
                if pd > 30:
                    dx, dy = prey.x - m.x, prey.y - m.y
                    L = math.hypot(dx, dy) or 1
                    m.x += dx / L * m.speed * dt
                    m.y += dy / L * m.speed * dt
                else:
                    prey.hurt(m.dmg * 0.9 * dt)
                    if random.random() < dt * 3:
                        self.star_fx(prey.x, prey.y - 6, (255, 200, 200))
                return
            kx2, ky2 = self.keep
            dx, dy = kx2 - m.x, ky2 - m.y
            L = math.hypot(dx, dy) or 1
            if L < KEEP_R + 20:
                self.keep_hp = max(0.0, self.keep_hp - m.dmg * 0.8 * dt)
                if self.keep_hp <= 0:
                    self.lose_crown()
            else:
                m.x += dx / L * m.speed * dt
                m.y += dy / L * m.speed * dt
            return

        if getattr(m, "target_struct", None) is None:
            m.target_struct = self.pick_structure(m.x, m.y, k=3)
            if m.target_struct is None:
                return
        kind, camp = m.target_struct
        if kind == "camp" and camp["owner"] == "ruin":
            m.target_struct = None
            return
        tx, ty = self.struct_pos(kind, camp)
        walls = self.struct_walls(kind, camp)

        # 投石手：隔空砸墙
        if m.kind == "thrower":
            wall = None
            bd = 1e9
            for w in walls:
                if w.hp <= 0:
                    continue
                mx, my = w.mid()
                d = math.hypot(mx - m.x, my - m.y)
                if d < bd:
                    wall, bd = w, d
            if wall is not None and bd < 340:
                if bd > 250:
                    dx, dy = wall.mid()[0] - m.x, wall.mid()[1] - m.y
                    L = math.hypot(dx, dy) or 1
                    m.x += dx / L * m.speed * dt
                    m.y += dy / L * m.speed * dt
                else:
                    m.throw_cd -= dt
                    if m.throw_cd <= 0:
                        m.throw_cd = 2.6
                        wall.hp = max(0.0, wall.hp - m.dmg * 2.2)
                        self.fire_arrow(m.x, m.y - 14, wall.mid()[0], wall.mid()[1], (200, 170, 150), 0.4)
                        self.star_fx(wall.mid()[0], wall.mid()[1], (220, 190, 160))
                return

        # 爆裂怪：贴墙自爆
        if m.kind == "bomber":
            target_wall = None
            for w in walls:
                if w.hp > 0 and w.near(m.x, m.y, 40):
                    target_wall = w
                    break
            if target_wall is not None:
                target_wall.hp = max(0.0, target_wall.hp - 150.0)
                self.shake = min(1.0, self.shake + 0.25)
                self.hitstop = 0.06
                play_sfx("hit")
                self.star_fx(target_wall.mid()[0], target_wall.mid()[1], (255, 180, 130))
                m.dead = True
                return
            dx, dy = tx - m.x, ty - m.y
            L = math.hypot(dx, dy) or 1
            m.x += dx / L * m.speed * dt
            m.y += dy / L * m.speed * dt
            return

        # 攻击附近的任何单位（不分阵营）
        prey = None
        pd = 120.0
        cand = self.query_grid(getattr(self, "_grid_units", {}), m.x, m.y, 120) + \
            self.query_grid(getattr(self, "_grid_hostile", {}), m.x, m.y, 120)
        for d2, u in cand:
            if u is m or getattr(u, "dead", False):
                continue
            d = math.sqrt(d2)
            if d < pd:
                prey, pd = u, d
        if prey is not None:
            if pd > 34:
                dx, dy = prey.x - m.x, prey.y - m.y
                L = math.hypot(dx, dy) or 1.0
                nx, ny = m.x + dx / L * m.speed * dt, m.y + dy / L * m.speed * dt
                wall = None
                for w in walls:
                    if w.hp > 0 and w.near(nx, ny, 18):
                        wall = w
                        break
                if wall is not None:
                    wall.hp = max(0.0, wall.hp - m.dmg * dt)
                    if random.random() < dt * 3:
                        self.star_fx(wall.mid()[0], wall.mid()[1], (220, 190, 160))
                else:
                    m.x, m.y = nx, ny
            else:
                prey.hurt(m.dmg * 1.0 * dt)
                if random.random() < dt * 3:
                    self.slash_fx(m.x, m.y - 8, math.atan2(prey.y - m.y, prey.x - m.x),
                                  (255, 160, 150))
                    self.star_fx(prey.x, prey.y - 8, (255, 170, 150))
            return

        # 走向目标结构并拆墙
        d = math.hypot(tx - m.x, ty - m.y)
        if d < 150:
            res = self.damage_structure(kind, camp, m.dmg * 0.9 * dt, m.x, m.y)
            if res and random.random() < dt * 4:
                self.slash_fx(m.x, m.y - 8, math.atan2(ty - m.y, tx - m.x), (255, 160, 150))
            return
        dx, dy = tx - m.x, ty - m.y
        L = math.hypot(dx, dy) or 1
        nx, ny = m.x + dx / L * m.speed * dt, m.y + dy / L * m.speed * dt
        wall = None
        for w in walls:
            if w.hp > 0 and w.near(nx, ny, 20):
                wall = w
                break
        if wall is not None:
            wall.hp = max(0.0, wall.hp - m.dmg * dt)
            if random.random() < dt * 3:
                self.slash_fx(m.x, m.y - 6, math.atan2(ny - m.y, nx - m.x), (255, 160, 150))
            return
        m.x, m.y = nx, ny

    def draw(self, cam, view=(VIEW_W, VIEW_H)):
        vw, vh = view
        cx, cy = cam
        self.lights = []
        if not hasattr(self, "_frame_cache"):
            self._frame_cache = {}
        if not hasattr(self, "_rgb_cache"):
            self._rgb_cache = {}
        low = getattr(self, "low_detail", False)
        ix, iy = int(cx), int(cy)
        key = (vw, vh)
        frame = self._frame_cache.get(key)
        if frame is None:
            frame = Image.new("RGBA", (vw, vh))
            self._frame_cache[key] = frame
        tx0, ty0 = ix // TILE, iy // TILE
        tx1, ty1 = (ix + vw) // TILE, (iy + vh) // TILE
        tiles = self.tiles
        for ty in range(ty0, ty1 + 1):
            for tx in range(tx0, tx1 + 1):
                tile = tiles[(tx * 7 + ty * 13) % 3]
                frame.paste(tile, (tx * TILE - ix, ty * TILE - iy))
        d = ImageDraw.Draw(frame, "RGBA")

        if low:
            gx0, gx1 = 1, 0
        else:
            gx0, gx1 = ix // 320, (ix + vw) // 320
        gy0, gy1 = iy // 320, (iy + vh) // 320
        grid = self._decor_grid
        for cyi in range(gy0, gy1 + 1):
            for cxi in range(gx0, gx1 + 1):
                for idx in grid.get((cxi, cyi), ()):
                    kind, dx, dy, size, seed = self.decor[idx]
                    x, y = dx - cx, dy - cy
                    if not (-24 < x < vw + 24 and -24 < y < vh + 24):
                        continue
                    if kind == "tuft":
                        sway = math.sin(self.t * 1.6 + seed) * 1.6
                        d.line([(x, y), (x + sway - 1, y - size * 1.6)], fill=(100, 166, 96), width=2)
                        d.line([(x + 3, y), (x + 3 + sway, y - size * 1.2)], fill=(112, 178, 104), width=2)
                    elif kind == "flower":
                        col = [(240, 226, 150), (236, 196, 210), (204, 214, 240)][int(seed) % 3]
                        d.ellipse([x - size, y - size, x + size, y + size], fill=col)
                        d.ellipse([x - 1, y - 1, x + 1, y + 1], fill=(250, 236, 170))
                    elif kind == "stone":
                        d.ellipse([x - size, y - size * 0.7, x + size, y + size * 0.7],
                                  fill=(178, 176, 164), outline=(120, 118, 108))
                    else:
                        d.ellipse([x - size, y - size * 0.8, x + size, y + size * 0.8],
                                  fill=(96, 150, 92), outline=(70, 118, 70))
        kx, ky = self.keep

        def sx(x):
            return x - cx

        def sy(y):
            return y - cy

        # trees
        for ti, t in enumerate(self.trees):
            if t.dead or (low and ti % 2):
                continue
            x, y = sx(t.x), sy(t.y)
            if -70 < x < vw + 70 and -70 < y < vh + 70:
                s_ = t.scale
                shadow(d, x + 5, y + 16 * s_, 26 * s_, 9 * s_)
                d.rectangle([x - 5 * s_, y - 6 * s_, x + 5 * s_, y + 18 * s_],
                            fill=(118, 84, 56), outline=INK, width=2)
                sway = math.sin(self.t * 1.2 + t.seed) * 2
                if t.variant == 1:
                    for i in range(3):
                        w_ = (30 - i * 7) * s_
                        h_ = (22 - i * 4) * s_
                        yy = y - (14 + i * 15) * s_
                        d.polygon([(x - w_ + sway * 0.4, yy), (x + w_ + sway * 0.4, yy),
                                   (x + sway * 0.7, yy - h_)],
                                  fill=(64, 122, 78), outline=INK)
                else:
                    blob(d, x + sway, y - 24 * s_, 26 * s_, 24 * s_, (70, 134, 82), INK, 3)
                    blob(d, x - 13 * s_ + sway, y - 13 * s_, 16 * s_, 14 * s_, (88, 158, 96), INK, 3)
                    blob(d, x + 13 * s_ + sway, y - 15 * s_, 15 * s_, 13 * s_, (88, 158, 96), INK, 3)
                    blob(d, x + sway - 4, y - 30 * s_, 9 * s_, 6 * s_, (132, 194, 128), (72, 138, 84), 2)

        # keep
        self.draw_keep(d, sx(kx), sy(ky))
        if self.phase == "night" and self.state == "playing":
            r = 300
            pulse = 3 * math.sin(self.t * 2.2)
            d.ellipse([sx(kx) - r - pulse, sy(ky) - r * 0.72 - pulse,
                       sx(kx) + r + pulse, sy(ky) + r * 0.72 + pulse],
                      outline=(255, 226, 150, 70), width=2)

        # workshop
        wx, wy = sx(self.workshop[0]), sy(self.workshop[1])
        self.draw_workshop(d, wx, wy)

        # 营地
        for c in self.camps:
            cx_, cy_ = sx(c["x"]), sy(c["y"])
            if -180 < cx_ < vw + 180 and -180 < cy_ < vh + 180:
                self.draw_camp(d, c, cx_, cy_)

        # dock
        if self.dock is not None:
            self.draw_dock(d, sx(self.dock[0]), sy(self.dock[1]))

        # 施工工地
        for pj in self.projects:
            px, py = sx(pj["x"]), sy(pj["y"])
            if -90 < px < vw + 90 and -90 < py < vh + 90:
                self.draw_site(d, pj, px, py)

        # buildings
        for b in self.buildings:
            bx, by = sx(b["x"]), sy(b["y"])
            if -90 < bx < vw + 90 and -90 < by < vh + 90:
                if b["type"] == "farm":
                    self.draw_farm(d, b, bx, by)
                elif b["type"] == "tower":
                    self.draw_tower(d, b, bx, by)
                elif b["type"] == "barracks":
                    self.draw_barracks(d, b, bx, by)
                elif b["type"] == "hospital":
                    self.draw_hospital(d, b, bx, by)
                elif b["type"] == "trap":
                    self.draw_trap(d, b, bx, by)
                else:
                    self.draw_statue(d, b, bx, by)

        # walls
        for w in self.walls:
            self.draw_wall(d, w, sx, sy)

        # coins
        for c in self.coins_world:
            x, y = sx(c.x), sy(c.y)
            bounce = math.sin(self.t * 6 + c.bob) * 3
            blob(d, x, y + bounce, 8, 8, (248, 206, 84), (150, 110, 30), 2)
            d.ellipse([x - 3, y - 3 + bounce, x + 3, y + 3 + bounce], fill=(255, 238, 160), outline=None)

        # nest
        if self.nest is not None:
            nx, ny = sx(self.nest["x"]), sy(self.nest["y"])
            if -160 < nx < vw + 160 and -160 < ny < vh + 160:
                self.draw_nest(d, nx, ny, self.nest)
            else:
                self.draw_nest_arrow(d, nx, ny, vw, vh)

        # animals
        for a in self.animals:
            axx, ayy = sx(a.x), sy(a.y)
            if -60 < axx < vw + 60 and -60 < ayy < vh + 60:
                self.draw_animal(d, a, axx, ayy)

        # refugees
        for r in self.refugees:
            rxx, ryy = sx(r.x), sy(r.y)
            if -60 < rxx < vw + 60 and -60 < ryy < vh + 60:
                self.draw_refugee(d, r, rxx, ryy)

        # monsters
        heavy = low or (len(self.monsters) + len(self.units) > 60)
        self._heavy = heavy
        for m in self.monsters:
            x, y = sx(m.x), sy(m.y)
            if not (-90 < x < vw + 90 and -90 < y < vh + 90):
                continue
            kind = m.kind
            big = kind == "brute"
            if not heavy:
                shadow(d, x, y + (22 if big else 16), (28 if big else 18), (11 if big else 7))
            if m.hit_flash > 0:
                body = (244, 206, 244)
            else:
                body = {"imp": (150, 96, 168), "brute": (104, 64, 120),
                        "thrower": (128, 108, 176), "bomber": (96, 74, 96),
                        "shield": (120, 112, 104), "flyer": (176, 120, 190)}[kind]

            if heavy and kind in ("imp", "thrower", "bomber", "shield"):
                blob(d, x, y - 2, 18, 16, body, INK, 2)
                d.ellipse([x - 7, y - 8, x - 2, y - 3], fill=(255, 245, 235))
                d.ellipse([x + 2, y - 8, x + 7, y - 3], fill=(255, 245, 235))
                if m.hp < m.max_hp and getattr(m, "hp_flash", 0) > 0:
                    w = 30
                    d.rectangle([x - w / 2, y - 30, x + w / 2, y - 26], fill=(60, 40, 60), outline=INK)
                    d.rectangle([x - w / 2 + 1, y - 29,
                                 x - w / 2 + 1 + (w - 2) * m.hp / m.max_hp, y - 27], fill=(236, 120, 120))
                continue
            if kind == "imp":
                blob(d, x, y - 2, 19, 17, body, INK, 3)
                d.polygon([(x - 14, y - 12), (x - 8, y - 22), (x - 4, y - 12)], fill=body, outline=INK)
                d.polygon([(x + 4, y - 12), (x + 9, y - 23), (x + 14, y - 11)], fill=body, outline=INK)
                d.ellipse([x - 9, y - 8, x - 3, y - 2], fill=(255, 255, 255))
                d.ellipse([x + 3, y - 8, x + 9, y - 2], fill=(255, 255, 255))
                d.ellipse([x - 7, y - 6, x - 4, y - 3], fill=INK)
                d.ellipse([x + 5, y - 6, x + 8, y - 3], fill=INK)
            elif kind == "brute":
                blob(d, x, y - 4, 27, 24, body, INK, 4)
                for hx in (-20, 20):
                    d.polygon([(x + hx - 8, y - 18), (x + hx, y - 38), (x + hx + 8, y - 18)],
                              fill=(226, 216, 196), outline=INK)
                d.rounded_rectangle([x - 20, y + 2, x + 20, y + 16], radius=6,
                                    fill=(72, 44, 84), outline=INK, width=3)
                d.ellipse([x - 14, y - 12, x - 3, y - 1], fill=(255, 214, 90))
                d.ellipse([x + 3, y - 12, x + 14, y - 1], fill=(255, 214, 90))
                d.ellipse([x - 10, y - 9, x - 6, y - 4], fill=INK)
                d.ellipse([x + 6, y - 9, x + 10, y - 4], fill=INK)
            elif kind == "thrower":
                blob(d, x, y - 2, 20, 18, body, INK, 3)
                d.ellipse([x - 8, y - 8, x - 2, y - 2], fill=(255, 250, 220))
                d.ellipse([x + 2, y - 8, x + 8, y - 2], fill=(255, 250, 220))
                d.ellipse([x - 6, y - 6, x - 3, y - 3], fill=INK)
                d.ellipse([x + 4, y - 6, x + 7, y - 3], fill=INK)
                # 举着石头
                d.line([(x - 12, y - 10), (x - 16, y - 26)], fill=INK, width=4)
                d.line([(x + 12, y - 10), (x + 16, y - 26)], fill=INK, width=4)
                d.ellipse([x - 6, y - 38, x + 14, y - 20], fill=(150, 146, 138), outline=INK, width=3)
            elif kind == "flyer":
                flap = math.sin(self.t * 14) * 6
                body = (176, 120, 190) if m.hit_flash <= 0 else (250, 216, 250)
                d.polygon([(x - 8, y - 10), (x - 30, y - 18 - flap), (x - 10, y + 2)],
                          fill=(206, 170, 214), outline=INK, width=2)
                d.polygon([(x + 8, y - 10), (x + 30, y - 18 - flap), (x + 10, y + 2)],
                          fill=(206, 170, 214), outline=INK, width=2)
                blob(d, x, y - 6, 13, 12, body, INK, 3)
                d.ellipse([x - 7, y - 12, x - 2, y - 7], fill=(255, 210, 120))
                d.ellipse([x + 2, y - 12, x + 7, y - 7], fill=(255, 210, 120))
                d.polygon([(x - 4, y - 2), (x, y + 4), (x + 4, y - 2)], fill=(120, 60, 120), outline=INK)
            elif kind == "bomber":
                blob(d, x, y - 2, 17, 16, body, INK, 3)
                d.ellipse([x - 8, y - 7, x - 3, y - 2], fill=(255, 160, 90))
                d.ellipse([x + 3, y - 7, x + 8, y - 2], fill=(255, 160, 90))
                d.line([(x, y - 18), (x + 3, y - 26)], fill=INK, width=3)
                spark = 2 + abs(math.sin(self.t * 12)) * 3
                d.ellipse([x + 3 - spark, y - 26 - spark, x + 3 + spark, y - 26 + spark],
                          fill=(255, 220, 120))
            else:  # shield
                blob(d, x, y - 2, 22, 20, body, INK, 3)
                d.rounded_rectangle([x - 26, y - 16, x - 8, y + 18], radius=6,
                                    fill=(176, 170, 160), outline=INK, width=3)
                d.rounded_rectangle([x - 22, y - 10, x - 12, y + 12], radius=4,
                                    fill=(206, 200, 190), outline=(140, 134, 124), width=2)
                d.ellipse([x + 2, y - 10, x + 8, y - 4], fill=(255, 230, 150))
                d.ellipse([x + 10, y - 10, x + 16, y - 4], fill=(255, 230, 150))

            m.hp_flash = max(0.0, getattr(m, "hp_flash", 0) - 0.016)
            m.atk_t = max(0.0, getattr(m, "atk_t", 0.0) - 0.016)
            if m.atk_t > 0:
                y -= 1.6
            if m.hp < m.max_hp and m.hp_flash > 0:
                w = 52 if big else 34
                top = y - (46 if big else 36)
                d.rectangle([x - w / 2, top, x + w / 2, top + 5], fill=(60, 40, 60), outline=INK)
                d.rectangle([x - w / 2 + 1, top + 1,
                             x - w / 2 + 1 + (w - 2) * m.hp / m.max_hp, top + 4],
                            fill=(236, 120, 120))

        # 打击特效
        for sl in self.slashes:
            x, y, ang, life, color = sl[0], sl[1], sl[2], sl[3], sl[4]
            k = clamp(life / 0.22, 0, 1)
            r = 12 + (1 - k) * 22
            a0 = math.degrees(ang) - 58
            a1 = math.degrees(ang) + 58
            d.arc([sx(x) - r, sy(y) - r, sx(x) + r, sy(y) + r], a0, a1,
                  fill=color, width=max(2, int(5 * k)))
            r2 = r - 6
            d.arc([sx(x) - r2, sy(y) - r2, sx(x) + r2, sy(y) + r2], a0, a1,
                  fill=(255, 255, 235), width=max(1, int(2 * k)))
        for st in self.stars:
            x, y, life, color = st[0], st[1], st[2], st[3]
            k = clamp(life / 0.26, 0, 1)
            r0 = 3 + (1 - k) * 5
            r1 = 9 + (1 - k) * 20
            for a in (0, 45, 90, 135, 180, 225, 270, 315):
                ar = math.radians(a)
                d.line([(sx(x) + math.cos(ar) * r0, sy(y) + math.sin(ar) * r0 - 6),
                        (sx(x) + math.cos(ar) * r1, sy(y) + math.sin(ar) * r1 - 6)],
                       fill=color, width=2)

        # units
        for u in self.units:
            self.draw_unit(d, u, sx(u.x), sy(u.y))
        for e in self.enemy_units:
            self.draw_unit(d, e, sx(e.x), sy(e.y))

        # player
        self.draw_player(d, sx(self.player.x), sy(self.player.y))

        # hits
        for h in self.hits:
            x, y = sx(h[0]), sy(h[1])
            rr = 12 * (1 - h[2] / 0.12) + 4
            d.ellipse([x - rr, y - rr, x + rr, y + rr], outline=(255, 240, 190, 200), width=2)

        # popups
        for p in self.popups:
            f = load_font(16)
            d.text((sx(p.x), sy(p.y)), p.text, font=f, fill=p.color, anchor="mm",
                   stroke_width=2, stroke_fill=(60, 50, 44, 200))

        # night tint
        tone = None
        if self.phase == "night":
            k = clamp(min(1.0, (NIGHT_LEN - self.phase_t) / 6.0, self.phase_t / 6.0), 0, 1)
            if self.blood:
                tone = (112, 26, 32, int(126 * k))
            else:
                tone = (18, 24, 62, int(118 * k))
            if self.phase_t < 8:
                warm = 1.0 - self.phase_t / 8.0
                tone = (int(tone[0] + (220 - tone[0]) * warm),
                        int(tone[1] + (140 - tone[1]) * warm),
                        int(tone[2] + (90 - tone[2]) * warm),
                        int(tone[3] * (1 - 0.45 * warm)))
        elif self.phase_t < 14:
            warm = (14 - self.phase_t) / 14.0
            tone = (255, 146, 82, int(78 * warm))
        if tone is not None:
            frame = Image.alpha_composite(frame, Image.new("RGBA", (vw, vh), tone))
        for lx, ly, rad, amp in self.lights:
            sp = glow_sprite(rad)
            frame.paste(sp, (int(lx - rad), int(ly - rad * 0.82)), sp)

        spot = light_spot()
        frame.paste(spot, (-120, -140), spot)
        sz = 360
        for fx in (False, True):
            for fy in (False, True):
                cv = corner_vignette(360, 104, fx, fy)
                px = vw - sz if fx else 0
                py = vh - sz if fy else 0
                frame.paste(cv, (px, py), cv)

        if self.state == "playing" and self.keep_hp / self.keep_max < 0.35:
            kk = 1.0 - self.keep_hp / self.keep_max
            a = int((30 + 40 * kk) * (0.5 + 0.5 * math.sin(self.t * 5)))
            frame = Image.alpha_composite(frame, Image.new("RGBA", (vw, vh), (200, 40, 34, a)))
        if self.phase == "day" and self.phase_t < 12 and self.state == "playing":
            k = (12 - self.phase_t) / 12.0
            a = int(42 * k * (0.55 + 0.45 * math.sin(self.t * 7)))
            frame = Image.alpha_composite(frame, Image.new("RGBA", (vw, vh), (196, 46, 40, a)))

        if self.state != "menu":
            self.draw_hud(frame, cam)

        # 天气
        if self.weather == "rain":
            for i in range(0, vw, 46):
                off = int((self.t * 420 + i * 7) % vh)
                d.line([(i + (off % 23), off - 20), (i + (off % 23) - 6, off + 12)],
                       fill=(180, 200, 230, 90), width=2)
                d.line([(i + 23 + (off % 17), (off + 260) % vh - 20),
                        (i + 17 + (off % 17), (off + 260) % vh + 12)],
                       fill=(180, 200, 230, 70), width=2)
        elif self.weather == "snow":
            for i in range(0, vw, 52):
                yy = int((self.t * 90 + i * 3) % vh)
                d.ellipse([i + 10, yy, i + 14, yy + 4], fill=(250, 250, 255, 180))
                d.ellipse([i + 30, (yy + 200) % vh, i + 33, (yy + 200) % vh + 3],
                          fill=(250, 250, 255, 140))
        elif self.weather == "fog":
            frame.paste(fog_layer(vw, vh), (0, 0), fog_layer(vw, vh))

        # 菜单
        if self.state == "menu":
            ov = Image.new("RGBA", (vw, vh), (14, 12, 16, 210))
            frame = Image.alpha_composite(frame, ov)
            dd = ImageDraw.Draw(frame, "RGBA")
            dd.text((vw / 2, vh * 0.30), "营地守望", font=load_font(46), fill=(255, 236, 190),
                    anchor="mm", stroke_width=4, stroke_fill=(40, 30, 24))
            dd.text((vw / 2, vh * 0.38), "Camp Watch · 守护你的大本营", font=load_font(16),
                    fill=(226, 214, 196), anchor="mm")
            opts = [("1", "和平模式", "怪物更弱 · 收入更高", (170, 220, 170)),
                    ("2", "普通模式", "标准难度", (240, 226, 180)),
                    ("3", "残酷模式", "怪物更强 · 奖励更高", (240, 160, 150))]
            for i, (key, name, desc, col) in enumerate(opts):
                yy = vh * 0.50 + i * 62
                dd.rounded_rectangle([vw / 2 - 190, yy - 22, vw / 2 + 190, yy + 22], radius=12,
                                     fill=(30, 26, 24, 220), outline=col)
                dd.text((vw / 2 - 160, yy), "[%s]" % key, font=load_font(18), fill=col, anchor="lm")
                dd.text((vw / 2 - 110, yy - 6), name, font=load_font(17), fill=(250, 244, 230), anchor="lm")
                dd.text((vw / 2 - 110, yy + 12), desc, font=load_font(12), fill=(190, 182, 168), anchor="lm")
            dd.text((vw / 2, vh * 0.88), "按 1 / 2 / 3 开始（回车 = 普通）", font=load_font(14),
                    fill=(220, 210, 194), anchor="mm")
        elif self.state in ("win", "lose"):
            ov = Image.new("RGBA", (vw, vh), (12, 10, 14, 190))
            frame = Image.alpha_composite(frame, ov)
            dd = ImageDraw.Draw(frame, "RGBA")
            if self.state == "win":
                title = "守成结局：你在第 %d 天选择收手" % self.day if getattr(self, "survive_win", False) \
                    else "征服结局：所有营地插上了你的旗"
            else:
                title = "覆灭结局：三顶王冠都被抢走"
            dd.text((vw / 2, vh * 0.30), title, font=load_font(26), fill=(255, 236, 190),
                    anchor="mm", stroke_width=3, stroke_fill=(40, 30, 26))
            rows = ["存活 %d 天" % self.day,
                    "击杀 %d" % self.stats_kills,
                    "阵亡 %d" % self.stats_lost,
                    "金币峰值 %d" % self.peak_coins,
                    "占领营地 %d / %d" % (sum(1 for c in self.camps if c["owner"] == "mine"), len(self.camps))]
            for i, txt in enumerate(rows):
                dd.text((vw / 2, vh * 0.44 + i * 30), txt, font=load_font(16),
                        fill=(232, 224, 208), anchor="mm")
            dd.text((vw / 2, vh * 0.82), "按 R 重开", font=load_font(16), fill=(250, 226, 160), anchor="mm")
        out = self._rgb_cache.get((vw, vh))
        if out is None:
            out = Image.new("RGB", (vw, vh))
            self._rgb_cache[(vw, vh)] = out
        out.paste(frame)
        return out

    # ---------------- drawing helpers
    def bubble(self, d, x, y, text):
        f = load_font(14)
        w = d.textlength(text, font=f) + 24
        d.rounded_rectangle([x - w / 2, y - 16, x + w / 2, y + 14], radius=10,
                            fill=(255, 250, 236, 235), outline=INK, width=2)
        d.polygon([(x - 6, y + 13), (x + 6, y + 13), (x, y + 22)], fill=(255, 250, 236, 235),
                  outline=INK)
        d.text((x, y - 1), text, font=f, fill=(70, 58, 50), anchor="mm")

    def draw_animal(self, d, a, x, y):
        bob = math.sin(a.bob) * 1.4
        if a.kind == "rabbit":
            shadow(d, x, y + 9, 9, 4)
            blob(d, x, y - 2 + bob, 9, 8, (238, 232, 222), INK, 2)
            blob(d, x - 2, y - 12 + bob, 5, 6, (250, 246, 240), INK, 2)
            d.ellipse([x + 5, y - 6 + bob, x + 8, y - 3 + bob], fill=INK)
        else:
            shadow(d, x, y + 14, 14, 6)
            d.rounded_rectangle([x - 13, y - 6 + bob, x + 13, y + 10 + bob], radius=6,
                                fill=(198, 154, 108), outline=INK, width=2)
            blob(d, x + 12, y - 8 + bob, 7, 7, (208, 164, 116), INK, 2)
            d.line([(x + 12, y - 14 + bob), (x + 8, y - 22 + bob)], fill=INK, width=2)
            d.line([(x + 14, y - 14 + bob), (x + 20, y - 22 + bob)], fill=INK, width=2)

    def draw_refugee(self, d, r, x, y):
        bob = math.sin(r.bob) * 1.8
        shadow(d, x, y + 14, 13, 5)
        d.polygon([(x - 11, y + 12 + bob), (x - 8, y - 6 + bob), (x + 8, y - 6 + bob),
                   (x + 11, y + 12 + bob)], fill=(150, 142, 132), outline=INK, width=2)
        d.polygon([(x - 7, y + 12 + bob), (x, y + 2 + bob), (x + 7, y + 12 + bob)],
                  fill=(126, 118, 110), outline=INK)
        blob(d, x, y - 14 + bob, 9, 9, (242, 214, 184), INK, 2)
        d.arc([x - 10, y - 24 + bob, x + 10, y - 8 + bob], 180, 360, fill=(168, 128, 96), width=5)
        d.ellipse([x - 5, y - 16 + bob, x - 2, y - 12 + bob], fill=INK)
        d.ellipse([x + 2, y - 16 + bob, x + 5, y - 12 + bob], fill=INK)
        d.rounded_rectangle([x + 7, y - 4 + bob, x + 15, y + 8 + bob], radius=3,
                            fill=(176, 148, 108), outline=INK, width=2)
        d.line([(x - 13, y + 12 + bob), (x - 16, y - 10 + bob)], fill=(140, 106, 74), width=3)
        if math.sin(self.t * 3 + r.seed) > -0.2:
            d.text((x, y - 34 + bob), "!", font=load_font(16), fill=(255, 214, 120), anchor="mm",
                   stroke_width=2, stroke_fill=(60, 50, 44))

    def draw_farm(self, d, b, x, y):
        shadow(d, x, y + 20, 46, 14)
        d.rounded_rectangle([x - 46, y - 22, x + 46, y + 22], radius=8,
                            fill=(146, 108, 74), outline=INK, width=3)
        for i in range(3):
            yy = y - 12 + i * 12
            d.line([(x - 38, yy), (x + 38, yy)], fill=(172, 134, 92), width=4)
            for j in range(6):
                xx = x - 34 + j * 13
                sway = math.sin(self.t * 2 + i + j) * 1.5
                d.line([(xx, yy), (xx + sway, yy - 8)], fill=(126, 186, 110), width=2)
        if b.get("branch") == "high":
            for k in range(3):
                d.line([(x - 30 + k * 6, y - 26), (x - 30 + k * 6, y - 38)], fill=(150, 210, 130), width=2)
        elif b.get("branch") == "bomb":
            d.ellipse([x - 8, y - 40, x + 8, y - 26], fill=(60, 50, 48), outline=INK, width=2)
            d.line([(x, y - 40), (x + 3, y - 48)], fill=INK, width=2)
        if b["purse"] > 0:
            d.ellipse([x - 13, y - 52, x + 13, y - 30], fill=(248, 206, 84), outline=INK, width=2)
            d.text((x, y - 41), "%d" % b["purse"], font=load_font(13), fill=(90, 64, 30), anchor="mm")

    def draw_tower(self, d, b, x, y):
        shadow(d, x, y + 18, 28, 10)
        d.rounded_rectangle([x - 24, y - 40, x + 24, y + 18], radius=6,
                            fill=(206, 202, 194), outline=INK, width=3)
        d.rectangle([x - 24, y - 52, x + 24, y - 34], fill=(196, 190, 182), outline=INK, width=3)
        for i in range(4):
            bx0 = x - 24 + i * 13
            d.rectangle([bx0, y - 60, bx0 + 8, y - 50], fill=(206, 202, 194), outline=INK, width=2)
        branch = b.get("branch")
        if branch == "rapid":
            for i in (-6, 6):
                d.line([(x + i, y - 44), (x + i, y - 30)], fill=(250, 236, 190), width=2)
        elif branch == "heavy":
            d.line([(x, y - 48), (x, y - 26)], fill=(250, 236, 190), width=4)
            d.polygon([(x - 5, y - 48), (x + 5, y - 48), (x, y - 58)], fill=(238, 200, 120), outline=INK)
        d.rounded_rectangle([x - 8, y - 14, x + 8, y + 6], radius=3, fill=(96, 84, 74), outline=INK, width=2)
        bob = math.sin(self.t * 3) * 2
        blob(d, x, y - 68 + bob, 8, 8, (248, 220, 186), INK, 2)
        d.arc([x + 6, y - 74 + bob, x + 22, y - 58 + bob], -70, 70, fill=(110, 78, 54), width=2)

    def draw_barracks(self, d, b, x, y):
        shadow(d, x, y + 18, 34, 12)
        d.polygon([(x - 36, y + 16), (x, y - 30), (x + 36, y + 16)],
                  fill=(126, 96, 70), outline=INK, width=3)
        d.polygon([(x - 14, y + 16), (x, y - 8), (x + 14, y + 16)], fill=(58, 44, 36), outline=INK, width=2)
        d.line([(x + 22, y - 26), (x + 22, y - 52)], fill=(200, 200, 210), width=3)
        d.polygon([(x + 18, y - 52), (x + 26, y - 52), (x + 22, y - 60)], fill=(220, 220, 230), outline=INK)

    def draw_hospital(self, d, b, x, y):
        shadow(d, x, y + 18, 32, 12)
        d.rounded_rectangle([x - 30, y - 26, x + 30, y + 16], radius=6,
                            fill=(240, 238, 232), outline=INK, width=3)
        d.polygon([(x - 36, y - 24), (x, y - 48), (x + 36, y - 24)],
                  fill=(226, 220, 212), outline=INK, width=3)
        d.rectangle([x - 4, y - 20, x + 4, y + 4], fill=(212, 88, 84))
        d.rectangle([x - 14, y - 12, x + 14, y - 4], fill=(212, 88, 84))

    def draw_trap(self, d, b, x, y):
        d.ellipse([x - 26, y - 8, x + 26, y + 12], fill=(72, 66, 58), outline=INK, width=2)
        for i in range(5):
            tx = x - 20 + i * 10
            d.polygon([(tx - 5, y + 4), (tx, y - 14), (tx + 5, y + 4)],
                      fill=(210, 208, 200), outline=INK)

    def draw_statue(self, d, b, x, y):
        role = b["role"]
        col = {"hunter": (124, 154, 110), "knight": (150, 160, 178), "farmer": (216, 186, 108)}[role]
        shadow(d, x, y + 16, 34, 12)
        d.rounded_rectangle([x - 30, y - 6, x + 30, y + 16], radius=5,
                            fill=(196, 190, 178), outline=INK, width=3)
        d.rounded_rectangle([x - 8, y - 54, x + 8, y - 6], radius=4, fill=col, outline=INK, width=2)
        blob(d, x, y - 62, 11, 11, col, INK, 2)
        d.ellipse([x - 4, y - 65, x - 1, y - 61], fill=INK)
        d.ellipse([x + 2, y - 65, x + 5, y - 61], fill=INK)
        r = 250
        d.ellipse([x - r * 0.5, y - r * 0.34 + 8, x + r * 0.5, y + r * 0.34 + 8],
                  outline=(255, 236, 150, 110), width=2)

    def draw_site(self, d, pj, x, y):
        shadow(d, x, y + 14, 34, 12)
        d.rounded_rectangle([x - 34, y - 18, x + 34, y + 14], radius=6,
                            fill=(176, 150, 116), outline=INK, width=3)
        d.line([(x - 26, y - 18), (x - 26, y - 54)], fill=(160, 120, 84), width=3)
        d.line([(x + 26, y - 18), (x + 26, y - 54)], fill=(160, 120, 84), width=3)
        d.line([(x - 28, y - 50), (x + 28, y - 50)], fill=(160, 120, 84), width=3)
        ratio = clamp(pj["prog"] / max(pj["dur"], 1), 0, 1)
        d.rectangle([x - 36, y - 70, x + 36, y - 62], fill=(58, 48, 42), outline=INK)
        d.rectangle([x - 34, y - 68, x - 34 + 68 * ratio, y - 64], fill=(236, 190, 96))
        name = {"wall": "城墙", "expand": "扩建", "farm": "农场", "tower": "箭塔"}.get(pj["kind"], "雕像")
        d.text((x, y - 82), "%s %d%%" % (name, int(ratio * 100)), font=load_font(12),
               fill=(255, 244, 214), anchor="mm", stroke_width=2, stroke_fill=(40, 30, 26))

    def draw_camp(self, d, c, x, y):
        owner = c["owner"]
        if owner == "ruin":
            shadow(d, x, y + 20, 52, 16)
            d.ellipse([x - 50, y - 6, x + 50, y + 26], fill=(96, 88, 78), outline=INK, width=3)
            d.line([(x, y - 10), (x, y - 62)], fill=INK, width=4)
            d.text((x, y - 78), "F 插旗", font=load_font(13), fill=(255, 240, 200), anchor="mm",
                   stroke_width=2, stroke_fill=(40, 30, 26))
            return
        ox, oy = c["x"] - x, c["y"] - y
        for w in c["walls"]:
            if w.hp > 0:
                self.draw_wall(d, w, lambda wx: wx - ox, lambda wy: wy - oy)

        mine = owner == "mine"
        style = c.get("style", 0)
        stone = (196, 206, 220) if mine else (216, 210, 198)
        roof = (96, 126, 168) if mine else (168, 84, 72)
        shadow(d, x, y + 22, 56, 18)
        if style == 1:
            d.ellipse([x - 46, y - 44, x + 46, y + 24], fill=stone, outline=INK, width=3)
            for row in range(3):
                yy = y - 30 + row * 16
                d.line([(x - 42, yy), (x + 42, yy)], fill=(186, 180, 168), width=2)
            d.polygon([(x - 54, y - 40), (x, y - 96), (x + 54, y - 40)],
                      fill=(78, 106, 150) if not mine else (110, 140, 186), outline=INK, width=3)
            d.rounded_rectangle([x - 11, y - 20, x + 11, y + 24], radius=4,
                                fill=(120, 86, 60), outline=INK, width=2)
            top = y - 104
        elif style == 2:
            d.polygon([(x - 58, y + 22), (x, y - 74), (x + 58, y + 22)],
                      fill=(92, 130, 96) if not mine else (120, 158, 124), outline=INK, width=3)
            d.polygon([(x - 22, y + 22), (x, y - 26), (x + 22, y + 22)],
                      fill=(52, 62, 52), outline=INK, width=2)
            top = y - 84
        else:
            d.rounded_rectangle([x - 48, y - 30, x + 48, y + 20], radius=8,
                                fill=stone, outline=INK, width=3)
            for row in range(2):
                for col in range(4):
                    bx = x - 42 + col * 22 + (0 if row % 2 == 0 else 11)
                    by = y - 26 + row * 20
                    d.rectangle([bx, by, bx + 18, by + 15], fill=(232, 226, 212),
                                outline=(190, 182, 166))
            d.polygon([(x - 58, y - 30), (x, y - 76), (x + 58, y - 30)],
                      fill=roof, outline=INK, width=3)
            d.rounded_rectangle([x - 12, y - 18, x + 12, y + 20], radius=4,
                                fill=(120, 86, 60), outline=INK, width=2)
            top = y - 84

        d.line([(x, top), (x, top - 16)], fill=INK, width=4)
        flag = (110, 170, 230) if mine else (214, 92, 84)
        wave = math.sin(self.t * 3 + c["x"]) * 4
        d.polygon([(x + 1, top - 14), (x + 30 + wave, top - 2), (x + 1, top + 10)],
                  fill=flag, outline=INK, width=3)

        ratio = clamp(c["hp"] / max(c["max"], 1), 0, 1)
        w = 108
        d.rectangle([x - w / 2, y - 136, x + w / 2, y - 128], fill=(40, 30, 34), outline=INK)
        d.rectangle([x - w / 2 + 2, y - 134, x - w / 2 + 2 + (w - 4) * ratio, y - 130],
                    fill=(140, 200, 240) if mine else (230, 120, 110))
        if mine:
            gcount = sum(1 for u in self.units if getattr(u, "garrison", None) is c)
            label = "分营地·驻军%d" % gcount if gcount else "分营地"
        else:
            label = "敌方营地 Lv.%d" % c["level"]
        d.text((x, y - 148), label, font=load_font(12), fill=(255, 238, 220), anchor="mm",
               stroke_width=2, stroke_fill=(30, 22, 26))
        if mine and c["purse"] > 0:
            d.ellipse([x - 12, y + 26, x + 12, y + 48], fill=(248, 206, 84), outline=INK, width=2)
            d.text((x, y + 37), "%d" % c["purse"], font=load_font(12), fill=(90, 64, 30), anchor="mm")

    def draw_dock(self, d, x, y):
        shadow(d, x, y + 16, 40, 12)
        for i in range(4):
            d.rectangle([x - 34 + i * 18, y - 6, x - 22 + i * 18, y + 14],
                        fill=(178, 138, 96), outline=INK, width=2)
        bob = math.sin(self.t * 2.2) * 3
        d.polygon([(x - 10, y - 20 + bob), (x + 26, y - 20 + bob), (x + 20, y - 4 + bob),
                   (x - 4, y - 4 + bob)], fill=(196, 148, 100), outline=INK, width=3)

    def draw_keep(self, d, x, y):
        night = self.phase == "night"
        lvl = max(w.level for w in self.walls) if self.walls else 1
        # ground shadow
        shadow(d, x, y + 46, 86, 22)

        # stone plinth
        d.rounded_rectangle([x - 84, y + 26, x + 84, y + 50], radius=8,
                            fill=(178, 172, 160), outline=INK, width=4)
        for i in range(7):
            bx = x - 78 + i * 23
            d.rectangle([bx, y + 30, bx + 18, y + 46], fill=(196, 190, 178), outline=(120, 116, 106))

        # main body with stone blocks
        d.rounded_rectangle([x - 78, y - 54, x + 78, y + 30], radius=10,
                            fill=(232, 222, 198), outline=INK, width=4)
        for row in range(4):
            by = y - 48 + row * 20
            cols = 7 if row % 2 == 0 else 6
            for c in range(cols):
                bx = x - 72 + c * 22 + (0 if row % 2 == 0 else 11)
                d.rectangle([bx, by, bx + 19, by + 16], fill=(240, 231, 209), outline=(200, 186, 160))

        # timber frame
        d.line([(x - 78, y - 6), (x + 78, y - 6)], fill=(150, 106, 72), width=6)
        d.line([(x - 40, y - 54), (x - 40, y - 6)], fill=(150, 106, 72), width=5)
        d.line([(x + 40, y - 54), (x + 40, y - 6)], fill=(150, 106, 72), width=5)

        # windows (glow at night)
        for wx in (x - 52, x + 52):
            d.rounded_rectangle([wx - 15, y - 44, wx + 15, y - 18], radius=4,
                                fill=(84, 66, 54) if night else (168, 196, 214), outline=INK, width=3)
            if night:
                d.rounded_rectangle([wx - 11, y - 40, wx + 11, y - 22], radius=3,
                                    fill=(255, 206, 120))
                self.lights.append([x + (wx - x), y - 31, 92, 40])

        # door
        d.rounded_rectangle([x - 22, y - 26, x + 22, y + 30], radius=8,
                            fill=(126, 88, 60), outline=INK, width=4)
        d.rectangle([x - 16, y - 20, x + 16, y + 26], fill=(150, 106, 72), outline=(96, 64, 44), width=3)
        for i in range(2):
            d.line([(x - 16, y - 8 + i * 18), (x + 16, y - 8 + i * 18)], fill=(120, 122, 128), width=4)
        d.ellipse([x + 6, y + 2, x + 13, y + 9], fill=(240, 202, 96), outline=INK)

        # roof: layered tiles
        d.polygon([(x - 96, y - 48), (x, y - 114), (x + 96, y - 48)], fill=(186, 84, 68), outline=INK, width=4)
        for r in range(4):
            yy = y - 54 - r * 15
            width = 88 - r * 22
            d.line([(x - width, yy + 12), (x + width, yy + 12)], fill=(166, 70, 58), width=4)
            for t in range(-4, 5):
                tx = x + t * (width / 4.4)
                d.arc([tx - 10, yy + 2, tx + 10, yy + 18], 200, 340, fill=(210, 108, 88), width=3)
        d.polygon([(x - 96, y - 48), (x, y - 114), (x + 96, y - 48)],
                  outline=INK, width=0)

        # 等级装饰：旗帜 / 侧塔 / 金色描边
        if lvl >= 2:
            for sx_ in (-58, 58):
                d.line([(x + sx_, y - 58), (x + sx_, y - 96)], fill=INK, width=3)
                wave2 = math.sin(self.t * 3.2 + sx_) * 3
                d.polygon([(x + sx_, y - 94), (x + sx_ + (18 if sx_ > 0 else -18) + wave2, y - 84),
                           (x + sx_, y - 74)], fill=(232, 196, 120), outline=INK, width=2)
        if lvl >= 3:
            for i in range(5):
                bx = x - 76 + i * 32
                d.rectangle([bx, y - 84, bx + 18, y - 66], fill=(214, 206, 192), outline=INK, width=3)
        if lvl >= 4:
            for sx_ in (-96, 96):
                d.rounded_rectangle([x + sx_ - 18, y - 34, x + sx_ + 18, y + 30], radius=6,
                                   fill=(212, 204, 190), outline=INK, width=3)
                d.polygon([(x + sx_ - 24, y - 34), (x + sx_, y - 60), (x + sx_ + 24, y - 34)],
                          fill=(176, 84, 68), outline=INK, width=3)
        if lvl >= 5:
            d.polygon([(x - 96, y - 48), (x, y - 114), (x + 96, y - 48)],
                      outline=(246, 214, 120), width=4)

        # flag pole + banner
        d.line([(x, y - 112), (x, y - 152)], fill=INK, width=5)
        wave = math.sin(self.t * 3.4) * 5
        d.polygon([(x + 2, y - 150), (x + 46 + wave, y - 137), (x + 2, y - 122)],
                  fill=(246, 206, 92), outline=INK, width=3)
        d.ellipse([x + 14, y - 142, x + 24, y - 133], fill=(196, 92, 76), outline=INK)

        # torches
        for tx in (x - 92, x + 92):
            d.rectangle([tx - 3, y - 14, tx + 3, y + 20], fill=(120, 86, 58), outline=INK, width=2)
            flick = math.sin(self.t * 9 + tx) * 2
            d.polygon([(tx - 6, y - 16), (tx, y - 34 - flick), (tx + 6, y - 16)],
                      fill=(255, 168, 70), outline=(210, 110, 40))
            d.polygon([(tx - 3, y - 17), (tx, y - 26 - flick * 0.6), (tx + 3, y - 17)],
                      fill=(255, 236, 170))
            if night:
                self.lights.append([tx, y - 24, 132, 52])

    def draw_workshop(self, d, x, y):
        shadow(d, x + 2, y + 30, 44, 12)
        d.rounded_rectangle([x - 44, y - 6, x + 44, y + 28], radius=8,
                            fill=(208, 168, 122), outline=INK, width=3)
        d.polygon([(x - 52, y - 4), (x, y - 40), (x + 52, y - 4)], fill=(164, 118, 86), outline=INK, width=3)
        d.rounded_rectangle([x - 14, y - 16, x + 14, y + 6], radius=4, fill=(120, 124, 136), outline=INK, width=2)
        d.line([(x - 10, y - 16), (x + 10, y - 8)], fill=(240, 240, 246), width=3)

    def draw_wall(self, d, w, sx, sy):
        if w.hp <= 0:
            return
        ax, ay, bx, by = sx(w.ax), sy(w.ay), sx(w.bx), sy(w.by)
        thick = 15 + 3 * w.level
        ratio = w.ratio
        base = (172, 128, 88) if ratio > 0.45 else (186, 118, 92)
        # 木栅：底色 + 高光 + 阴影
        d.line([(ax, ay), (bx, by)], fill=(126, 92, 62), width=thick + 4)
        d.line([(ax, ay), (bx, by)], fill=base, width=thick)
        d.line([(ax, ay - 2), (bx, by - 2)], fill=(198, 158, 112), width=max(3, thick - 9))
        # 木板纹理
        L = math.hypot(bx - ax, by - ay)
        n = max(2, int(L / 34))
        for i in range(n + 1):
            t = i / n
            px = ax + (bx - ax) * t
            py = ay + (by - ay) * t
            d.line([(px, py - thick / 2 + 1), (px, py + thick / 2 - 1)],
                   fill=(150, 110, 74), width=2)
            d.ellipse([px - thick / 2 - 3, py - thick / 2 - 3, px + thick / 2 + 3, py + thick / 2 + 3],
                      fill=(160, 118, 78), outline=INK, width=2)
            d.ellipse([px - thick / 2, py - thick / 2 - 2, px + thick / 2 - 2, py + thick / 2 - 4],
                      fill=(196, 154, 110))
        # 受损裂纹
        if ratio < 0.75:
            cracks = int((1 - ratio) * 6) + 1
            for i in range(cracks):
                t = (i + 0.5) / cracks
                px = ax + (bx - ax) * t
                py = ay + (by - ay) * t
                d.line([(px - 6, py - thick / 2), (px + 4, py), (px - 3, py + thick / 2)],
                       fill=(88, 62, 44), width=2)

    def draw_unit(self, d, u, x, y):
        sc = getattr(u, "scale", 1.0)
        vet = getattr(u, "veteran", False)
        face = getattr(u, "face", 1)
        moving = getattr(u, "moving", False)
        atk = getattr(u, "atk", "idle")
        atk_t = getattr(u, "atk_t", 0.0)

        # 走路：上下颠 + 左右摆；站立：轻微呼吸
        if moving:
            step = math.sin(u.walk)
            bob = -abs(step) * 1.6
            sway = step * 1.2
        else:
            step = 0.0
            bob = math.sin(self.t * 2.0 + u.jit) * 0.7
            sway = math.sin(self.t * 1.3 + u.jit) * 0.4
        # 硬直：往后缩；挥砍：往前探
        lean = 0.0
        if atk == "stagger":
            lean = -3.0 * (atk_t / 0.16)
        elif atk == "swing":
            lean = 2.5 * (1 - atk_t / 0.22)
        elif atk == "draw":
            lean = -1.2

        bx = x + sway * 0.4 + face * lean * 0.5
        by = y + bob

        color = ROLE_COLOR.get(u.role, (226, 205, 176))
        if getattr(u, "team", "mine") == "enemy":
            color = (176, 96, 88)
        if getattr(u, "hit_flash", 0) > 0:
            color = (255, 236, 236)
        u.hit_flash = max(0.0, getattr(u, "hit_flash", 0) - 0.016)

        if getattr(u, "on_wall", False):
            d.rounded_rectangle([bx - 15, y + 6, bx + 15, y + 13], radius=3,
                                fill=(150, 110, 74), outline=INK, width=2)

        heavy = getattr(self, "_heavy", False) or getattr(self, "low_detail", False)
        if not heavy:
            shadow(d, x, y + 14, 13 * sc, 5 * sc)

        # 腿
        if moving and not heavy:
            l1 = step * 3.0
            d.line([(bx - 4, by + 8), (bx - 4 - l1 * 0.6, by + 13)], fill=(90, 74, 60), width=3)
            d.line([(bx + 4, by + 8), (bx + 4 + l1 * 0.6, by + 13)], fill=(90, 74, 60), width=3)

        # 身体
        body = [bx - 11 * sc, by - 8 * sc, bx + 11 * sc, by + 12]
        d.rounded_rectangle(body, radius=7, fill=color, outline=INK, width=2)
        if vet:
            d.rounded_rectangle([bx - 11 * sc, by + 2, bx + 11 * sc, by + 6],
                                radius=2, fill=(246, 206, 92), outline=(150, 110, 30))
        # 头
        blob(d, bx + face * 0.8, by - 13, 10, 10, (248, 220, 186), INK, 2)
        # 眼睛（朝向前方）
        ex = bx + face * 1.2
        d.ellipse([ex - 4, by - 16, ex - 1, by - 12], fill=INK)
        d.ellipse([ex + 2, by - 16, ex + 5, by - 12], fill=INK)
        # 老兵头盔 + 星
        if vet:
            d.arc([bx - 11, by - 23, bx + 11, by - 7], 180, 360,
                  fill=(246, 206, 92), width=4)
            d.polygon([(bx, by - 34), (bx + 4, by - 28), (bx - 4, by - 28)],
                      fill=(255, 226, 120), outline=(150, 110, 30))

        # 武器
        if heavy:
            pass
        elif u.role == "worker":
            d.line([(bx + face * 12, by - 2), (bx + face * 20, by - 12)], fill=(120, 86, 58), width=3)
            hx0, hx1 = sorted((bx + face * 16, bx + face * 24))
            d.rectangle([hx0, by - 18, hx1, by - 12], fill=(150, 154, 166), outline=INK)
        elif u.role == "hunter":
            pull = 0.0
            if atk == "draw":
                pull = 3.5 * (1 - atk_t / 0.22)
            elif atk == "release":
                pull = -1.0
            gx = bx + face * 14
            gy = by - 6
            d.arc([gx - 9, gy - 12, gx + 9, gy + 10], -80 if face > 0 else 100,
                  100 if face > 0 else 260, fill=(120, 86, 58), width=3)
            # 弓弦
            d.line([(gx - face * 2, gy - 11), (gx - face * (2 + pull), gy - 1),
                    (gx - face * 2, gy + 9)], fill=(226, 218, 196), width=1)
            if atk == "draw":
                d.line([(gx - face * (2 + pull), gy - 1), (gx + face * 12, gy - 1)],
                       fill=(220, 210, 180), width=2)
        elif u.role == "knight":
            ang = -0.9
            if atk == "swing":
                ang = -0.9 + (1 - atk_t / 0.22) * 1.8
            hx = bx + face * 11
            hy = by - 4
            sx = hx + math.cos(ang) * 14 * face
            sy = hy + math.sin(ang) * 14
            d.line([(hx, hy), (sx, sy)], fill=(196, 202, 214), width=3)
            d.polygon([(sx, sy), (sx - face * 4, sy + 5), (sx - face * 1, sy - 4)],
                      fill=(230, 236, 246), outline=INK)
            if atk == "swing":
                k = clamp(atk_t / 0.22, 0, 1)
                r = 18 + (1 - k) * 10
                d.arc([bx - r, by - r - 4, bx + r, by + r - 4],
                      200 if face > 0 else -20, 340 if face > 0 else 120,
                      fill=(255, 246, 200), width=4)
        elif u.role == "farmer":
            d.line([(bx + face * 11, by + 4), (bx + face * 19, by - 16)], fill=(126, 92, 62), width=3)
            d.polygon([(bx + face * 17, by - 18), (bx + face * 25, by - 13), (bx + face * 19, by - 6)],
                      fill=(186, 192, 202), outline=INK)
        elif u.role == "lumber":
            d.line([(bx + face * 11, by + 2), (bx + face * 19, by - 14)], fill=(120, 86, 58), width=3)
            d.polygon([(bx + face * 15, by - 18), (bx + face * 23, by - 10), (bx + face * 13, by - 10)],
                      fill=(190, 196, 206), outline=INK)

        if getattr(u, "team", "mine") == "enemy" and u.hp < u.max_hp:
            w = 26
            d.rectangle([bx - w / 2, by - 30, bx + w / 2, by - 25], fill=(50, 34, 34), outline=INK)
            d.rectangle([bx - w / 2 + 1, by - 29,
                         bx - w / 2 + 1 + (w - 2) * clamp(u.hp / max(u.max_hp, 1), 0, 1), by - 26],
                        fill=(226, 120, 110))
        if u.purse > 0:
            d.ellipse([bx - 4, by - 34, bx + 4, by - 26], fill=(248, 206, 84), outline=INK)

    def draw_player(self, d, x, y):
        bob = math.sin(self.t * 9) * 1.4
        shadow(d, x, y + 16, 14, 6)
        d.rounded_rectangle([x - 12, y - 6 + bob, x + 12, y + 14 + bob], radius=8,
                            fill=(92, 122, 176), outline=INK, width=2)
        blob(d, x, y - 14 + bob, 11, 11, (250, 224, 192), INK, 2)
        d.ellipse([x - 5, y - 17 + bob, x - 2, y - 13 + bob], fill=INK)
        d.ellipse([x + 2, y - 17 + bob, x + 5, y - 13 + bob], fill=INK)
        d.polygon([(x - 11, y - 22 + bob), (x - 7, y - 30 + bob), (x - 3, y - 22 + bob),
                   (x + 1, y - 30 + bob), (x + 5, y - 22 + bob), (x + 9, y - 30 + bob),
                   (x + 13, y - 22 + bob)],
                  fill=(246, 206, 92), outline=INK)
        d.line([(x - 14, y + 4 + bob), (x - 22, y + 12 + bob)], fill=(92, 122, 176), width=4)

    def draw_hud(self, frame, cam=(0, 0)):
        d = ImageDraw.Draw(frame, "RGBA")
        f18, f14, f12 = load_font(18), load_font(14), load_font(12)

        panel = (28, 24, 22, 150)
        d.rounded_rectangle([16, 14, 300, 126], radius=14, fill=panel)
        if self.coin_pulse > 0:
            r = 12 + (1 - self.coin_pulse / 0.35) * 10
            d.ellipse([42 - r, 44 - r, 42 + r, 44 + r], outline=(255, 226, 130, 160), width=2)
        blob(d, 42, 44, 11, 11, (248, 206, 84), (150, 110, 30), 2)
        coin_col = (255, 140, 130) if self.deny_flash > 0 else (255, 246, 220)
        d.text((62, 44), "%d" % self.coins, font=load_font(22), fill=coin_col, anchor="lm")
        d.text((62, 74), "第 %d 天 · %s" % (self.day,
                                            "白天" if self.phase == "day" else "夜晚"),
               font=f14, fill=(226, 218, 200), anchor="lm")
        # 血月 / 平安日
        if self.safe_day:
            d.text((62, 96), "平安日 · 产出×1.5", font=f12, fill=(180, 240, 180), anchor="lm")
        elif self.blood_count > 0:
            d.text((62, 96), "血月第 %d 次" % self.blood_count, font=f12,
                   fill=(255, 170, 160), anchor="lm")

        # crowns
        for i in range(3):
            cx0 = 40 + i * 26
            col = (250, 208, 96) if i < self.crowns else (78, 68, 62)
            d.polygon([(cx0 - 9, 112), (cx0 - 9, 102), (cx0 - 4, 108), (cx0, 98),
                       (cx0 + 4, 108), (cx0 + 9, 102), (cx0 + 9, 112)],
                      fill=col, outline=(52, 44, 40))

        bar_w = 220
        p = 1.0 - clamp(self.phase_t / (DAY_LEN if self.phase == "day" else NIGHT_LEN), 0, 1)
        d.rounded_rectangle([32, 92, 32 + bar_w, 99], radius=3, fill=(70, 66, 60, 180))
        d.rounded_rectangle([32, 92, 32 + bar_w * p, 99], radius=3,
                            fill=(246, 206, 92, 230) if self.phase == "day" else (150, 170, 240, 230))

        hint = "WASD 1-5职业 6/7/8雕像 9兵营 0医院 L陷阱 E升级 X扩建 Q出击 F插旗 H驻军 Z/C分支 Y补员 U修墙 Tab精简"
        d.rounded_rectangle([16, VIEW_H - 46, 820, VIEW_H - 14], radius=12, fill=(28, 24, 22, 140))
        d.text((32, VIEW_H - 30), hint, font=f12, fill=(232, 226, 210), anchor="lm")

        lvl = max(w.level for w in self.walls)
        kx_ratio = clamp(self.keep_hp / self.keep_max, 0, 1)
        has_camp = any(c["owner"] in ("enemy", "mine") for c in self.camps)
        panel_h = 104
        if self.nest is not None:
            panel_h = 178
        if has_camp:
            panel_h += 40
        d.rounded_rectangle([VIEW_W - 286, 12, VIEW_W - 12, panel_h], radius=14, fill=(28, 24, 22, 150))
        d.text((VIEW_W - 24, 28), "城墙 Lv.%d" % lvl, font=f14, fill=(250, 240, 220), anchor="rm")
        d.text((VIEW_W - 24, 50), "疆域 %.0f" % self.wall_half, font=f12, fill=(222, 214, 196), anchor="rm")
        d.rounded_rectangle([VIEW_W - 268, 64, VIEW_W - 24, 78], radius=6, fill=(60, 44, 40, 170))
        d.rounded_rectangle([VIEW_W - 266, 66, VIEW_W - 266 + 240 * kx_ratio, 76], radius=5,
                            fill=(236, 120, 110, 235) if kx_ratio < 0.4 else (150, 208, 140, 235))
        d.text((VIEW_W - 24, 90), "大本营 %d%%" % int(kx_ratio * 100), font=f12,
               fill=(226, 214, 200), anchor="rm")
        if kx_ratio < 0.45:
            urgent = "危急！守住大本营" if kx_ratio < 0.2 else "警告：大本营受损"
            d.text((VIEW_W / 2, 70), urgent, font=f12, fill=(255, 150, 130), anchor="mm",
                   stroke_width=2, stroke_fill=(40, 20, 20))

        if self.nest is not None:
            n = self.nest
            ratio = clamp(n["hp"] / n["max"], 0, 1)
            d.text((VIEW_W - 24, 116), "贪婪之巢 %d%%" % int(ratio * 100), font=f12,
                   fill=(255, 190, 180), anchor="rm")
            d.rounded_rectangle([VIEW_W - 268, 126, VIEW_W - 24, 140], radius=6, fill=(60, 32, 36, 170))
            d.rounded_rectangle([VIEW_W - 266, 128, VIEW_W - 266 + 240 * ratio, 138], radius=5,
                                fill=(226, 96, 96, 235))
            pd = dist(self.player.pos(), (n["x"], n["y"]))
            d.text((VIEW_W - 24, 164), "距离 %d m" % int(pd / 10), font=f12,
                   fill=(240, 214, 204), anchor="rm")

        enemies = sum(1 for c in self.camps if c["owner"] == "enemy")
        outs = sum(1 for c in self.camps if c["owner"] == "mine")
        if enemies or outs:
            d.text((VIEW_W - 24, 196 if self.nest is not None else 118),
                   "敌营 %d · 分营 %d" % (enemies, outs), font=f12,
                   fill=(240, 214, 204), anchor="rm")

        vets = sum(1 for u in self.units if getattr(u, "veteran", False))
        if vets:
            d.text((62, 112), "老兵 %d" % vets, font=f12, fill=(250, 214, 120), anchor="lm")

        counts = {}
        for u in self.units:
            counts[u.role] = counts.get(u.role, 0) + 1
        parts = ["%s %d" % (ROLE_NAME[k], v) for k, v in counts.items() if k != "idle"]
        idle = counts.get("idle", 0)
        if idle:
            parts.insert(0, "空闲 %d" % idle)
        d.text((VIEW_W - 246, VIEW_H - 40), " · ".join(parts) if parts else "", font=f12,
               fill=(250, 244, 228), anchor="rm")
        if self.fps:
            d.text((VIEW_W - 246, VIEW_H - 62), "%d FPS" % int(self.fps), font=f12,
                   fill=(210, 220, 200), anchor="rm")

        # 可交互高亮
        pp0 = self.player.pos()
        pulse = 4 * math.sin(self.t * 4)
        for pos, rad, near in (((self.keep[0], self.keep[1]), 96, 165),
                               (self.workshop, 62, 150)):
            if dist(pp0, pos) < near:
                hx, hy = pos[0] - cam[0], pos[1] - cam[1]
                d.ellipse([hx - rad - pulse, hy - rad * 0.7 - pulse,
                           hx + rad + pulse, hy + rad * 0.7 + pulse],
                          outline=(255, 226, 150, 120), width=2)

        # 顶部：夜袭/天亮倒计时（王国式预告）
        if self.state == "playing":
            if self.phase == "day":
                left = int(self.phase_t)
                label = "夜袭倒计时 %d 秒" % left
                if self.day % 4 == 3:
                    label += "   （明夜血月）"
                col = (255, 226, 150) if self.phase_t >= 12 else (255, 140, 130)
            else:
                left = int(self.phase_t)
                label = ("血月·天亮 %d 秒" % left) if self.blood else ("天亮 %d 秒" % left)
                col = (180, 200, 255)
            tw = d.textlength(label, font=f12) + 34
            d.rounded_rectangle([VIEW_W / 2 - tw / 2, 16, VIEW_W / 2 + tw / 2, 44],
                                radius=14, fill=(26, 22, 20, 175))
            wx_short = {"clear": "晴", "rain": "雨", "fog": "雾", "snow": "雪"}[self.weather]
            label = label + " · " + wx_short
            tw = d.textlength(label, font=f12) + 34
            d.rounded_rectangle([VIEW_W / 2 - tw / 2, 16, VIEW_W / 2 + tw / 2, 44],
                                radius=14, fill=(26, 22, 20, 175))
            d.text((VIEW_W / 2, 30), label, font=f12, fill=col, anchor="mm")

        # 老兵晋升横幅（画在最上层，压住倒计时）
        if self.promo is not None:
            txt, life = self.promo
            a = 235 if life > 0.6 else int(235 * (life / 0.6))
            tw = d.textlength(txt, font=load_font(16)) + 44
            d.rounded_rectangle([VIEW_W / 2 - tw / 2, 12, VIEW_W / 2 + tw / 2, 48],
                                radius=14, fill=(70, 50, 18, a), outline=(250, 214, 120, a))
            d.text((VIEW_W / 2, 30), txt, font=load_font(16), fill=(255, 244, 200), anchor="mm")

        # 黎明结算面板
        if self.dawn is not None and self.state == "playing":
            dw, dh = 300, 150
            dx0, dy0 = 20, 146
            d.rounded_rectangle([dx0, dy0, dx0 + dw, dy0 + dh], radius=14,
                                fill=(24, 20, 18, 215), outline=(250, 226, 160, 70))
            d.text((dx0 + dw / 2, dy0 + 18), "第 %d 天 · 昨夜战报" % self.day, font=f14,
                   fill=(255, 238, 190), anchor="mm")
            rows = [("击杀", "%d" % self.dawn["kills"], (190, 240, 190)),
                    ("阵亡", "%d" % self.dawn["lost"], (255, 180, 170)),
                    ("收入", "+%d 金" % self.dawn["income"], (250, 214, 120)),
                    ("城墙", "%d%%" % self.dawn["wall"], (200, 214, 240))]
            for i, (k, v, col) in enumerate(rows):
                cx0 = dx0 + 18 + (i % 2) * 140
                cy0 = dy0 + 44 + (i // 2) * 24
                d.text((cx0, cy0), k, font=f12, fill=(180, 170, 160), anchor="lm")
                d.text((cx0 + 62, cy0), v, font=f12, fill=col, anchor="lm")
            wx = {"clear": "晴", "rain": "雨", "fog": "雾", "snow": "雪"}[self.weather]
            d.text((dx0 + 18, dy0 + 104), "天气：" + wx, font=f12, fill=(210, 226, 240), anchor="lm")
            ctext = self.chronicle if len(self.chronicle) <= 13 else self.chronicle[:12] + "…"
            d.text((dx0 + 18, dy0 + 126), ctext, font=f12, fill=(216, 206, 190), anchor="lm")

        # 物体上方的操作提示（王国式：走到哪，提示就在哪个建筑头上）
        def draw_stack(wx, wy, acts, dy0=0):
            if not acts:
                return
            bx = wx - cam[0]
            by = wy - cam[1] - dy0
            h = 22 * len(acts) + 12
            w = 156
            d.rounded_rectangle([bx - w / 2, by - h, bx + w / 2, by], radius=10,
                                fill=(24, 20, 18, 205), outline=(250, 226, 160, 60))
            for i, (key, label, cost) in enumerate(acts):
                yy = by - h + 8 + i * 22
                ok = self.coins >= cost
                d.rounded_rectangle([bx - w / 2 + 8, yy, bx - w / 2 + 28, yy + 16], radius=4,
                                    fill=(250, 214, 120) if ok else (112, 100, 92))
                d.text((bx - w / 2 + 18, yy + 8), key, font=load_font(11),
                       fill=(40, 32, 26), anchor="mm")
                d.text((bx - w / 2 + 34, yy + 8), label, font=load_font(11),
                       fill=(246, 238, 220) if ok else (150, 140, 130), anchor="lm")
                if cost:
                    d.text((bx + w / 2 - 10, yy + 8), "%d" % cost, font=load_font(11),
                           fill=(250, 214, 120) if ok else (190, 110, 100), anchor="rm")

        pp = self.player.pos()
        lvl_w = max(w.level for w in self.walls) if self.walls else 1
        show_stack = self.dawn is None
        if dist(pp, self.keep) < 165:
            keep_acts = [("E", "升级城墙", 10 * lvl_w)]
            if self.wall_expand < MAX_EXPAND:
                keep_acts.append(("X", "扩建疆域", 30 + 25 * self.wall_expand))
            keep_acts.append(("B", "农场", 20))
            keep_acts.append(("T", "箭塔", 34))
            keep_acts.append(("9", "兵营", 40))
            keep_acts.append(("0", "医院", 34))
            keep_acts.append(("L", "陷阱", 14))
            if not show_stack:
                keep_acts = []
            draw_stack(self.keep[0] - 52, self.keep[1], keep_acts, 150)
        if dist(pp, self.workshop) < 150:
            tool_acts = [("1", "工人", TOOL_COST["worker"]),
                         ("2", "猎人", TOOL_COST["hunter"]),
                         ("3", "骑士", TOOL_COST["knight"]),
                         ("4", "伐木", TOOL_COST["lumber"]),
                         ("5", "农民", TOOL_COST["farmer"])]
            draw_stack(self.workshop[0] + 58, self.workshop[1], tool_acts, 92)
        for c in self.camps:
            if dist(pp, (c["x"], c["y"])) < 210:
                if c["owner"] == "enemy":
                    draw_stack(c["x"], c["y"], [("Q", "全军出击", 0)], 150)
                elif c["owner"] == "mine":
                    draw_stack(c["x"], c["y"], [("H", "驻军/撤回", 0)], 150)
                else:
                    draw_stack(c["x"], c["y"], [("F", "插旗", 30)], 150)
        for b in self.buildings:
            if b["type"] in ("tower", "farm") and not b.get("branch") and \
                    dist(pp, (b["x"], b["y"])) < 110:
                if b["type"] == "tower":
                    draw_stack(b["x"], b["y"], [("Z", "连射塔", 30), ("C", "重箭塔", 30)], 84)
                else:
                    draw_stack(b["x"], b["y"], [("Z", "高产农场", 25), ("C", "自爆农场", 25)], 62)
        for r in self.refugees:
            if dist(pp, r.pos()) < 110:
                draw_stack(r.x, r.y, [("G", "收编难民", 5)], 46)

        if self.toasts:
            ty = VIEW_H - 116
            for text, life in self.toasts[-2:]:
                tw = d.textlength(text, font=f14) + 44
                alpha = 190 if life > 0.5 else int(190 * life / 0.5)
                d.rounded_rectangle([VIEW_W / 2 - tw / 2, ty - 18, VIEW_W / 2 + tw / 2, ty + 18],
                                    radius=14, fill=(28, 24, 22, alpha))
                d.text((VIEW_W / 2, ty), text, font=f14, fill=(255, 244, 214), anchor="mm")
                ty += 42

        # minimap
        mw, mh = 210, 150
        mx0, my0 = VIEW_W - mw - 18, VIEW_H - mh - 18
        d.rounded_rectangle([mx0, my0, mx0 + mw, my0 + mh], radius=10,
                            fill=(30, 46, 34, 205), outline=(240, 236, 220, 110), width=2)
        sxr = (mw - 14) / WORLD_W
        syr = (mh - 14) / WORLD_H
        kx, ky = self.keep

        def mm(x, y):
            return (mx0 + 7 + x * sxr, my0 + 7 + y * syr)

        d.rectangle([mm(kx - self.wall_half, ky - self.wall_half),
                     mm(kx + self.wall_half, ky + self.wall_half)],
                    outline=(238, 206, 150, 200), width=1)
        vx0, vy0 = mm(cam[0], cam[1])
        vx1, vy1 = mm(cam[0] + VIEW_W, cam[1] + VIEW_H)
        d.rectangle([vx0, vy0, vx1, vy1], outline=(255, 255, 255, 110), width=1)
        for i, t in enumerate(self.trees):
            if not t.dead and i % 4 == 0:
                d.point(mm(t.x, t.y), fill=(74, 116, 74))
        for b in self.buildings:
            bx, by = mm(b["x"], b["y"])
            d.rectangle([bx - 2, by - 2, bx + 2, by + 2],
                        fill=(240, 210, 140) if b["type"] == "farm" else (210, 214, 226))
        for u in self.units:
            d.ellipse([mm(u.x, u.y)[0] - 2, mm(u.x, u.y)[1] - 2,
                       mm(u.x, u.y)[0] + 2, mm(u.x, u.y)[1] + 2], fill=(170, 230, 170))
        for m in self.monsters:
            mx, my = mm(m.x, m.y)
            d.rectangle([mx - 1, my - 1, mx + 1, my + 1], fill=(240, 96, 96))
        if self.nest is not None:
            nx, ny = mm(self.nest["x"], self.nest["y"])
            d.polygon([(nx, ny - 4), (nx + 4, ny), (nx, ny + 4), (nx - 4, ny)],
                      fill=(240, 90, 90), outline=(255, 210, 200))
        px, py = mm(self.player.x, self.player.y)
        d.ellipse([px - 3, py - 3, px + 3, py + 3], fill=(255, 255, 255), outline=(30, 30, 30))
        d.ellipse([mm(kx, ky)[0] - 3, mm(kx, ky)[1] - 3, mm(kx, ky)[0] + 3, mm(kx, ky)[1] + 3],
                  fill=(250, 214, 120), outline=(60, 46, 30))

        if self.state in ("win", "lose"):
            d.rectangle([0, 0, VIEW_W, VIEW_H], fill=(20, 18, 24, 170))
            if self.state == "win":
                title = "贪婪之巢已毁，三座岛终于安全了"
            else:
                title = "三顶王冠都被抢走了"
            d.text((VIEW_W / 2, VIEW_H / 2 - 30), title, font=load_font(34),
                   fill=(255, 236, 190), anchor="mm", stroke_width=3, stroke_fill=(40, 30, 26))
            d.text((VIEW_W / 2, VIEW_H / 2 + 24), "按 R 重新开始", font=f18,
                   fill=(230, 220, 206), anchor="mm")


# --------------------------------------------------------------------------- app
class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.game = Game()
        self.keys = set()
        self.cam = [0.0, 0.0]
        self.last = time.perf_counter()
        self.running = True

        root.title("营地守望 · Camp Watch")
        root.configure(bg="#2B2622")
        root.resizable(False, False)
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        w, h = VIEW_W, VIEW_H
        # 客户区要比画布略大，否则底部会盖住提示条
        root.geometry("%dx%d+%d+%d" % (w + 18, h + 62, (sw - w) // 2, max(0, (sh - h) // 2 - 30)))
        root.lift()
        root.attributes("-topmost", True)
        root.after(600, lambda: root.attributes("-topmost", False))

        self.canvas = tk.Canvas(root, width=VIEW_W, height=VIEW_H, highlightthickness=0, bg="#2B2622")
        self.canvas.place(relx=0.5, rely=0.5, anchor="center")
        self.photo = None
        self.item = None
        self.frame_ms = 16.0
        self.fps = 60.0
        self.last_frame = time.perf_counter()
        # Windows 默认计时精度 15.6ms，会把 after(3) 睡成 15ms，这里提到 1ms
        try:
            import ctypes
            ctypes.windll.winmm.timeBeginPeriod(1)
            self._timer_fixed = True
        except Exception:
            self._timer_fixed = False

        root.bind("<KeyPress>", self.on_key)
        root.bind("<KeyRelease>", self.on_key_up)
        root.bind("<Escape>", lambda _e: self.quit())

        self.update_cam(1.0)
        self.root.after(16, self.loop)

    def quit(self):
        self.running = False
        try:
            if getattr(self, "_timer_fixed", False):
                import ctypes
                ctypes.windll.winmm.timeEndPeriod(1)
        except Exception:
            pass
        self.root.destroy()

    def on_key(self, event):
        k = event.keysym.lower()
        if self.game.state == "menu":
            if k in ("1", "2", "3"):
                init_sfx()
                self.game.start_game(int(k))
            elif k in ("return", "space", "kp_enter"):
                init_sfx()
                self.game.start_game(2)
            return
        mapping = {"up": "up", "down": "down", "left": "left", "right": "right"}
        self.keys.add(mapping.get(k, k))
        if k == "r":
            self.game.reset()
        elif k == "e":
            self.game.upgrade_walls()
        elif k == "x":
            self.game.expand_walls()
        elif k == "f":
            self.game.plant_flag()
        elif k == "q":
            self.game.order_attack()
        elif k == "h":
            self.game.station_troops()
        elif k == "y":
            self.game.quick_recruit()
        elif k == "u":
            self.game.quick_repair()
        elif k == "z":
            self.game.upgrade_branch("tower", "rapid")
            self.game.upgrade_branch("farm", "high")
        elif k == "c":
            self.game.upgrade_branch("tower", "heavy")
            self.game.upgrade_branch("farm", "bomb")
        elif k == "6":
            self.game.build("statue_hunter")
        elif k == "7":
            self.game.build("statue_knight")
        elif k == "8":
            self.game.build("statue_farmer")
        elif k == "9":
            self.game.build("camp_barracks")
        elif k == "0":
            self.game.build("camp_hospital")
        elif k == "l":
            self.game.build("camp_trap")
        elif k == "b":
            self.game.build("farm")
        elif k == "t":
            self.game.build("tower")
        elif k == "g":
            self.game.recruit()
        elif k == "v":
            self.game.say("换岛功能已取消，专心守住这一座营地", 2.5)
        elif k in ("1", "2", "3", "4", "5"):
            role = {"1": "worker", "2": "hunter", "3": "knight", "4": "lumber",
                    "5": "farmer"}[k]
            self.game.buy_tool(role)

    def on_key_up(self, event):
        k = event.keysym.lower()
        self.keys.discard(k)

    def update_cam(self, dt):
        px, py = self.game.player.pos()
        tx = clamp(px - VIEW_W / 2, 0, WORLD_W - VIEW_W)
        ty = clamp(py - VIEW_H / 2, 0, WORLD_H - VIEW_H)
        self.cam[0] += (tx - self.cam[0]) * min(1.0, dt * 7)
        self.cam[1] += (ty - self.cam[1]) * min(1.0, dt * 7)

    def loop(self):
        if not self.running:
            return
        try:
            self._frame()
        except Exception:
            import traceback
            try:
                with open(os.path.join(os.environ.get("TEMP", "."), "camp_err.log"), "a",
                          encoding="utf-8") as f:
                    f.write(time.strftime("%H:%M:%S") + "\n")
                    traceback.print_exc(file=f)
            except Exception:
                pass
        if self.running:
            self.root.after(getattr(self, "_delay", 1), self.loop)

    def _frame(self):
        now = time.perf_counter()
        dt = min(0.05, now - self.last)
        self.last = now
        self.game.update(dt, self.keys)
        self.update_cam(dt)
        t0 = time.perf_counter()
        sh = self.game.shake
        ox = random.uniform(-1, 1) * sh * 9 if sh > 0 else 0
        oy = random.uniform(-1, 1) * sh * 9 if sh > 0 else 0
        img = self.game.draw((int(self.cam[0] + ox), int(self.cam[1] + oy)))
        dt_draw = (time.perf_counter() - t0) * 1000
        self.frame_ms = self.frame_ms * 0.85 + dt_draw * 0.15

        if self.photo is None or self.photo.width() != img.width or self.photo.height() != img.height:
            self.photo = ImageTk.PhotoImage(img)
            if self.item is None:
                self.item = self.canvas.create_image(0, 0, anchor="nw", image=self.photo)
            else:
                self.canvas.itemconfig(self.item, image=self.photo)
        else:
            self.photo.paste(img)

        spent = (time.perf_counter() - t0) * 1000
        now = time.perf_counter()
        gap = now - self.last_frame
        self.last_frame = now
        if gap > 0:
            self.fps = self.fps * 0.9 + (1.0 / gap) * 0.1
            self.game.fps = self.fps
        # 自适应画质
        if self.fps and self.fps < 48 and not getattr(self.game, 'low_detail', False):
            self.game.low_detail = True
        elif self.fps > 57 and getattr(self.game, 'low_detail', False):
            self.game.low_detail = False
        # 帧率封顶 60：剩余时间交给 after 调度
        self._delay = int(max(1, 16 - spent))


# --------------------------------------------------------------------------- checks
def check_mode():
    g = Game(seed=3)
    g.start_game(2)
    t0 = time.perf_counter()
    steps = 0
    for _ in range(2400):  # ~80s of game time
        g.update(1 / 30.0, ())
        steps += 1
    dt = time.perf_counter() - t0
    img = g.draw((0, 0))
    print("ticks %d in %.2fs (%.2f ms/tick) | day %d | phase %s | units %d | monsters %d"
          % (steps, dt, dt / steps * 1000, g.day, g.phase, len(g.units), len(g.monsters)))
    print("render size", img.size, "| state", g.state, "| keep_hp %.0f" % g.keep_hp)
    return 0


def main():
    import gc
    gc.set_threshold(20000, 100, 200)
    if "--check" in sys.argv:
        raise SystemExit(check_mode())
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
